import json
import re
from typing import Any, Dict, Optional

def safe_float(val: Any) -> float:
    try:
        return float(val) if val is not None else 0.0
    except (ValueError, TypeError):
        return 0.0

def safe_bool(d: Dict[str, Any], key: str) -> bool:
    val = d.get(key)
    return val in [True, 1, "1", "true", "True", "yes", "YES"]

def _normalizar_palabra_numero_es(texto: str) -> str:
    rep = {
        'á': 'a', 'é': 'e', 'í': 'i', 'ó': 'o', 'ú': 'u', 'ü': 'u',
    }
    t = str(texto or '').lower().strip()
    for a, b in rep.items():
        t = t.replace(a, b)
    t = re.sub(r"\s+", " ", t)
    return t

def _parse_numero_es(frase: str) -> Optional[int]:
    """Convierte números en texto español (0-199 aprox) a entero."""
    s = _normalizar_palabra_numero_es(frase)
    if not s:
        return None

    direct = {
        'cero': 0, 'un': 1, 'uno': 1, 'una': 1, 'dos': 2, 'tres': 3, 'cuatro': 4,
        'cinco': 5, 'seis': 6, 'siete': 7, 'ocho': 8, 'nueve': 9, 'diez': 10,
        'once': 11, 'doce': 12, 'trece': 13, 'catorce': 14, 'quince': 15,
        'dieciseis': 16, 'diecisiete': 17, 'dieciocho': 18, 'diecinueve': 19,
        'veinte': 20, 'veintiuno': 21, 'veintiun': 21, 'veintidos': 22, 'veintitres': 23,
        'veinticuatro': 24, 'veinticinco': 25, 'veintiseis': 26, 'veintisiete': 27,
        'veintiocho': 28, 'veintinueve': 29, 'treinta': 30, 'cuarenta': 40,
        'cincuenta': 50, 'sesenta': 60, 'setenta': 70, 'ochenta': 80, 'noventa': 90,
        'cien': 100, 'ciento': 100,
    }
    if s in direct:
        return direct[s]

    if ' y ' in s:
        a, b = [x.strip() for x in s.split(' y ', 1)]
        if a in direct and b in direct:
            return direct[a] + direct[b]

    if s.startswith('ciento '):
        rem = s.replace('ciento ', '', 1).strip()
        if rem in direct:
            return 100 + direct[rem]
        if ' y ' in rem:
            a, b = [x.strip() for x in rem.split(' y ', 1)]
            if a in direct and b in direct:
                return 100 + direct[a] + direct[b]

    return None

def normalizar_numeros_texto_clinico(texto: str) -> str:
    """Reescribe expresiones numéricas en palabras a dígitos para facilitar regex/LLM."""
    if not texto:
        return texto

    unidades = r"(?:años?|a\u00f1os?|mm|cm|mV|pg/ml|pg\/ml|%|por ciento)"
    patron = re.compile(
        rf"\b([a-zA-ZáéíóúüñÁÉÍÓÚÜÑ]+(?:\s+y\s+[a-zA-ZáéíóúüñÁÉÍÓÚÜÑ]+)?(?:\s+[a-zA-ZáéíóúüñÁÉÍÓÚÜÑ]+)?)\s+({unidades})\b",
        flags=re.IGNORECASE
    )

    def repl(m: re.Match) -> str:
        expr = m.group(1)
        uni = m.group(2)
        n = _parse_numero_es(expr)
        if n is None:
            return m.group(0)
        return f"{n} {uni}"

    texto_out = patron.sub(repl, texto)
    texto_out = re.sub(r"\bmenos\s+(\d+(?:[\.,]\d+)?)\b", r"-\1", texto_out, flags=re.IGNORECASE)
    return texto_out

def parsear_json_llm(content: Any) -> Dict[str, Any]:
    """Parsea salida de LLM tolerando texto extra y bloques markdown."""
    if isinstance(content, dict):
        return content

    text = str(content or "").strip()
    if not text:
        return {}

    try:
        obj = json.loads(text)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        pass

    text_clean = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE).strip("` \n")
    try:
        obj = json.loads(text_clean)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        pass

    m = re.search(r"\{.*\}", text_clean, flags=re.DOTALL)
    if not m:
        return {}

    try:
        obj = json.loads(m.group(0))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}
