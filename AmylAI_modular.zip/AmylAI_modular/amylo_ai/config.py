from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
BASE_DIR = str(PACKAGE_DIR.parent)

ALGORITMO_VERSION = "4.3.0-OPTIMIZADO"
FECHA_VALIDACION = "2026-02-08"
DB_FILE = "tabla_amiloidosis_completada-_1_.csv"
if not DB_FILE.lower().endswith(".csv"):
    DB_FILE = f"{DB_FILE}.csv"

TERMINOLOGIA_MEDICA = {
    # CONFUSORES (elevan umbral de HVI exigido)
    "confusor_hta": "HTA|Hipertensión|Hipertenso|Cifras tensionales elevadas|Crisis hipertensiva|Antecedentes de hipertensión",
    "confusor_ao": "Estenosis aórtica|EAo|Valvulopatía aórtica|TAVI|Prótesis aórtica|Recambio valvular|Aorta bicúspide",
    "confusor_irc": "Insuficiencia renal|IRC|ERC|Fallo renal|Creatinina elevada|Filtrado glomerular|Diálisis",
    
    # RED FLAGS ATTR: FENOTIPO MUSCULOESQUELÉRICO
    "stc": "Túnel carpiano|STC|Atrapamiento del mediano|Liberación del mediano|Retinaculotomía|Síndrome del túnel carpiano|Parestesias mano|Adormecimiento dedos",
    "biceps": "Rotura de bíceps|Signo de Popeye|Deformidad en brazo|Tenotomía|Rotura bicipital|Avulsión proximal",
    "lumbar": "Canal lumbar estrecho|Estenosis de canal|Claudicación neurógena|Laminectomía|Estenosis foraminal|Compresión radicular|Estenosis lumbar",
    "hombro": "Tendinopatía hombro|Supraespinoso|Manguito rotadores|Omalgia|Hombro congelado|Capsulitis adhesiva|Rotura manguito|Gota hombro",
    "dupuytren": "Enfermedad de Dupuytren|Contractura de Dupuytren|Nódulos palmares|Cordones fibrosos mano",
    "artralgias": "Artralgias|Artralgia de grandes articulaciones|Dolor articular|Poliartralgia|Artropatía",
    "fractura_vert": "Fractura vertebral|Colapso vertebral|Osteoporosis|Fracturas patológicas|Cifosis",
    
    # RED FLAGS AL: SISTÉMICOS
    "macro": "Macroglosia|Lengua aumentada|Hipertrofia lingual|Improntas dentales|Festoneado|Aumento de volumen lingual",
    "purpura": "Púrpura|Ojos de mapache|Hematoma periorbitario|Equimosis palpebral|Hemorragia conjuntival|Púrpura periorbitaria",
    "mgus": "Gammapatía|MGUS|Mieloma|Componente monoclonal|Pico M|Banda monoclonal|Cadenas ligeras libres|Inmunofijación positiva|Paraproteína",
    "nefro": "Síndrome nefrótico|Edemas|Proteinuria|Albuminuria|Orina espumosa|Proteinuria >3.5|Insuficiencia renal|Nefropatía",
    "neuro_p": "Polineuropatía|Neuropatía|Parestesias en calcetín|Hormigueos distales|Neuropatía sensorial|Pérdida sensorial",
    "disauto": "Disautonomía|Hipotensión ortostática|Síncope vasovagal|Disfunción eréctil|Alteración GI|Impotencia|Estreñimiento|Diarrea",
    "hepato": "Hepatomegalia|Aumento de hígado|Hígado palpable|Cirrosis|Insuficiencia hepática",
    "fatiga": "Fatiga severa|Agotamiento extremo|Pérdida de energía|Síncope|Presíncope",
    "piel_lesiones": "Lesiones cérosas|Depósitos cutáneos|Lesiones papulares|Infiltración cutánea|Amiloidosis cutánea",
    
    # RED FLAGS CARDIACAS (AMBAS)
    "bav_mp": "Bloqueo AV|BAV|Bloqueo completo|Marcapasos|MP definitivo|DAI|TRC|Disfunción del nodo|Bloqueo de rama",
    "apical_sparing": "Apical sparing|Conservación apical|Strain apical longitudinal preservado|Patrón de strain discordante",
    "pseudo_q": "Pseudoinfarto|Ondas Q|Patrón tipo infarto|Necrosis|Fibrosis miocárdica",
    "biatrial": "Dilatación biauricular| Aurículas aumentadas|Aurículas dilatadas",
    "bajo_voltaje": "Bajo voltaje|Microvoltaje|Voltaje bajo|Bajo voltaje paradójico",
    
    # PATOLOGÍA ATTR HEREDITARIA
    "mutacion_ttr": "Mutación TTR|Transtiretina hereditaria|Amiloidosis hereditaria|Neuropatía amiloide hereditaria|Polineuropatía amiloide familiar",
    
    # OTROS ATTR-ESPECÍFICOS
    "tendinitis_calcifica": "Tendinitis cálcica|Depósitos de calcio|Calcificación tendinosa|Calcificación rotadoriana",
    
    # BIOMARCADORES (Nuevos)
    "nt_probnp": "NT-proBNP|NT-proBNP elevado|BNP|Péptido natriurético|Péptidos natriuréticos",
    "troponina": "Troponina elevada|Troponina alta|Troponina I|Troponina T|Elevación de troponina",
    
    # RESONANCIA MAGNÉTICA CARDÍACA (Nuevos)
    "lge_patron": "Realce tardío|Gadolinio|Patrón subendocárdico|Patrón transmural|Fibrosis|Infiltración|LGE|Delayed enhancement",
    "ecv": "Volumen extracelular|ECV|Volumen extracelular elevado|ECV alterado|T1 mapping",
    "t1_mapping": "T1 nativo|T1 mapping|T1 elevado|T1 prolongado",
    
    # DETALLES ECOCARDIOGRÁFICOS (Nuevos)
    "derrame_pericardico": "Derrame pericárdico|Efusión pericárdica|Cantidad de pericardio|Líquido pericárdico",
    "septum_posterior": "Tabique engrosado|Pared posterior engrosada|Grosor del tabique|Distribución concéntrica|Patrón concéntrico",
    "distribucion_concentrica": "Distribución concéntrica|Patrón concéntrico|Hipertrofia concéntrica|HVI concéntrica",
    "rv_engrosado": "RV engrosado|Ventrículo derecho engrosado|Pared libre RV engrosada|Grosor RV aumentado",
    "aorta_pequena": "Aorta pequeña|Aorta normal|Diámetro aórtico pequeño|Paradoja aórtica",
    "ausencia_fa": "Sin fibrilación auricular|Ausencia de FA|FA negada|Ritmo sinusal|Ritmo sinusal normal",
    
    # RESONANCIA MAGNÉTICA AVANZADA
    "hiperrealce_subepicardico": "Hiperrealce subepicárdico|Realce subepicárdico|Patrón subepicárdico|Fibrosis subepicárdica",
    
    # TROPONINA ESPECÍFICA
    "troponina_cronica": "Troponina crónica|Troponina ligeramente elevada|Troponina baja persistente|Elevación crónica de troponina"
}

FEATURES = [
    # Parámetros cardiacos numéricos
    "ivs","volt","gls",
    # Biomarcadores
    "nt_probnp","troponina","troponina_cronica",
    # Resonancia Cardíaca / RM
    "lge_patron","ecv","t1_mapping","hiperrealce_subepicardico",
    # Demografía
    "edad","sexo",
    # Detalles ecocardiográficos finos - REDFLAGS NUEVOS ATTR específicos
    "derrame_pericardico","septum_posterior","distribucion_concentrica","rv_engrosado","aorta_pequena","ausencia_fa",
    # ✓ FENOTIPO ATTR MUSCULOESQUELÉTICO - Red Flags de ATTR Clásico
    "stc","biceps","lumbar","hombro","dupuytren","artralgias","fractura_vert","tendinitis_calcifica",
    # ✓ FENOTIPO AL SISTÉMICO - Red Flags de AL
    "macro","purpura","mgus","nefro","neuro_p","disauto","hepato","fatiga","piel_lesiones",
    # ✓ HALLAZGOS CARDIACOS ESPECÍFICOS - Red Flags cardiacos
    "apical_sparing","biatrial","bav_mp","pseudo_q","bajo_voltaje",
    # ✓ ATTR HEREDITARIA - Red Flags genéticos
    "mutacion_ttr",
    # ✓ FACTORES CONFUSORES - Diagnóstico diferencial
    "confusor_hta","confusor_ao","confusor_irc"
]

DEFAULT_DATA = {
    "nhc": "",
    # Valores numéricos principales
    "ivs": 0.0, "volt": 0.0, "gls": 0.0,
    # Biomarcadores
    "nt_probnp": 0.0, "troponina": False,
    # RM
    "lge_patron": "", "ecv": 0.0, "t1_mapping": False,
    # Demografía
    "edad": 0, "sexo": "",
    # Ecocardiografía fina
    "derrame_pericardico": False, "septum_posterior": 0.0,
    # Fenotipo ATTR musculoesquelético
    "stc": False, "biceps": False, "lumbar": False, "hombro": False, 
    "dupuytren": False, "artralgias": False, "fractura_vert": False, "tendinitis_calcifica": False,
    # Fenotipo AL sistémico
    "macro": False, "purpura": False, "mgus": False, "nefro": False,
    "neuro_p": False, "disauto": False, "hepato": False, "fatiga": False, "piel_lesiones": False,
    # Cardiacos
    "apical_sparing": False, "biatrial": False, "bav_mp": False, "pseudo_q": False, "bajo_voltaje": False,
    # REDFLAGS NUEVOS: Ecocardiografía específica ATTR
    "distribucion_concentrica": False, "rv_engrosado": False, "aorta_pequena": False, "ausencia_fa": False,
    # REDFLAGS NUEVOS: RM específica ATTR
    "hiperrealce_subepicardico": False, "troponina_cronica": False,
    # ATTR hereditaria
    "mutacion_ttr": False,
    # Confusores
    "confusor_hta": False, "confusor_ao": False, "confusor_irc": False,
    # NUEVO v4.3.0: Metadata de análisis
    "confianza_ia": 0.0,  # Porcentaje de confianza del modelo
    "modelo_usado": ""   # Tipo de modelo (LLM, Regex, Híbrido)
}

PESOS = {
    "apical_sparing": 4,
    "discordancia": 3,
    "hvi_base": 3,
    "hvi_confusor": 1,
    "strain_reducido": 2,
    "bav_mp": 2,
    "attr_extra_alto": 3,
    "attr_extra_bajo": 1
}

UMBRAL_CONFIRMACION = 2   # Score para ATTR ALTA

UMBRAL_SCREENING = 4      # Score para INTERMEDIA (antes era 1 - demasiado bajo)

UMBRAL_CONFIRMACION_CALIBRADO = None  # Se actualizará desde la UI si es necesario

UMBRAL_SCREENING_CALIBRADO = None     # Se actualizará desde la UI si es necesario

ENSAMBLE_CATEGORIAS = [
    "ALTA SOSPECHA (AL)",
    "ALTA PROBABILIDAD (ATTR)",
    "INTERMEDIA (Screening)",
    "HVI No Amiloide",
    "BAJA / SANO",
]

ENSAMBLE_ESTILOS = {
    "ALTA SOSPECHA (AL)": {
        "color": "#d32f2f",
        "msg": "🚨 Alta sospecha de amiloidosis AL por consenso clínico-IA.",
        "accion": "Derivación URGENTE a Hematología + estudio de cadenas ligeras y biopsia según contexto."
    },
    "ALTA PROBABILIDAD (ATTR)": {
        "color": "#c62828",
        "msg": "✅ Alta probabilidad de ATTR por consenso clínico-IA.",
        "accion": "Confirmar con gammagrafía ósea (Tc-99m DPD/PyP) ± estudio genético/biopsia."
    },
    "INTERMEDIA (Screening)": {
        "color": "#f57c00",
        "msg": "⚠️ Sospecha moderada. Requiere pruebas complementarias.",
        "accion": "Completar Cardio-RM, biomarcadores y algoritmo diferencial."
    },
    "HVI No Amiloide": {
        "color": "#1976d2",
        "msg": "💙 Fenotipo hipertrófico probablemente no amiloide.",
        "accion": "Optimizar control de HTA/valvulopatía y reevaluar si aparecen red flags."
    },
    "BAJA / SANO": {
        "color": "#388e3c",
        "msg": "✅ Baja probabilidad de cardiopatía infiltrativa.",
        "accion": "Seguimiento clínico habitual."
    }
}
