import streamlit as st
from amylo_ai.config import DEFAULT_DATA

def init_session_state():
    if 'form_data' not in st.session_state:
        st.session_state.form_data = DEFAULT_DATA.copy()
    if 'consolidado_batch' not in st.session_state:
        st.session_state.consolidado_batch = []
    if 'resumen_generado' not in st.session_state:
        st.session_state.resumen_generado = None
    if 'confianza_analisis' not in st.session_state:
        st.session_state.confianza_analisis = 0.0
    if 'nivel_diagnostico' not in st.session_state:
        st.session_state.nivel_diagnostico = ''
    if 'analisis_automatico' not in st.session_state:
        st.session_state.analisis_automatico = False
