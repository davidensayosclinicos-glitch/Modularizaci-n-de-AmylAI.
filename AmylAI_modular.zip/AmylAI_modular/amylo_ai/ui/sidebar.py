import os
import streamlit as st
from amylo_ai.config import BASE_DIR
from amylo_ai.utils.files import read_file_base64
from amylo_ai.services import llm

def render_sidebar():
    tab_labels = [
        "Lote de PDFs",
        "Caso Individual",
        "Guia Clinica",
        "Base de Datos",
        "Diagnóstico del Algoritmo",
        "Test de Estrés"
    ]

    fondo_lateral_path = os.path.join(BASE_DIR, "fondo_lateral.jpg")
    # Streamlit Cloud: intentar ruta relativa si BASE_DIR falla
    if not os.path.exists(fondo_lateral_path) and os.path.exists("fondo_lateral.jpg"):
        fondo_lateral_path = "fondo_lateral.jpg"

    fondo_lateral_data = read_file_base64(fondo_lateral_path)
    fondo_lateral_base64 = fondo_lateral_data if fondo_lateral_data else None
    fondo_lateral_css = (
        f"background-image: url('data:image/jpeg;base64,{fondo_lateral_base64}') !important;"
        if fondo_lateral_base64 else ""
    )

    with st.sidebar:
        # Logo elegante - PROTAGONISTA
        try:
            logo_path = os.path.join(BASE_DIR, "image_6.png")
            if not os.path.exists(logo_path) and os.path.exists("image_6.png"):
                logo_path = "image_6.png"

            logo_b64 = read_file_base64(logo_path)
            if logo_b64:
                st.markdown(
                    f"""
                    <div class='sidebar-logo-wrap'>
                        <img src='data:image/png;base64,{logo_b64}' alt='AmylAI Logo' />
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            else:
                st.markdown(f"<h3 style='text-align:center; font-size:3em;'><b>🏥</b></h3>", unsafe_allow_html=True)
        except Exception as e:
            st.markdown(f"<h3 style='text-align:center; font-size:3em;'><b>🏥</b></h3>", unsafe_allow_html=True)
    
        # Descripción de la app
        st.markdown("""
        <div style='text-align: center; padding: 10px 8px; font-size: 0.82em; line-height: 1.4;'>
        <b>AmylAI 1.0</b> detecta amiloidosis cardíaca mediante inteligencia artificial. 
        Combina <b>pdfplumber</b> para extracción de texto, <b>LLMs locales</b> (vLLM/Ollama) para interpretación de datos clínicos, un <b>algoritmo diagnóstico experto basado en puntuación clínica</b>, y <b>Machine Learning</b> (RandomForest/scikit-learn) para validación estadística, clasificando el riesgo (AL, ATTR, HVI o Bajo) según evidencia científica. 
        Acelera el diagnóstico precoz de esta enfermedad infradiagnosticada, mejorando el pronóstico del paciente.
        </div>
        """, unsafe_allow_html=True)

        st.caption(f"Backend IA: {llm.backend_activo or 'No detectado'}")
        st.caption(f"Modelo configurado: {llm.llm_model}")
        if llm.llm_provider_activo:
            st.caption(f"Proveedor activo: {llm.llm_provider_activo}")
        if llm.llm_endpoint_activo:
            st.caption(f"Endpoint activo: {llm.llm_endpoint_activo}")
        if not llm.client:
            st.info("Modo actual: Regex/Fallback (sin LLM activo)")
    
        st.divider()
        selected_tab = st.radio("Navegacion", tab_labels, index=1)
    return selected_tab, fondo_lateral_css
