import os
import re
import io
import csv
import json
import base64
import datetime
import time
import html
import zipfile
import tempfile
import hashlib
import hmac
import shutil
import glob
import webbrowser
from urllib.parse import quote_plus

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pdfplumber
from PIL import Image
from scipy import stats
from scipy.stats import norm
from sklearn.metrics import (
    confusion_matrix, roc_curve, auc, matthews_corrcoef, cohen_kappa_score,
    accuracy_score, balanced_accuracy_score, f1_score, fbeta_score,
    brier_score_loss, average_precision_score, precision_recall_curve,
    classification_report
)
import streamlit as st

# Esta página no necesita cargar el motor clínico.

def render():
    st.markdown("### 🧭 Guía Clínica y Algoritmo Diagnóstico")
    st.markdown("Comprende cómo funciona el algoritmo de diagnóstico de amiloidosis cardíaca")
    st.divider()

    # ========== SECCIÓN 1: RESUMEN VISUAL DEL ALGORITMO ==========
    st.subheader("🎯 ¿Cómo Funciona el Algoritmo?")

    st.info("""
    El algoritmo evalúa **múltiples dimensiones clínicas** y asigna puntos según la gravedad de cada hallazgo.
    Al final, la suma total de puntos determina el nivel de sospecha.
    """)

    # Diagrama de flujo visual
    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("#### 📥 ENTRADA")
        st.markdown("""
        **Datos Clínicos:**
        - Ecocardiograma
        - ECG
        - Biomarcadores
        - Resonancia Magnética
        - Historia Clínica
        - Red Flags
        """)

    with col2:
        st.markdown("#### ⚙️ PROCESAMIENTO")
        st.markdown("""
        **Sistema de Puntaje:**
        1. Asigna puntos a cada hallazgo
        2. Suma total de puntos
        3. Identifica patrones
        4. Diferencia AL vs ATTR
        5. Detecta confusores (HTA, EAo)
        """)

    with col3:
        st.markdown("#### 📤 SALIDA")
        st.markdown("""
        **Clasificación:**
        - 🔴 ALTA SOSPECHA (AL/ATTR)
        - 🟡 INTERMEDIA (Screening)
        - 🔵 HVI No Amiloide
        - 🟢 BAJA / Sano
        """)

    st.divider()

    # ========== SECCIÓN 2: TABLA DE PUNTAJES ==========
    st.subheader("📊 Sistema de Puntajes por Hallazgo")

    tab1, tab2, tab3, tab4 = st.tabs(["🫀 Cardiacos", "🧬 AL Específicos", "🦴 ATTR Específicos", "🔬 Imagen Avanzada"])

    with tab1:
        st.markdown("### Hallazgos Cardíacos")
        df_cardiacos = pd.DataFrame({
            'Hallazgo': [
                'IVS ≥ 14mm (hipertrofia)',
                'Voltaje < 0.5 mV (bajo voltaje)',
                'GLS reducido (< -16%)',
                'Apical Sparing',
                'BAV/Marcapasos',
                'Pseudoinfarto (ondas Q)',
                'Dilatación biauricular'
            ],
            'Puntos': [3, 4, 3, 5, 3, 2, 2],
            'Importancia': ['Media', 'Alta', 'Media', 'Muy Alta', 'Media', 'Baja', 'Baja']
        })
        st.dataframe(df_cardiacos, use_container_width=True, hide_index=True)

    with tab2:
        st.markdown("### Red Flags de Amiloidosis AL")
        df_al = pd.DataFrame({
            'Hallazgo': [
                'MGUS/Paraproteína',
                'Macroglosia',
                'Púrpura periorbital',
                'Síndrome nefrótico',
                'Hepatomegalia',
                'Polineuropatía',
                'Disautonomía'
            ],
            'Puntos': [6, 5, 4, 3, 2, 2, 2],
            'Importancia': ['Muy Alta', 'Muy Alta', 'Alta', 'Media', 'Baja', 'Baja', 'Baja']
        })
        st.dataframe(df_al, use_container_width=True, hide_index=True)
        st.warning("⚠️ La presencia de MGUS + cualquier hallazgo cardiaco → **ALTA SOSPECHA AL directa**")

    with tab3:
        st.markdown("### Red Flags de Amiloidosis ATTR")
        df_attr = pd.DataFrame({
            'Hallazgo': [
                'STC bilateral',
                'Estenosis lumbar',
                'Rotura de bíceps bilateral',
                'Tendinitis hombro',
                'Contractura Dupuytren',
                'Mutación TTR confirmada'
            ],
            'Puntos': [4, 3, 3, 2, 2, 10],
            'Importancia': ['Alta', 'Media', 'Media', 'Baja', 'Baja', 'Diagnóstico']
        })
        st.dataframe(df_attr, use_container_width=True, hide_index=True)
        st.info("💡 La **tríada clásica** (STC + Estenosis lumbar + Rotura bíceps) es casi patognomónica de ATTR")

    with tab4:
        st.markdown("### Hallazgos de Imagen Avanzada (RM Cardíaca)")
        df_rm = pd.DataFrame({
            'Hallazgo': [
                'ECV > 40%',
                'LGE subendocárdico/transmural',
                'T1 Mapping elevado',
                'NT-proBNP > 3000 pg/ml'
            ],
            'Puntos': [5, 5, 4, 4],
            'Importancia': ['Muy Alta', 'Muy Alta', 'Alta', 'Alta']
        })
        st.dataframe(df_rm, use_container_width=True, hide_index=True)
        st.success("✅ ECV > 40% es **casi patognomónico** de amiloidosis")

    st.divider()

    # ========== SECCIÓN 3: UMBRALES DE CLASIFICACIÓN ==========
    st.subheader("🎚️ Umbrales de Clasificación")

    col_u1, col_u2, col_u3, col_u4 = st.columns(4)

    with col_u1:
        st.metric("BAJA / Sano", "< 1 punto", help="Sin hallazgos significativos")

    with col_u2:
        st.metric("INTERMEDIA", "1-1 puntos", help="Requiere investigación adicional")

    with col_u3:
        st.metric("HVI No Amiloide", "2-5 puntos + HTA/EAo", help="Hipertrofia por sobrecarga")

    with col_u4:
        st.metric("ALTA SOSPECHA", "≥ 2 puntos", help="AL: 2+ con red flags | ATTR: 2+ con tríada")

    st.divider()

    # ========== SECCIÓN 4: EJEMPLOS PRÁCTICOS ==========
    st.subheader("📝 Ejemplos de Clasificación")

    ejemplo = st.selectbox(
        "Selecciona un ejemplo:",
        [
            "Ejemplo 1: ALTA SOSPECHA AL",
            "Ejemplo 2: ALTA PROBABILIDAD ATTR",
            "Ejemplo 3: HVI por HTA (No Amiloide)",
            "Ejemplo 4: INTERMEDIA (Zona Gris)"
        ]
    )

    if "Ejemplo 1" in ejemplo:
        st.markdown("### 🔴 Caso: ALTA SOSPECHA AL")
        st.markdown("""
        **Paciente:** Varón de 62 años con insuficiencia cardíaca de nueva aparición
    
        **Hallazgos:**
        - IVS 16mm → +3 puntos
        - Voltaje ECG 0.4 mV → +4 puntos
        - MGUS detectado → +6 puntos
        - NT-proBNP 4500 pg/ml → +4 puntos
    
        **Puntaje Total: 17 puntos**
    
        **Diagnóstico: 🔴 ALTA SOSPECHA AL**
    
        **Justificación:** MGUS + hallazgos cardíacos → clasificación directa como AL de alta sospecha
    
        **Siguiente paso:** Referir urgente a hematología + biopsia endomiocárdica
        """)

    elif "Ejemplo 2" in ejemplo:
        st.markdown("### 🟣 Caso: ALTA PROBABILIDAD ATTR")
        st.markdown("""
        **Paciente:** Varón de 78 años con historia de STC operado hace 10 años
    
        **Hallazgos:**
        - IVS 18mm → +3 puntos
        - STC bilateral previo → +4 puntos
        - Estenosis lumbar → +3 puntos
        - Apical sparing en eco → +5 puntos
        - Distribución concéntrica → Patrón ATTR
    
        **Puntaje Total: 15 puntos**
    
        **Diagnóstico: 🟣 ALTA PROBABILIDAD ATTR**
    
        **Justificación:** Tríada musculoesquelética + patrón ecocardiográfico típico de ATTR
    
        **Siguiente paso:** Gammagrafía ósea + genotipado TTR
        """)

    elif "Ejemplo 3" in ejemplo:
        st.markdown("### 🔵 Caso: HVI por HTA (No Amiloide)")
        st.markdown("""
        **Paciente:** Mujer de 55 años con HTA desde hace 20 años
    
        **Hallazgos:**
        - IVS 15mm → +3 puntos
        - HTA severa confirmada → Factor confusor
        - Voltaje normal (1.2 mV) → 0 puntos
        - Sin red flags sistémicos
        - NT-proBNP 150 pg/ml (normal)
    
        **Puntaje Total: 3 puntos + confusor HTA**
    
        **Diagnóstico: 🔵 HVI No Amiloide**
    
        **Justificación:** HVI explicada por HTA de larga data, sin características infiltrativas
    
        **Siguiente paso:** Control de HTA y seguimiento ecocardiográfico
        """)

    else:
        st.markdown("### 🟡 Caso: INTERMEDIA (Zona Gris)")
        st.markdown("""
        **Paciente:** Varón de 68 años con disnea progresiva
    
        **Hallazgos:**
        - IVS 14mm → +3 puntos
        - Voltaje 0.6 mV (límite) → 0 puntos
        - Sin red flags claros
        - NT-proBNP 800 pg/ml → +4 puntos
    
        **Puntaje Total: 7 puntos**
    
        **Diagnóstico: 🟡 INTERMEDIA (Screening)**
    
        **Justificación:** Hallazgos sugestivos pero no definitivos. Requiere más investigación
    
        **Siguiente paso:** RM cardíaca con realce tardío + cadenas ligeras en suero
        """)

    st.divider()

    # ========== SECCIÓN 5: DIFERENCIACIÓN AL vs ATTR ==========
    st.subheader("🔬 ¿Cómo Diferencia el Algoritmo AL vs ATTR?")

    col_dif1, col_dif2 = st.columns(2)

    with col_dif1:
        st.markdown("### 🔴 Patrón AL")
        st.markdown("""
        **Criterios de AL:**
        - ✅ MGUS/Paraproteína presente
        - ✅ Macroglosia, púrpura periorbital
        - ✅ Afección renal/hepática
        - ✅ NT-proBNP muy elevado (>3000)
        - ✅ Troponina elevada
        - ✅ Inicio más agudo
        - ✅ Edad: 50-70 años
    
        **Clasificación:** Si MGUS + cualquier hallazgo cardiaco → **AL directa**
        """)

    with col_dif2:
        st.markdown("### 🟣 Patrón ATTR")
        st.markdown("""
        **Criterios de ATTR:**
        - ✅ STC bilateral previo (años antes del Dx)
        - ✅ Tríada musculoesquelética
        - ✅ Ausencia de paraproteína
        - ✅ Patrón concéntrico en eco
        - ✅ Apical sparing marcado
        - ✅ Ausencia de FA (a pesar de ICC)
        - ✅ Edad: >70 años (ATTR-wt)
    
        **Clasificación:** Si tríada completa + edad avanzada → **ATTR alta probabilidad**
        """)

    st.divider()

    # ========== SECCIÓN 6: FACTORES CONFUSORES ==========
    st.subheader("⚠️ Factores Confusores (Diagnóstico Diferencial)")

    st.warning("""
    El algoritmo identifica **factores confusores** que pueden simular amiloidosis pero tienen otra causa:
    """)

    df_confusores = pd.DataFrame({
        'Factor Confusor': ['HTA severa', 'Estenosis aórtica', 'Insuficiencia renal crónica'],
        'Causa HVI': ['Sobrecarga de presión', 'Sobrecarga de presión', 'Retención de volumen + anemia'],
        'Cómo Diferenciarlo': [
            'HVI concéntrica simétrica, sin bajo voltaje',
            'Gradiente transvalvular elevado, soplo',
            'Creatinina elevada, anemia, hipervolemia'
        ]
    })
    st.dataframe(df_confusores, use_container_width=True, hide_index=True)

    st.info("""
    💡 **Regla del algoritmo:** Si hay HVI + confusor evidente + ausencia de red flags sistémicos → Clasifica como **HVI No Amiloide**
    """)
