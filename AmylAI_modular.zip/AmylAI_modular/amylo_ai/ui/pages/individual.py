import os
import re
import io
import csv
import json
import base64
import datetime
import time
import html
import zipfile
import tempfile
import hashlib
import hmac
import shutil
import glob
import webbrowser
from urllib.parse import quote_plus

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pdfplumber
from PIL import Image
from scipy import stats
from scipy.stats import norm
from sklearn.metrics import (
    confusion_matrix, roc_curve, auc, matthews_corrcoef, cohen_kappa_score,
    accuracy_score, balanced_accuracy_score, f1_score, fbeta_score,
    brier_score_loss, average_precision_score, precision_recall_curve,
    classification_report
)
import streamlit as st

from amylo_ai.clinical.algorithm import calcular_riesgo_experto
from amylo_ai.clinical.narrative import generar_explicacion_narrativa, generar_resumen_hallazgos
from amylo_ai.clinical.redflags import extraer_redflags_detectados
from amylo_ai.config import DEFAULT_DATA, FEATURES
from amylo_ai.data.repository import save_case_training
from amylo_ai.data.synthetic import generar_resumen_guardado
from amylo_ai.ml.model import calcular_ensamble_experto_ml_llm, normalizar_categoria_diagnostico
from amylo_ai.services.llm import motor_nlp_contextual
from amylo_ai.utils.parsing import safe_float

def render():
    st.markdown("### 🩺 Análisis Detallado de Caso Individual")
    st.info("Build UI activo: 2026-03-03 · LM complementaria + Desglose de Confianza", icon="🧩")
    st.markdown("Completa la información del paciente para un diagnóstico preciso")
    st.divider()

    # Layout principal
    left_col, right_col = st.columns([1.1, 1], gap="large")

    with left_col:
        st.markdown("## 📋 Recopilación de Datos")
    
        st.divider()
    
        # Step 1: Text Input
        with st.container(border=True):
            st.markdown("### 📝 Paso 1: Nota Clínica")
            st.markdown("*Copia la evolución clínica o informe médico completo*")
        
            texto = st.text_area(
                "Texto de la nota clínica",
                height=180,
                placeholder="Ejemplo:\n\nPaciente masculino 68 años con antecedente de...\nEcocardiograma: HVI 16mm con apical sparing...\nECG: bajo voltaje, BAV...",
                label_visibility="collapsed"
            )
        
            col_btn1, col_btn2 = st.columns(2, gap="small")
            with col_btn1:
                if st.button("✨ Analizar con IA (Máxima Precisión)", type="primary", use_container_width=True):
                    barra_ind = st.progress(0, text="0% | 🚀 Iniciando análisis...")
                    try:
                        barra_ind.progress(20, text="20% | 🧠 LLM analizando texto...")
                        # Usar motor LLM mejorado para máxima precisión
                        nlp = motor_nlp_contextual(texto)
                        barra_ind.progress(80, text="80% | 🛡️ Validando y procesando...")
                        time.sleep(0.3)
                        barra_ind.progress(100, text="100% | ✅ ¡Completado!")
                        time.sleep(0.3)
                        barra_ind.empty()
                    
                        modelo = nlp.get('_modelo', 'Desconocido')
                        st.success(f"✅ Analizado: {modelo}")
                    
                        if '_modelo' in nlp:
                            del nlp['_modelo']
                        st.session_state.form_data.update(nlp)
                        st.session_state.analisis_automatico = True  # Flag para mostrar resumen
                    except Exception as e:
                        st.error(f"Error: {e}")
        
            with col_btn2:
                if st.button("🔄 Limpiar", use_container_width=True):
                    st.session_state.form_data = DEFAULT_DATA.copy()
                    st.session_state.analisis_automatico = False
                    st.rerun()
    
        st.divider()
    
        # SECCIÓN DE HALLAZGOS EXTRAÍDOS AUTOMÁTICAMENTE
        if st.session_state.get('analisis_automatico', False):
            with st.container(border=True):
                st.markdown("### 📋 RESUMEN COMPLETO DE HALLAZGOS EXTRAÍDOS")
                st.markdown("*Todos los datos y red flags detectados. Revísalos antes de guardar*")
            
                # Extraer todos los red flags categorizados
                redflags_dict = extraer_redflags_detectados(st.session_state.form_data)
            
                # Crear tabla de TODOS los hallazgos extraídos
                hallazgos_tabla = []
            
                # 1. DATOS DEMOGRÁFICOS
                if st.session_state.form_data.get('edad'):
                    hallazgos_tabla.append({
                        'Categoría': '👤 Demográfico',
                        'Campo': 'Edad',
                        'Valor': f"{st.session_state.form_data['edad']} años",
                        'Tipo': '✓ Extraído'
                    })
            
                if st.session_state.form_data.get('sexo'):
                    sexo_desc = 'Masculino' if st.session_state.form_data['sexo'] == 'M' else 'Femenino' if st.session_state.form_data['sexo'] == 'F' else 'N/A'
                    hallazgos_tabla.append({
                        'Categoría': '👤 Demográfico',
                        'Campo': 'Sexo',
                        'Valor': sexo_desc,
                        'Tipo': '✓ Extraído'
                    })
            
                # 2. PARÁMETROS CARDIACOS ECOCARDIOGRAMA
                if st.session_state.form_data.get('ivs'):
                    hallazgos_tabla.append({
                        'Categoría': '🫀 Ecocardiografía',
                        'Campo': 'IVS (septo)',
                        'Valor': f"{st.session_state.form_data['ivs']} mm",
                        'Tipo': '✓ Extraído'
                    })
            
                if st.session_state.form_data.get('gls'):
                    hallazgos_tabla.append({
                        'Categoría': '🫀 Ecocardiografía',
                        'Campo': 'GLS (strain)',
                        'Valor': f"{st.session_state.form_data['gls']} %",
                        'Tipo': '✓ Extraído'
                    })
            
                if st.session_state.form_data.get('septum_posterior'):
                    hallazgos_tabla.append({
                        'Categoría': '🫀 Ecocardiografía',
                        'Campo': 'Pared Posterior',
                        'Valor': f"{st.session_state.form_data['septum_posterior']} mm",
                        'Tipo': '✓ Extraído'
                    })
            
                if st.session_state.form_data.get('derrame_pericardico'):
                    hallazgos_tabla.append({
                        'Categoría': '🫀 Ecocardiografía',
                        'Campo': 'Derrame Pericárdico',
                        'Valor': '✓ PRESENTE',
                        'Tipo': '✓ Detectado'
                    })
            
                # 3. PARÁMETROS ECG
                if st.session_state.form_data.get('volt'):
                    hallazgos_tabla.append({
                        'Categoría': '📟 ECG',
                        'Campo': 'Voltaje',
                        'Valor': f"{st.session_state.form_data['volt']} mV",
                        'Tipo': '✓ Extraído'
                    })
            
                # 4. BIOMARCADORES
                if st.session_state.form_data.get('nt_probnp'):
                    hallazgos_tabla.append({
                        'Categoría': '🧪 Biomarcadores',
                        'Campo': 'NT-proBNP',
                        'Valor': f"{st.session_state.form_data['nt_probnp']} pg/ml",
                        'Tipo': '✓ Extraído'
                    })
            
                if st.session_state.form_data.get('troponina'):
                    hallazgos_tabla.append({
                        'Categoría': '🧪 Biomarcadores',
                        'Campo': 'Troponina',
                        'Valor': '✓ Elevada',
                        'Tipo': '✓ Detectada'
                    })
            
                # 5. RESONANCIA MAGNÉTICA
                if st.session_state.form_data.get('lge_patron'):
                    hallazgos_tabla.append({
                        'Categoría': '🎯 Resonancia Cardíaca',
                        'Campo': 'Patrón LGE',
                        'Valor': st.session_state.form_data['lge_patron'].upper(),
                        'Tipo': '✓ Extraído'
                    })
            
                if st.session_state.form_data.get('ecv'):
                    hallazgos_tabla.append({
                        'Categoría': '🎯 Resonancia Cardíaca',
                        'Campo': 'ECV',
                        'Valor': f"{st.session_state.form_data['ecv']} %",
                        'Tipo': '✓ Extraído'
                    })
            
                if st.session_state.form_data.get('t1_mapping'):
                    hallazgos_tabla.append({
                        'Categoría': '🎯 Resonancia Cardíaca',
                        'Campo': 'T1 Mapping',
                        'Valor': '✓ Elevado',
                        'Tipo': '✓ Detectado'
                    })
            
                # 6. RED FLAGS - AL DIRECTO (Patognomónicos)
                if redflags_dict.get('AL_DIRECTO'):
                    for hallazgo in redflags_dict['AL_DIRECTO']:
                        hallazgos_tabla.append({
                            'Categoría': '🔴 AL Directo',
                            'Campo': hallazgo,
                            'Valor': '✓ PRESENTE',
                            'Tipo': '✓ Red Flag'
                        })
            
                # 7. RED FLAGS - AL SISTÉMICO
                if redflags_dict.get('AL_SISTEMICO'):
                    for hallazgo in redflags_dict['AL_SISTEMICO']:
                        hallazgos_tabla.append({
                            'Categoría': '🟠 AL Sistémico',
                            'Campo': hallazgo,
                            'Valor': '✓ PRESENTE',
                            'Tipo': '✓ Red Flag'
                        })
            
                # 8. RED FLAGS - ATTR CLÁSICO (Tríada musculoesquelética)
                if redflags_dict.get('ATTR_CLASICO'):
                    for hallazgo in redflags_dict['ATTR_CLASICO']:
                        hallazgos_tabla.append({
                            'Categoría': '🟡 ATTR Clásico',
                            'Campo': hallazgo,
                            'Valor': '✓ PRESENTE',
                            'Tipo': '✓ Red Flag'
                        })
            
                # 9. RED FLAGS - ATTR HEREDITARIA
                if redflags_dict.get('ATTR_HEREDITARIO'):
                    for hallazgo in redflags_dict['ATTR_HEREDITARIO']:
                        hallazgos_tabla.append({
                            'Categoría': '🟢 ATTR Hereditario',
                            'Campo': hallazgo,
                            'Valor': '✓ PRESENTE',
                            'Tipo': '✓ Red Flag'
                        })
            
                # 10. HALLAZGOS CARDIACOS ESPECÍFICOS
                if redflags_dict.get('HALLAZGOS_CARDIACOS'):
                    for hallazgo in redflags_dict['HALLAZGOS_CARDIACOS']:
                        hallazgos_tabla.append({
                            'Categoría': '💙 Cardiacos',
                            'Campo': hallazgo,
                            'Valor': '✓ PRESENTE',
                            'Tipo': '✓ Red Flag'
                        })
            
                # 11. PARÁMETROS CARDIACOS NUMÉRICOS
                if redflags_dict.get('PARAMETROS_CARDIACOS'):
                    for hallazgo in redflags_dict['PARAMETROS_CARDIACOS']:
                        hallazgos_tabla.append({
                            'Categoría': '📊 Parámetros',
                            'Campo': hallazgo,
                            'Valor': '⚠️ CRÍTICO',
                            'Tipo': '✓ Red Flag'
                        })
            
                # 12. FACTORES CONFUSORES
                if redflags_dict.get('FACTORES_CONFUSORES'):
                    for hallazgo in redflags_dict['FACTORES_CONFUSORES']:
                        hallazgos_tabla.append({
                            'Categoría': '⚙️ Confusores',
                            'Campo': hallazgo,
                            'Valor': '⚠️ PRESENTE',
                            'Tipo': '✓ Confosor'
                        })
            
                # Mostrar tabla si hay hallazgos
                if hallazgos_tabla:
                    df_hallazgos = pd.DataFrame(hallazgos_tabla)
                    st.dataframe(
                        df_hallazgos,
                        use_container_width=True,
                        hide_index=True,
                        column_config={
                            'Categoría': st.column_config.TextColumn(width='small'),
                            'Campo': st.column_config.TextColumn(width='medium'),
                            'Valor': st.column_config.TextColumn(width='small'),
                            'Tipo': st.column_config.TextColumn(width='small'),
                        }
                    )
                
                    # Resumen rápido de red flags
                    col_summary1, col_summary2, col_summary3, col_summary4 = st.columns(4)
                    with col_summary1:
                        st.metric("🔴 AL Directo", len(redflags_dict.get('AL_DIRECTO', [])))
                    with col_summary2:
                        st.metric("🟠 AL Sistémico", len(redflags_dict.get('AL_SISTEMICO', [])))
                    with col_summary3:
                        st.metric("🟡 ATTR Clásico", len(redflags_dict.get('ATTR_CLASICO', [])))
                    with col_summary4:
                        st.metric("⚙️ Confusores", len(redflags_dict.get('FACTORES_CONFUSORES', [])))
                
                    st.caption(f"📊 **Total: {len(hallazgos_tabla)} hallazgos extraídos** | **Red Flags: {redflags_dict['TOTAL_REDFLAGS']}** | Puedes editar los valores en las secciones del Paso 2 abajo")
                else:
                    st.info("ℹ️ No se detectaron hallazgos significativos en el texto")

    
        st.divider()
    
        # Step 2: Parameters
        with st.container(border=True):
            st.markdown("### 🫀 Paso 2: Parámetros Cardiacos")
            st.markdown("*Valores del ecocardiograma*")

            ivs_value = float(safe_float(st.session_state.form_data.get('ivs', 0.0)))
            volt_value = float(safe_float(st.session_state.form_data.get('volt', 0.0)))
            gls_value = float(safe_float(st.session_state.form_data.get('gls', -15.0)))
        
            p_col1, p_col2, p_col3 = st.columns(3, gap="small")
        
            with p_col1:
                st.session_state.form_data['ivs'] = st.number_input(
                    "IVS (mm)",
                    min_value=0.0, max_value=30.0, step=0.1,
                    value=ivs_value,
                    help="Grosor pared VI. Normal <11mm"
                )
        
            with p_col2:
                st.session_state.form_data['volt'] = st.number_input(
                    "Voltaje (mV)",
                    min_value=0.0, max_value=2.0, step=0.01,
                    value=volt_value,
                    help="Amplitud máxima QRS en ECG"
                )
        
            with p_col3:
                st.session_state.form_data['gls'] = st.number_input(
                    "GLS (%)",
                    min_value=-30.0, max_value=0.0, step=0.5,
                    value=gls_value,
                    help="Strain longitudinal global (-15% a -20% normal)"
                )
    
        st.divider()
    
        # Step 2.5: Biomarcadores
        st.markdown("### 🔬 Paso 2B: Biomarcadores Cardiacos")
        st.markdown("*Pista bioquímica crítica para diferenciar tipos de amiloidosis*")
    
        bm_col1, bm_col2 = st.columns(2, gap="small")
    
        with bm_col1:
            nt_probnp_value = float(st.session_state.form_data.get('nt_probnp', 0.0))
            nt_probnp_max = max(6000.0, nt_probnp_value)
            st.session_state.form_data['nt_probnp'] = st.number_input(
                "NT-proBNP (pg/ml)",
                min_value=0.0, max_value=nt_probnp_max, step=50.0,
                value=nt_probnp_value,
                help="Péptido natriurético. >3000: muy sugestivo amiloidosis. <400: descarta"
            )
    
        with bm_col2:
            st.session_state.form_data['troponina'] = st.checkbox(
                "🩸 Troponina Elevada Crónica",
                value=st.session_state.form_data.get('troponina', False),
                help="Sin infarto agudo → Infiltración miocárdica crónica"
            )
    
        st.divider()
    
        # Step 2.6: Resonancia Magnética
        st.markdown("### 🎯 Paso 2C: Resonancia Magnética Cardíaca")
        st.markdown("*Desempate definitivo cuando el Eco es dudoso*")
    
        rm1, rm2 = st.columns(2, gap="small")
    
        with rm1:
            lge_options = ["", "subendocardico", "transmural", "parcheado", "difuso", "null"]
            lge_current = st.session_state.form_data.get('lge_patron', '')
            lge_index = 0
            try:
                lge_index = lge_options.index(lge_current) if lge_current in lge_options else 0
            except (ValueError, IndexError):
                lge_index = 0
        
            st.session_state.form_data['lge_patron'] = st.selectbox(
                "Patrón LGE (Realce Tardío de Gadolinio)",
                options=lge_options,
                index=lge_index,
                help="Patrón subendocárdico/transmural = patognomónico amiloidosis"
            )
        
            st.session_state.form_data['ecv'] = st.number_input(
                "ECV - Volumen Extracelular (%)",
                min_value=0.0, max_value=100.0, step=1.0,
                value=st.session_state.form_data.get('ecv', 0.0),
                help="ECV > 40% = DIAGNÓSTICO. 30-40%: muy sugestivo"
            )
    
        with rm2:
            st.session_state.form_data['t1_mapping'] = st.checkbox(
                "T1 Mapping Elevado",
                value=st.session_state.form_data.get('t1_mapping', False),
                help="T1 nativo prolongado → Amiloidosis (esp. AL)"
            )
    
        st.divider()
    
        # Step 2.7: Demografía
        st.markdown("### 👤 Paso 2D: Datos Demográficos")
        st.markdown("*Contexto clínico (prior probability)*")
    
        dem1, dem2 = st.columns(2, gap="small")
    
        with dem1:
            st.session_state.form_data['edad'] = st.number_input(
                "Edad (años)",
                min_value=0, max_value=120, step=1,
                value=int(st.session_state.form_data.get('edad', 0)),
                help="ATTR wild-type es rara <60 años; AL puede ser más joven"
            )
    
        with dem2:
            sexo_options = ["", "M", "F"]
            sexo_current = st.session_state.form_data.get('sexo', '')
            sexo_index = 0
            try:
                sexo_index = sexo_options.index(sexo_current) if sexo_current in sexo_options else 0
            except (ValueError, IndexError):
                sexo_index = 0
        
            st.session_state.form_data['sexo'] = st.selectbox(
                "Sexo",
                options=sexo_options,
                index=sexo_index,
                help="ATTR wild-type: 80-90% hombres"
            )
    
        st.divider()
    
        # Step 2.8: Detalles Ecocardiográficos Finos
        st.markdown("### 🔍 Paso 2E: Detalles Ecocardiográficos")
        st.markdown("*Hallazgos ecocardiográficos adicionales*")
    
        eco_col1, eco_col2 = st.columns(2, gap="small")
    
        with eco_col1:
            st.session_state.form_data['derrame_pericardico'] = st.checkbox(
                "💧 Derrame Pericárdico",
                value=st.session_state.form_data.get('derrame_pericardico', False),
                help="Común en AL, raro en ATTR → Diferencia tipos"
            )
    
        with eco_col2:
            st.session_state.form_data['septum_posterior'] = st.number_input(
                "Grosor Tabique+Pared Post (mm)",
                min_value=0.0, max_value=30.0, step=0.5,
                value=st.session_state.form_data.get('septum_posterior', 0.0),
                help="Patrón concéntrico vs asimétrico. >13mm: HVI severa"
            )
    
        st.divider()
    
        # Step 3: Symptoms
        st.markdown("### ✓ Paso 3: Hallazgos Clínicos")
        st.markdown("*Selecciona los síntomas y signos presentes*")
    
        # AL Directo
        with st.expander("🚨 **AL DIRECTO** (¡DERIVACIÓN URGENTE si presente!)", expanded=True):
            st.markdown("*Criterios diagnósticos específicos de amiloidosis AL*")
            col_al_d = st.columns(3, gap="small")
            with col_al_d[0]:
                st.session_state.form_data['mgus'] = st.checkbox(
                    "💊 MGUS/Paraproteína",
                    value=st.session_state.form_data['mgus'],
                    help="Componente monoclonal de cadenas ligeras"
                )
            with col_al_d[1]:
                st.session_state.form_data['macro'] = st.checkbox(
                    "👅 Macroglosia",
                    value=st.session_state.form_data['macro'],
                    help="Lengua aumentada > 0.5cm"
                )
            with col_al_d[2]:
                st.session_state.form_data['purpura'] = st.checkbox(
                    "💜 Púrpura Periorbital",
                    value=st.session_state.form_data['purpura'],
                    help="Hematoma 'ojos de mapache' espontáneo"
                )
    
        # AL Sistémico
        with st.expander("🟠 **AL SISTÉMICO** (Manifestaciones secundarias)", expanded=True):
            st.markdown("*Hallazgos que sugieren nivel sistémico de afección*")
            col_al_s1 = st.columns(3, gap="small")
            with col_al_s1[0]:
                st.session_state.form_data['nefro'] = st.checkbox(
                    "🫘 Síndrome Nefrótico",
                    value=st.session_state.form_data['nefro'],
                    help="Proteinuria >3.5g/24h + edemas"
                )
                st.session_state.form_data['hepato'] = st.checkbox(
                    "🟤 Hepatomegalia",
                    value=st.session_state.form_data['hepato'],
                    help="Hígado aumentado por depósito amiloide"
                )
            with col_al_s1[1]:
                st.session_state.form_data['neuro_p'] = st.checkbox(
                    "⚡ Polineuropatía",
                    value=st.session_state.form_data['neuro_p'],
                    help="Parestesias distales simétricas"
                )
                st.session_state.form_data['fatiga'] = st.checkbox(
                    "😴 Fatiga Severa",
                    value=st.session_state.form_data['fatiga'],
                    help="Agotamiento extremo, presíncope"
                )
            with col_al_s1[2]:
                st.session_state.form_data['disauto'] = st.checkbox(
                    "🌀 Disautonomía",
                    value=st.session_state.form_data['disauto'],
                    help="Hipotensión ortostática, disfuncion GI"
                )
                st.session_state.form_data['piel_lesiones'] = st.checkbox(
                    "🩹 Lesiones Cutáneas",
                    value=st.session_state.form_data['piel_lesiones'],
                    help="Depósitos amiloides en piel"
                )
    
        # ATTR Clásico
        with st.expander("🟣 **ATTR CLÁSICO** (Síndrome Musculoesquelético)", expanded=True):
            st.markdown("*Tríada característica: STC bilateral + Estenosis lumbar + Rotura bíceps*")
            col_attr_p = st.columns(2, gap="small")
            with col_attr_p[0]:
                st.markdown("#### Hallazgos Primarios")
                st.session_state.form_data['stc'] = st.checkbox(
                    "🔴 STC Bilateral",
                    value=st.session_state.form_data['stc'],
                    help="Atrapamiento del nervio mediano bilateral"
                )
                st.session_state.form_data['lumbar'] = st.checkbox(
                    "🔴 Estenosis Lumbar",
                    value=st.session_state.form_data['lumbar'],
                    help="Claudicación neurógena, compresión radicular"
                )
                st.session_state.form_data['biceps'] = st.checkbox(
                    "🔴 Rotura de Bíceps",
                    value=st.session_state.form_data['biceps'],
                    help="Signo de Popeye - muy específico para ATTR"
                )
            with col_attr_p[1]:
                st.markdown("#### Hallazgos Adicionales")
                st.session_state.form_data['hombro'] = st.checkbox(
                    "Tendinitis Hombro",
                    value=st.session_state.form_data['hombro'],
                    help="Rotura del manguito rotador"
                )
                st.session_state.form_data['dupuytren'] = st.checkbox(
                    "Dupuytren",
                    value=st.session_state.form_data['dupuytren'],
                    help="Contractura fibrosa de mano - presente 5-25%"
                )
                st.session_state.form_data['artralgias'] = st.checkbox(
                    "Artralgias",
                    value=st.session_state.form_data['artralgias'],
                    help="Dolor articular crónico en grandes articulaciones"
                )
                st.session_state.form_data['fractura_vert'] = st.checkbox(
                    "Fractura Vertebral",
                    value=st.session_state.form_data['fractura_vert'],
                    help="Fragilidad ósea, colapso vertebral"
                )
                st.session_state.form_data['tendinitis_calcifica'] = st.checkbox(
                    "Tendinitis Cálcica",
                    value=st.session_state.form_data['tendinitis_calcifica'] if 'tendinitis_calcifica' in st.session_state.form_data else False,
                    help="Depósitos de calcio en tendones"
                )
    
        # Hallazgos Cardiacos
        with st.expander("💙 **HALLAZGOS CARDIACOS** (Ecocardiografía)", expanded=True):
            st.markdown("*Hallazgos específicos en imagen cardíaca*")
            col_card = st.columns(3, gap="small")
            with col_card[0]:
                st.session_state.form_data['apical_sparing'] = st.checkbox(
                    "Apical Sparing",
                    value=st.session_state.form_data['apical_sparing'],
                    help="Preservación del strain apical - patognomónico ATTR"
                )
                st.session_state.form_data['bajo_voltaje'] = st.checkbox(
                    "Bajo Voltaje",
                    value=st.session_state.form_data['bajo_voltaje'],
                    help="Voltaje bajo + HVI severa (paradójico)"
                )
            with col_card[1]:
                st.session_state.form_data['bav_mp'] = st.checkbox(
                    "BAV/Marcapasos",
                    value=st.session_state.form_data['bav_mp'],
                    help="Bloqueo AV completo - requiere marcapasos"
                )
                st.session_state.form_data['pseudo_q'] = st.checkbox(
                    "Pseudoinfarto",
                    value=st.session_state.form_data['pseudo_q'],
                    help="Ondas Q patológicas SIN infarto"
                )
            with col_card[2]:
                st.session_state.form_data['biatrial'] = st.checkbox(
                    "Dilatación Biauricular",
                    value=st.session_state.form_data['biatrial'],
                    help="Aurículas aumentadas de volumen"
                )
    
        # ATTR Hereditaria
        with st.expander("🧬 **ATTR HEREDITARIA** (Mutación TTR)"):
            st.markdown("*Requiere cribado familiar*")
            col_attr_h = st.columns(3, gap="small")
            with col_attr_h[0]:
                st.session_state.form_data['mutacion_ttr'] = st.checkbox(
                    "🔴 Mutación TTR",
                    value=st.session_state.form_data['mutacion_ttr'],
                    help="TTR confirmada genéticamente"
                )

    
        # Factores Confusores
        with st.expander("⚠️ **FACTORES CONFUSORES** (Elevan umbral HVI)"):
            st.markdown("*No causan amiloidosis pero dificultan diagnóstico*")
            col_conf = st.columns(3, gap="small")
            with col_conf[0]:
                st.session_state.form_data['confusor_hta'] = st.checkbox(
                    "HTA Severa",
                    value=st.session_state.form_data['confusor_hta'],
                    help="Hipertensión crónica"
                )
            with col_conf[1]:
                st.session_state.form_data['confusor_ao'] = st.checkbox(
                    "Estenosis Aórtica",
                    value=st.session_state.form_data['confusor_ao'],
                    help="Valvulopatía aórtica severa"
                )
            with col_conf[2]:
                st.session_state.form_data['confusor_irc'] = st.checkbox(
                    "Insuficiencia Renal",
                    value=st.session_state.form_data['confusor_irc'],
                    help="ERC, diálisis"
                )

    with right_col:
        st.markdown("## 🎯 Resultado del Análisis")

        # Ensamble Experto + ML + LLM con caché por hash de entrada
        payload_ensamble = {f: st.session_state.form_data.get(f, DEFAULT_DATA.get(f, 0)) for f in FEATURES}
        payload_hash = json.dumps(payload_ensamble, sort_keys=True, default=str)

        if (
            st.session_state.get("ensamble_payload_hash") != payload_hash
            or "ensamble_resultado" not in st.session_state
        ):
            res_ensamble = calcular_ensamble_experto_ml_llm(payload_ensamble, usar_llm=True)
            st.session_state.ensamble_payload_hash = payload_hash
            st.session_state.ensamble_resultado = res_ensamble

        res_ind = st.session_state.get("ensamble_resultado", calcular_riesgo_experto(st.session_state.form_data))

        componentes_res = res_ind.get('componentes_ensamble', {})
        comp_experto = componentes_res.get('experto', {}) if isinstance(componentes_res, dict) else {}
        comp_llm = componentes_res.get('llm', {}) if isinstance(componentes_res, dict) else {}

        decision_algoritmo = comp_experto.get('categoria') or normalizar_categoria_diagnostico(res_ind.get('nivel', ''))
        decision_lm = comp_llm.get('etiqueta') or comp_llm.get('categoria') or 'No disponible'
        decision_lm_categoria = normalizar_categoria_diagnostico(decision_lm) if decision_lm != 'No disponible' else ''
        hay_concordancia_alg_lm = bool(decision_lm_categoria) and (decision_algoritmo == decision_lm_categoria)
    
        # Obtener confianza (con fallback)
        confianza = res_ind.get('confianza_porcentaje', 50.0)
    
        # Guardar confianza e info del modelo en session para uso posterior (guardar caso)
        st.session_state.confianza_analisis = confianza
        st.session_state.nivel_diagnostico = res_ind.get('nivel', 'Desconocido')
    
        # Resultado principal con porcentaje
        st.markdown(f"""
        <div style="
            background: linear-gradient(135deg, {res_ind['color']}33 0%, {res_ind['color']}11 100%);
            border-left: 5px solid {res_ind['color']};
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        ">
            <h2 style="color: {res_ind['color']}; margin: 0 0 10px 0;">
                {res_ind['nivel']}
            </h2>
            <p style="font-size: 1.05em; color: #333; margin: 0;">
                <strong>{res_ind['msg']}</strong>
            </p>
            <div style="margin-top: 15px; display: flex; align-items: center; gap: 15px;">
                <div style="background-color: {res_ind['color']}20; padding: 10px 20px; border-radius: 8px; font-weight: bold; color: {res_ind['color']}; font-size: 1.1em;">
                    📊 Confianza IA: <span style="font-size: 1.3em;">{confianza:.1f}%</span>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("### 🤝 Decisión Complementaria LM")
        col_dec1, col_dec2, col_dec3 = st.columns(3)
        with col_dec1:
            st.metric("Algoritmo (Experto)", decision_algoritmo)
        with col_dec2:
            st.metric("LM (complementaria)", decision_lm)
        with col_dec3:
            st.metric("Concordancia", "✅ Sí" if hay_concordancia_alg_lm else "⚠️ No")

        st.session_state.decision_algoritmo = decision_algoritmo
        st.session_state.decision_lm = decision_lm
        st.session_state.concordancia_alg_lm = hay_concordancia_alg_lm
    
        # Acción recomendada
        if 'accion' in res_ind:
            st.markdown(f"""
            <div style="
                background-color: #fff3cd;
                border-left: 4px solid #ffc107;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 20px;
            ">
                <strong>👉 Acción Recomendada:</strong><br>
                {res_ind['accion']}
            </div>
            """, unsafe_allow_html=True)
    
        # Score
        st.divider()
        st.markdown("### 📊 Puntuación Detallada")
    
        col_score1, col_score2, col_score3 = st.columns(3)
        with col_score1:
            st.metric(
                "Score Total",
                f"{res_ind['score']} pts",
                help="Suma ponderada de hallazgos"
            )
        with col_score2:
            st.metric(
                "Nivel de Riesgo",
                res_ind['nivel'].split(' ')[0],
                help="Categoría diagnóstica"
            )
        with col_score3:
            st.metric(
                "Confianza IA 🤖",
                f"{confianza:.1f}%",
                help="Porcentaje de confianza del algoritmo de machine learning"
            )

        # Desglose numérico de confianza
        conf_experto_num = float(safe_float(componentes_res.get('experto', {}).get('confianza', 0.0)))
        fuerza_consenso_num = float(safe_float(res_ind.get('fuerza_consenso', 0.0)))
        confianza_ponderada = (0.6 * conf_experto_num) + (0.4 * fuerza_consenso_num)
        confianza_limitada = max(40.0, min(99.0, confianza_ponderada))

        st.markdown("### 🔢 Desglose de Confianza")
        col_conf1, col_conf2, col_conf3, col_conf4 = st.columns(4)
        with col_conf1:
            st.metric("Conf. Experto", f"{conf_experto_num:.1f}%")
        with col_conf2:
            st.metric("Consenso", f"{fuerza_consenso_num:.1f}%")
        with col_conf3:
            st.metric("0.6E + 0.4C", f"{confianza_ponderada:.1f}%")
        with col_conf4:
            st.metric("Final mostrada", f"{confianza_limitada:.1f}%")

        st.caption("Fórmula: confianza_final = max(40, min(99, 0.6×conf_experto + 0.4×fuerza_consenso))")

        # Desglose del ensamble (Experto + ML + LLM)
        componentes = res_ind.get('componentes_ensamble', {})
        votos = res_ind.get('votos_ensamble', {})
        if componentes:
            st.markdown("### 🧠 Ensamble Diagnóstico")

            filas_componentes = []
            for nombre in ['experto', 'ml', 'llm']:
                comp = componentes.get(nombre, {})
                filas_componentes.append({
                    'Componente': nombre.upper(),
                    'Peso': round(float(comp.get('peso', 0.0)), 2),
                    'Categoría': comp.get('categoria') or 'N/D',
                })

            st.dataframe(
                pd.DataFrame(filas_componentes),
                use_container_width=True,
                hide_index=True
            )

            if votos:
                filas_votos = [
                    {'Categoría': cat, 'Voto Normalizado': round(float(valor) * 100.0, 1)}
                    for cat, valor in sorted(votos.items(), key=lambda x: x[1], reverse=True)
                ]
                st.dataframe(
                    pd.DataFrame(filas_votos),
                    use_container_width=True,
                    hide_index=True
                )
                st.caption(
                    f"Consenso final: {res_ind.get('categoria_ensamble', res_ind.get('nivel', 'N/D'))} "
                    f"({res_ind.get('fuerza_consenso', 0.0)}%)"
                )
    
        # Hallazgos encontrados
        st.markdown("### 📋 Hallazgos Detectados")
        if res_ind['hallazgos']:
            for h in res_ind['hallazgos']:
                st.markdown(f"✓ {h}", unsafe_allow_html=True)
        else:
            st.info("Sin hallazgos significativos detectados", icon="ℹ️")
    
        st.divider()
    
        # Explicación narrativa
        st.markdown("### 🤖 Análisis Clínico")
        explicacion = generar_explicacion_narrativa(st.session_state.form_data, res_ind)
        st.markdown(f"""
        <div style="
            background-color: #f0f4f8;
            border-radius: 8px;
            padding: 15px;
            border-left: 4px solid #2196F3;
            font-size: 0.95em;
            line-height: 1.6;
        ">
            {explicacion}
        </div>
        """, unsafe_allow_html=True)
    
        st.divider()
    
        # RESUMEN DE HALLAZGOS
        st.markdown("### 📑 Resumen Clínico de Hallazgos")
    
        col_btn_resumen1, col_btn_resumen2 = st.columns(2, gap="small")
        with col_btn_resumen1:
            if st.button("📋 Generar Resumen Completo", type="primary", use_container_width=True):
                resumen_hallazgos = generar_resumen_hallazgos(st.session_state.form_data, res_ind)
                st.session_state.resumen_generado = resumen_hallazgos
    
        with col_btn_resumen2:
            if st.button("📋 Limpiar Resumen", use_container_width=True):
                st.session_state.resumen_generado = None
                st.rerun()
    
        # Mostrar resumen si está disponible
        if 'resumen_generado' in st.session_state and st.session_state.resumen_generado:
            st.markdown(f"""
            <div style="
                background-color: #fafafa;
                border-radius: 8px;
                padding: 20px;
                border-left: 5px solid #4CAF50;
                font-size: 0.95em;
                line-height: 1.7;
                max-height: 600px;
                overflow-y: auto;
            ">
                {st.session_state.resumen_generado}
            </div>
            """, unsafe_allow_html=True)
        
            # Botones de acción
            col_copy1, col_copy2 = st.columns(2, gap="small")
        
            with col_copy1:
                # Limpiar markdown para descargar
                texto_descargar = st.session_state.resumen_generado
                texto_descargar = texto_descargar.replace("**", "").replace("###", "")
                texto_descargar = texto_descargar.replace("### ", "").replace("##", "")
            
                st.download_button(
                    label="📥 Descargar como TXT",
                    data=texto_descargar,
                    file_name=f"resumen_hallazgos_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                    mime="text/plain",
                    use_container_width=True,
                    key="download_individual_case"
                )
        
            with col_copy2:
                if st.button("📋 Copiar a Portapapeles", use_container_width=True):
                    st.code(st.session_state.resumen_generado, language="markdown")
    
        st.divider()
    
        # Guardar caso
        st.markdown("### 💾 Guardar Caso para Entrenamiento")
        st.markdown("*Revisa todos los hallazgos que se guardarán en la base de datos*")
    
        # TABLA RESUMEN DE TODOS LOS HALLAZGOS A GUARDAR
        with st.expander("📊 VISTA PREVIA: Todos los hallazgos a guardar", expanded=True):
            # Crear tabla estilo inventario
            datos_a_guardar = []
        
            # Sección: Identificación
            datos_a_guardar.append({'Sección': '👤 IDENTIFICACIÓN', 'Campo': 'NHC', 'Valor': st.session_state.form_data.get('nhc', '—'), 'Estado': '✓'})
        
            # Sección: Demografía
            edad = st.session_state.form_data.get('edad', 0)
            datos_a_guardar.append({'Sección': '👤 DEMOGRAFÍA', 'Campo': 'Edad', 'Valor': f"{edad} años" if edad else '—', 'Estado': '✓ Extraído' if edad else '—'})
        
            sexo_val = st.session_state.form_data.get('sexo', '')
            sexo_desc = 'Masculino' if sexo_val == 'M' else 'Femenino' if sexo_val == 'F' else '—'
            datos_a_guardar.append({'Sección': '👤 DEMOGRAFÍA', 'Campo': 'Sexo', 'Valor': sexo_desc, 'Estado': '✓ Extraído' if sexo_val else '—'})
        
            # Sección: Ecocardiografía
            ivs = st.session_state.form_data.get('ivs', 0)
            datos_a_guardar.append({'Sección': '🫀 ECOCARDIOGRAFÍA', 'Campo': 'IVS/Septo', 'Valor': f"{ivs} mm" if ivs else '—', 'Estado': '✓ Extraído' if ivs else '—'})
        
            gls = st.session_state.form_data.get('gls', 0)
            datos_a_guardar.append({'Sección': '🫀 ECOCARDIOGRAFÍA', 'Campo': 'GLS/Strain', 'Valor': f"{gls} %" if gls else '—', 'Estado': '✓ Extraído' if gls else '—'})
        
            septum_post = st.session_state.form_data.get('septum_posterior', 0)
            datos_a_guardar.append({'Sección': '🫀 ECOCARDIOGRAFÍA', 'Campo': 'Pared Posterior', 'Valor': f"{septum_post} mm" if septum_post else '—', 'Estado': '✓ Extraído' if septum_post else '—'})
        
            derrame = st.session_state.form_data.get('derrame_pericardico', False)
            datos_a_guardar.append({'Sección': '🫀 ECOCARDIOGRAFÍA', 'Campo': 'Derrame Pericárdico', 'Valor': '✓ SÍ' if derrame else 'NO', 'Estado': '✓ Detectado' if derrame else '—'})
        
            # Sección: Electrocardiografía
            volt = st.session_state.form_data.get('volt', 0)
            datos_a_guardar.append({'Sección': '📊 ECG', 'Campo': 'Voltaje', 'Valor': f"{volt} mV" if volt else '—', 'Estado': '✓ Extraído' if volt else '—'})
        
            bav_mp = st.session_state.form_data.get('bav_mp', False)
            datos_a_guardar.append({'Sección': '📊 ECG', 'Campo': 'BAV/Marcapasos', 'Valor': '✓ SÍ' if bav_mp else 'NO', 'Estado': '✓ Detectado' if bav_mp else '—'})
        
            bajo_volt = st.session_state.form_data.get('bajo_voltaje', False)
            datos_a_guardar.append({'Sección': '📊 ECG', 'Campo': 'Bajo Voltaje', 'Valor': '✓ SÍ' if bajo_volt else 'NO', 'Estado': '✓ Detectado' if bajo_volt else '—'})
        
            # Sección: Biomarcadores
            nt_probnp = st.session_state.form_data.get('nt_probnp', 0)
            datos_a_guardar.append({'Sección': '🧪 BIOMARCADORES', 'Campo': 'NT-proBNP', 'Valor': f"{nt_probnp} pg/ml" if nt_probnp else '—', 'Estado': '✓ Extraído' if nt_probnp else '—'})
        
            troponina = st.session_state.form_data.get('troponina', False)
            datos_a_guardar.append({'Sección': '🧪 BIOMARCADORES', 'Campo': 'Troponina Elevada', 'Valor': '✓ SÍ' if troponina else 'NO', 'Estado': '✓ Detectado' if troponina else '—'})
        
            # Sección: Resonancia Magnética Cardíaca
            lge = st.session_state.form_data.get('lge_patron', '')
            datos_a_guardar.append({'Sección': '🎯 RESONANCIA CARDÍACA', 'Campo': 'Patrón LGE', 'Valor': lge.upper() if lge else '—', 'Estado': '✓ Extraído' if lge else '—'})
        
            ecv = st.session_state.form_data.get('ecv', 0)
            datos_a_guardar.append({'Sección': '🎯 RESONANCIA CARDÍACA', 'Campo': 'ECV (%)', 'Valor': f"{ecv} %" if ecv else '—', 'Estado': '✓ Extraído' if ecv else '—'})
        
            t1_map = st.session_state.form_data.get('t1_mapping', False)
            datos_a_guardar.append({'Sección': '🎯 RESONANCIA CARDÍACA', 'Campo': 'T1 Mapping Elevado', 'Valor': '✓ SÍ' if t1_map else 'NO', 'Estado': '✓ Detectado' if t1_map else '—'})
        
            # Extender tabla con red flags
            redflags_dict = extraer_redflags_detectados(st.session_state.form_data)
        
            # Mostrar tabla
            df_guardar = pd.DataFrame(datos_a_guardar)
            st.dataframe(
                df_guardar,
                use_container_width=True,
                hide_index=True,
                column_config={
                    'Sección': st.column_config.TextColumn(width='small'),
                    'Campo': st.column_config.TextColumn(width='medium'),
                    'Valor': st.column_config.TextColumn(width='medium'),
                    'Estado': st.column_config.TextColumn(width='small'),
                }
            )
        
            # Resumen comprimido de red flags
            if redflags_dict["TOTAL_REDFLAGS"] > 0:
                st.markdown(f"**🚩 Red Flags Adicionales: {redflags_dict['TOTAL_REDFLAGS']}**")
                todos_redflags = (
                    redflags_dict.get("AL_DIRECTO", []) +
                    redflags_dict.get("AL_SISTEMICO", []) +
                    redflags_dict.get("ATTR_CLASICO", []) +
                    redflags_dict.get("ATTR_HEREDITARIO", []) +
                    redflags_dict.get("HALLAZGOS_CARDIACOS", []) +
                    redflags_dict.get("FACTORES_CONFUSORES", [])
                )
                st.write(", ".join(todos_redflags[:10]) + ("..." if len(todos_redflags) > 10 else ""))
    
        # Extraer red flags para mostrar y guardar (segunda vez)
        redflags_dict = extraer_redflags_detectados(st.session_state.form_data)
    
        # Mostrar contexto adicional de red flags si están disponibles
        if redflags_dict["TOTAL_REDFLAGS"] > 0:
            with st.expander("🔍 Detalles de Red Flags por Categoría"):
                col_rf1, col_rf2 = st.columns(2)
            
                with col_rf1:
                    st.metric("Total de Red Flags Detectados", redflags_dict["TOTAL_REDFLAGS"])
            
                with col_rf2:
                    st.metric("Total de Features a Guardar", len(FEATURES))
            
                # Mostrar red flags por categoría
                if redflags_dict["AL_DIRECTO"]:
                    st.markdown("**🚨 AL DIRECTO** (Amiloidosis AL)")
                    for rf in redflags_dict["AL_DIRECTO"]:
                        st.write(f"✓ {rf}")
            
                if redflags_dict["AL_SISTEMICO"]:
                    st.markdown("**🟠 AL SISTÉMICO**")
                    for rf in redflags_dict["AL_SISTEMICO"]:
                        st.write(f"✓ {rf}")
            
                if redflags_dict["ATTR_CLASICO"]:
                    st.markdown("**🟣 ATTR CLÁSICO** (Musculoesquelético)")
                    for rf in redflags_dict["ATTR_CLASICO"]:
                        st.write(f"✓ {rf}")
            
                if redflags_dict["ATTR_HEREDITARIO"]:
                    st.markdown("**🧬 ATTR HEREDITARIA**")
                    for rf in redflags_dict["ATTR_HEREDITARIO"]:
                        st.write(f"✓ {rf}")
            
                if redflags_dict["HALLAZGOS_CARDIACOS"]:
                    st.markdown("**💙 HALLAZGOS CARDIACOS**")
                    for rf in redflags_dict["HALLAZGOS_CARDIACOS"]:
                        st.write(f"✓ {rf}")
            
                if redflags_dict["PARAMETROS_CARDIACOS"]:
                    st.markdown("**📈 PARÁMETROS CARDIACOS**")
                    for rf in redflags_dict["PARAMETROS_CARDIACOS"]:
                        st.write(f"✓ {rf}")
            
                if redflags_dict["FACTORES_CONFUSORES"]:
                    st.markdown("**⚠️ FACTORES CONFUSORES**")
                    for rf in redflags_dict["FACTORES_CONFUSORES"]:
                        st.write(f"✓ {rf}")
        else:
            st.info("ℹ️ Sin hallazgos detectados - se guardará como caso sin red flags", icon="ℹ️")
    
        st.divider()
    
        diag_final = st.selectbox(
            "Diagnóstico Real (según confirmación posterior):",
            ["---", "ATTR", "AL", "HVI-HTA", "Sano"],
            help="Selecciona el diagnóstico confirmado para entrenar el modelo"
        )
    
        if st.button("💾 Guardar Caso en Base de Datos", type="primary", use_container_width=True):
            if diag_final != "---":
                # Obtener confianza y nivel guardados durante el análisis
                confianza_guardada = st.session_state.get('confianza_analisis', 0.0)
                nivel_guardado = st.session_state.get('nivel_diagnostico', '')
                decision_alg_guardada = st.session_state.get('decision_algoritmo', nivel_guardado)
                decision_lm_guardada = st.session_state.get('decision_lm', 'No disponible')
                concordancia_guardada = st.session_state.get('concordancia_alg_lm', False)

                trazabilidad_modelo = (
                    f"Ensamble E+ML+LM | Alg={decision_alg_guardada} | "
                    f"LM={decision_lm_guardada} | Concordancia={'SI' if concordancia_guardada else 'NO'}"
                )
            
                resultado = save_case_training(
                    st.session_state.form_data, 
                    diag_final,
                    confianza_ia=confianza_guardada,
                    modelo_usado=trazabilidad_modelo
                )
                if resultado != "ERROR":
                    # Mostrar resumen completo de lo guardado
                    resumen = generar_resumen_guardado(resultado, st.session_state.form_data, diag_final)
                    st.markdown(resumen)
                
                    # Información de éxito con detalles
                    col_exito1, col_exito2 = st.columns(2)
                    with col_exito1:
                        st.metric("Caso Guardado", f"#{resultado}")
                    with col_exito2:
                        st.metric("Confianza del Modelo", f"{confianza_guardada:.1f}%")
                
                    st.success(f"✅ **CASO #{resultado} GUARDADO EXITOSAMENTE**\n\nDiagnóstico: **{diag_final}** | Red Flags: **{redflags_dict['TOTAL_REDFLAGS']}** | Features: **{len(FEATURES)}**")
                    time.sleep(2)
                else:
                    st.error("❌ No se pudo guardar. Posibles causas:\n- El archivo CSV está abierto en Excel\n- No hay permisos de escritura\n- Espacio en disco insuficiente\n\nIntenta nuevamente después de cerrar el archivo.")
            else:
                st.warning("⚠️ Selecciona un diagnóstico válido para guardar el caso")

    # ================================================================
    # TAB 3: GUÍA CLÍNICA 
    # ================================================================
