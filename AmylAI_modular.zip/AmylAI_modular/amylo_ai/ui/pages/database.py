import os
import re
import io
import csv
import json
import base64
import datetime
import time
import html
import zipfile
import tempfile
import hashlib
import hmac
import shutil
import glob
import webbrowser
from urllib.parse import quote_plus

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pdfplumber
from PIL import Image
from scipy import stats
from scipy.stats import norm
from sklearn.metrics import (
    confusion_matrix, roc_curve, auc, matthews_corrcoef, cohen_kappa_score,
    accuracy_score, balanced_accuracy_score, f1_score, fbeta_score,
    brier_score_loss, average_precision_score, precision_recall_curve,
    classification_report
)
import streamlit as st

from amylo_ai.config import BASE_DIR, DB_FILE, DEFAULT_DATA, FEATURES
from amylo_ai.ml.model import calcular_ensamble_experto_ml_llm

def render():
    st.header("📊 Base de Datos de Entrenamiento")

    cargar_db = st.checkbox("Cargar base de datos", value=False)
    if not cargar_db:
        st.info("Base de datos no cargada para mejorar rendimiento. Activa la opcion para abrirla.")
        st.stop()

    ruta_abs = os.path.join(BASE_DIR, DB_FILE)

    if not os.path.isfile(ruta_abs):
        st.error(f"No se encuentra {DB_FILE} en la carpeta")
        st.stop()

    archivo_usado = DB_FILE

    if not os.path.isfile(ruta_abs):
        st.error(f"No se encuentra {DB_FILE} ni el backup en la carpeta")
        st.stop()

    # Cargar datos para estadísticas
    df_para_stats = pd.read_csv(ruta_abs)
    total_casos = len(df_para_stats)
    ultima_fecha = df_para_stats['fecha'].max() if 'fecha' in df_para_stats.columns else 'N/A'

    # Métricas superiores
    col_db1, col_db2, col_db3 = st.columns(3)
    col_db1.metric("Total de Casos", total_casos)
    col_db2.metric("Última Actualización", ultima_fecha)
    col_db3.metric("Archivo Usado", archivo_usado)

    st.divider()

    if total_casos > 0:
        with st.spinner("Cargando base de datos..."):
            # 1. Cargar datos brutos desde el archivo seleccionado (backup o principal)
            df_full = pd.read_csv(ruta_abs)
            # Asegurar que tenga todas las columnas necesarias
            for col in FEATURES:
                if col not in df_full.columns:
                    df_full[col] = None
            # Crear columnas de resultados si no existen
            if 'Diagnóstico Algoritmo' not in df_full.columns:
                df_full['Diagnóstico Algoritmo'] = ''
            if 'Hallazgos Detectados' not in df_full.columns:
                df_full['Hallazgos Detectados'] = ''
            if 'confianza_ia' not in df_full.columns:
                df_full['confianza_ia'] = ''
            if 'nhc' not in df_full.columns:
                df_full['nhc'] = ''
    
        # 2. CALCULAR DIAGNÓSTICO Y HALLAZGOS (EN TIEMPO REAL)
        # -------------------------------------------------------------------------
        # AQUÍ ESTÁ EL CAMBIO CLAVE:
        # Usamos df_full (el original) para calcular las columnas, así se guardarán.
        # -------------------------------------------------------------------------
    
        def aplicar_algoritmo(row):
            # Mapeo de nombres de columnas CSV a nombres esperados por el algoritmo
            mapeo_columnas = {
                'IVS (mm)': 'ivs',
                'Voltaje (mV)': 'volt',
                'GLS (%)': 'gls',
                'NT-proBNP (pg/ml)': 'nt_probnp',
                'Troponina elevada': 'troponina',
                'Troponina elevada crónica baja (ATTR)': 'troponina_cronica',
                'Patrón LGE': 'lge_patron',
                'ECV (%)': 'ecv',
                'T1 Mapping': 't1_mapping',
                'Hiperrealce subepicárdico (ATTR-v)': 'hiperrealce_subepicardico',
                'Edad': 'edad',
                'Sexo': 'sexo',
                'Derrame pericárdico': 'derrame_pericardico',
                'Pared posterior (mm)': 'septum_posterior',
                'Distribución concéntrica (ATTR)': 'distribucion_concentrica',
                'RV engrosado (ATTR)': 'rv_engrosado',
                'Aorta pequeña/normal relativa (ATTR)': 'aorta_pequena',
                'Ausencia de FA (ATTR vs HTA)': 'ausencia_fa',
                'STC bilateral': 'stc',
                'Rotura bíceps': 'biceps',
                'Estenosis lumbar': 'lumbar',
                'Tendinitis hombro': 'hombro',
                'Dupuytren': 'dupuytren',
                'Artralgias': 'artralgias',
                'Fractura vertebral': 'fractura_vert',
                'Tendinitis cálcica': 'tendinitis_calcifica',
                'Macroglosia': 'macro',
                'Púrpura periorbital': 'purpura',
                'MGUS/Paraproteína': 'mgus',
                'Síndrome nefrótico': 'nefro',
                'Polineuropatía': 'neuro_p',
                'Disautonomía': 'disauto',
                'Hepatomegalia': 'hepato',
                'Fatiga severa': 'fatiga',
                'Lesiones cutáneas': 'piel_lesiones',
                'Apical sparing': 'apical_sparing',
                'Dilatación biauricular': 'biatrial',
                'BAV/Marcapasos': 'bav_mp',
                'Pseudoinfarto': 'pseudo_q',
                'Bajo voltaje paradójico': 'bajo_voltaje',
                'Mutación TTR': 'mutacion_ttr',
                'Confusor HTA': 'confusor_hta',
                'Confusor EAo': 'confusor_ao',
                'Confusor IRC': 'confusor_irc'
            }
        
            # Convertimos la fila a diccionario
            d = DEFAULT_DATA.copy()
            row_dict = row.to_dict()
        
            # Contador de valores mapeados para debugging
            valores_mapeados = 0
        
            # Aplicar mapeo de columnas
            for nombre_csv, nombre_algoritmo in mapeo_columnas.items():
                if nombre_csv in row_dict:
                    valor = row_dict[nombre_csv]
                    # Convertir valores booleanos y numéricos
                    if nombre_algoritmo in DEFAULT_DATA:
                        if isinstance(DEFAULT_DATA[nombre_algoritmo], bool):
                            # Convertir a booleano
                            if isinstance(valor, bool):
                                d[nombre_algoritmo] = valor
                                valores_mapeados += 1
                            elif isinstance(valor, str):
                                d[nombre_algoritmo] = valor.lower() in ['true', '1', 'sí', 's', 'yes', 'v']
                                if d[nombre_algoritmo]:
                                    valores_mapeados += 1
                            elif isinstance(valor, (int, float)):
                                d[nombre_algoritmo] = bool(valor)
                                if d[nombre_algoritmo]:
                                    valores_mapeados += 1
                            else:
                                d[nombre_algoritmo] = False
                        elif isinstance(DEFAULT_DATA[nombre_algoritmo], (int, float)):
                            # Convertir a número, manteniendo como string si está vacío
                            try:
                                if pd.isna(valor) or valor == '' or valor is None:
                                    d[nombre_algoritmo] = DEFAULT_DATA[nombre_algoritmo]
                                else:
                                    d[nombre_algoritmo] = float(valor)
                                    valores_mapeados += 1
                            except (ValueError, TypeError):
                                d[nombre_algoritmo] = DEFAULT_DATA[nombre_algoritmo]
                        else:
                            # String o valor directo
                            if pd.notna(valor) and valor != '':
                                d[nombre_algoritmo] = valor
                                valores_mapeados += 1
                            else:
                                d[nombre_algoritmo] = DEFAULT_DATA[nombre_algoritmo]
        
            # Asegurar valores numéricos válidos
            for key in ['ivs', 'volt', 'gls', 'nt_probnp', 'ecv', 'septum_posterior', 'edad']:
                if key in d and (pd.isna(d[key]) or d[key] is None):
                    d[key] = 0.0 if isinstance(d[key], float) else 0
        
            try:
                # Use default thresholds for Base de Datos calculation
                res = calcular_ensamble_experto_ml_llm(d, usar_llm=False)
                nivel = res.get('nivel', '')
                hall = ", ".join(res.get('hallazgos', []))
            
                # Si no hay nivel después del cálculo, agregar info de debug
                if not nivel:
                    return pd.Series(["ERROR", f"Sin diagnóstico (mapeados: {valores_mapeados} valores)"])
            
                return pd.Series([nivel, hall])
            except Exception as e:
                return pd.Series(["ERROR", f"Error: {str(e)[:50]}"])

        if not df_full.empty:
            did_update = False
            if 'Diagnóstico Algoritmo' not in df_full.columns:
                df_full['Diagnóstico Algoritmo'] = ''
            if 'Hallazgos Detectados' not in df_full.columns:
                df_full['Hallazgos Detectados'] = ''

            # Asegurar que existan todas las variables necesarias
            missing_features = [f for f in FEATURES if f not in df_full.columns]
            if missing_features:
                for f in missing_features:
                    df_full[f] = DEFAULT_DATA.get(f, 0)
                st.warning("Faltaban variables en la base. Se completaron con valores por defecto para calcular el algoritmo.")

            # Botones de control
            col_btn1, col_btn2 = st.columns(2)
            with col_btn1:
                calcular_inicial = st.button("▶️ Calcular Algoritmo", type="primary")
            with col_btn2:
                recalcular_todo = st.button("🔄 Recalcular TODOS", type="secondary")

            def _is_empty(val: Any) -> bool:
                if val is None:
                    return True
                if isinstance(val, float) and np.isnan(val):
                    return True
                s = str(val).strip().lower()
                return s in ['', 'nan', 'none', 'null']

            # Calcular solo filas faltantes (o todo si se solicita)
            mask_diag = df_full['Diagnóstico Algoritmo'].apply(_is_empty)
            mask_hall = df_full['Hallazgos Detectados'].apply(_is_empty)
            mask_calc = mask_diag | mask_hall
        
            # Si se presiona el botón de calcular inicial, procesar solo filas vacías
            # Si se presiona recalcular todo, procesar todas las filas
            if calcular_inicial:
                # Solo calcular donde hay valores vacíos
                pass  # mask_calc ya está definido
            elif recalcular_todo:
                mask_calc = pd.Series([True] * len(df_full), index=df_full.index)
        
            if calcular_inicial or recalcular_todo:
                if mask_calc.any():
                    calc_count = int(mask_calc.sum())
                    try:
                        # Asegurar que las columnas tengan tipo correcto (object para strings)
                        df_full['Diagnóstico Algoritmo'] = df_full['Diagnóstico Algoritmo'].astype('object')
                        df_full['Hallazgos Detectados'] = df_full['Hallazgos Detectados'].astype('object')
                    
                        # Aplicar algoritmo a filas que necesitan cálculo
                        resultados = df_full.loc[mask_calc].apply(aplicar_algoritmo, axis=1)
                    
                        # FIX: Usar .values para asignación correcta (evita problemas de índices)
                        df_full.loc[mask_calc, 'Diagnóstico Algoritmo'] = resultados.iloc[:, 0].values
                        df_full.loc[mask_calc, 'Hallazgos Detectados'] = resultados.iloc[:, 1].values
                    
                        did_update = True
                    
                        # Contar resultados exitosos
                        resultados_validos = (~df_full.loc[mask_calc, 'Diagnóstico Algoritmo'].apply(_is_empty)).sum()
                        resultados_con_error = (df_full.loc[mask_calc, 'Diagnóstico Algoritmo'] == 'ERROR').sum()
                    
                        if resultados_validos > 0:
                            st.success(f"✅ Algoritmo calculado exitosamente en {resultados_validos} de {calc_count} casos.")
                            if resultados_con_error > 0:
                                st.warning(f"⚠️ {resultados_con_error} filas tuvieron errores durante el cálculo.")
                        else:
                            st.warning(f"⚠️ Se procesaron {calc_count} casos pero no se obtuvieron diagnósticos válidos.")
                            st.info("💡 Esto puede deberse a que todas las filas tienen valores por defecto (ceros) o datos incompletos.")
                    except Exception as e:
                        st.error(f"❌ Error durante el cálculo: {str(e)}")
                        st.error(f"Detalles: Tipo de error: {type(e).__name__}")
                        import traceback
                        with st.expander("Ver detalle técnico del error"):
                            st.code(traceback.format_exc())
                        did_update = False
                else:
                    st.info("ℹ️ Todas las filas ya tienen diagnóstico calculado. Usa 'Recalcular TODOS' para procesar nuevamente.")
        
            # Reordenamos para poner las nuevas columnas al principio
            cols_ordenadas = ['id', 'fecha', 'diagnostico', 'Diagnóstico Algoritmo', 'Hallazgos Detectados'] + \
                             [c for c in df_full.columns if c not in ['id', 'fecha', 'diagnostico', 'Diagnóstico Algoritmo', 'Hallazgos Detectados']]
            df_full = df_full[cols_ordenadas]

            if did_update:
                # Mantener la ruta correcta (backup o principal) sin sobreescribir
                df_full.to_csv(ruta_abs, index=False)
                # Verificar si hubo error en los cálculos (solo en filas calculadas)
                filas_con_error = (df_full.loc[mask_calc, 'Diagnóstico Algoritmo'] == 'ERROR').sum()
                if filas_con_error > 0:
                    st.warning(f"⚠️ {filas_con_error} filas tuvieron error en el cálculo. Revisa los datos de esas filas.")
                    # Mostrar filas con error
                    filas_error_idx = df_full.loc[mask_calc][df_full.loc[mask_calc, 'Diagnóstico Algoritmo'] == 'ERROR'].index
                    with st.expander("Ver filas con error"):
                        st.write(df_full.loc[filas_error_idx, ['id', 'fecha', 'Diagnóstico Algoritmo', 'Hallazgos Detectados']])
                elif df_full.loc[mask_calc, 'Diagnóstico Algoritmo'].apply(_is_empty).all():
                    st.error("❌ No se pudo calcular el algoritmo en ninguna fila procesada.")
                    st.info("💡 Posibles causas: columnas con nombres incorrectos o datos en formato no reconocido.")
                    # Mostrar muestra de datos procesados
                    with st.expander("Ver datos de las filas procesadas"):
                        cols_clave = ['id', 'IVS (mm)', 'Voltaje (mV)', 'GLS (%)', 'NT-proBNP (pg/ml)']
                        cols_disponibles = [c for c in cols_clave if c in df_full.columns]
                        if cols_disponibles:
                            st.write(df_full.loc[mask_calc, cols_disponibles].head())
                        else:
                            st.warning("No se encontraron columnas clave en la base de datos.")
    
        # Guardar en caché
        db_mtime = os.path.getmtime(ruta_abs)
        st.session_state.db_cache_key = db_mtime
        st.session_state.df_full_cache = df_full.copy()

        # 3. Vista completa primero
        st.subheader("📊 Base de Datos Completa")
    
        # Asegurar que existan las columnas mínimas
        if 'Diagnóstico Algoritmo' not in df_full.columns:
            df_full['Diagnóstico Algoritmo'] = ''
        if 'Hallazgos Detectados' not in df_full.columns:
            df_full['Hallazgos Detectados'] = ''
        if 'confianza_ia' not in df_full.columns:
            df_full['confianza_ia'] = ''

        # Mapeo completo de TODOS los red flags (igual que en aplicar_algoritmo)
        todas_las_caracteristicas = [
            'IVS (mm)', 'Voltaje (mV)', 'GLS (%)', 'NT-proBNP (pg/ml)',
            'Troponina elevada', 'Troponina elevada crónica baja (ATTR)',
            'Patrón LGE', 'ECV (%)', 'T1 Mapping', 'Hiperrealce subepicárdico (ATTR-v)',
            'Edad', 'Sexo', 'Derrame pericárdico', 'Pared posterior (mm)',
            'Distribución concéntrica (ATTR)', 'RV engrosado (ATTR)',
            'Aorta pequeña/normal relativa (ATTR)', 'Ausencia de FA (ATTR vs HTA)',
            'STC bilateral', 'Rotura bíceps', 'Estenosis lumbar', 'Tendinitis hombro',
            'Dupuytren', 'Artralgias', 'Fractura vertebral', 'Tendinitis cálcica',
            'Macroglosia', 'Púrpura periorbital', 'MGUS/Paraproteína', 'Síndrome nefrótico',
            'Polineuropatía', 'Disautonomía', 'Hepatomegalia', 'Fatiga severa',
            'Lesiones cutáneas', 'Apical sparing', 'Dilatación biauricular',
            'BAV/Marcapasos', 'Pseudoinfarto', 'Bajo voltaje paradójico',
            'Mutación TTR', 'Confusor HTA', 'Confusor EAo', 'Confusor IRC'
        ]
    
        # Construir lista de columnas a mostrar: base + todas las características disponibles
        columnas_mostrar = ['id', 'fecha', 'diagnostico', 'Diagnóstico Algoritmo', 'Hallazgos Detectados']
        columnas_mostrar += [c for c in todas_las_caracteristicas if c in df_full.columns]
    
        columnas_disponibles = [c for c in columnas_mostrar if c in df_full.columns]
    
        df_display = df_full[columnas_disponibles].copy()
        df_display = df_display.rename(columns={
            'diagnostico': 'Sospecha por IA convencional',
            'Diagnóstico Algoritmo': 'Sospecha Algoritmo'
        })
    
        # Mostrar con altura suficiente para ver bien todos los datos
        st.dataframe(df_display, use_container_width=True, height=600)
    
        st.divider()
    
        # 4. Vista detallada expandible por caso
        st.subheader("🔍 Vista Detallada: Todos los Hallazgos por Caso")
    
        id_casos = df_full['id'].tolist()
        caso_seleccionado = st.selectbox(
            "Selecciona un caso para ver TODOS sus hallazgos:",
            id_casos,
            format_func=lambda x: f"Caso #{x} - Real: {df_full[df_full['id']==x]['diagnostico'].values[0]} | Algoritmo: {df_full[df_full['id']==x]['Diagnóstico Algoritmo'].values[0] if 'Diagnóstico Algoritmo' in df_full.columns else 'N/A'}"
        )
    
        caso = df_full[df_full['id'] == caso_seleccionado].iloc[0]
    
        # Mostrar métricas principales
        col_m1, col_m2, col_m3 = st.columns(3)
        with col_m1:
            st.metric("ID Caso", f"#{caso.get('id', '—')}")
        with col_m2:
            st.metric("Diagnóstico Real", caso.get('diagnostico', '—'))
        with col_m3:
            diag_algo = caso.get('Diagnóstico Algoritmo', '—')
            st.metric("Diagnóstico Algoritmo", diag_algo)
    
        fecha_str = caso.get('fecha', '—')
        nhc_str = caso.get('nhc', '—')
        conf_str = f"{caso.get('confianza_ia', 0):.1f}%" if caso.get('confianza_ia') else "—"
        modelo_str = caso.get('modelo_usado', '—')
        st.markdown(f"**Fecha:** {fecha_str} | **NHC:** {nhc_str} | **Confianza IA:** {conf_str} | **Modelo:** {modelo_str}")
    
        st.divider()
    
        # Parámetros cardiacos
        st.markdown("#### 🫀 Parámetros Cardiacos")
        col_p1, col_p2, col_p3, col_p4 = st.columns(4)
        with col_p1:
            ivs_val = caso.get('ivs', 0)
            st.metric("IVS (mm)", f"{ivs_val}" if ivs_val else "—")
        with col_p2:
            gls_val = caso.get('gls', 0)
            st.metric("GLS (%)", f"{gls_val}" if gls_val else "—")
        with col_p3:
            volt_val = caso.get('volt', 0)
            st.metric("Voltaje (mV)", f"{volt_val}" if volt_val else "—")
        with col_p4:
            septum_val = caso.get('septum_posterior', 0)
            st.metric("Pared Post. (mm)", f"{septum_val}" if septum_val else "—")
    
        # Biomarcadores
        st.markdown("#### 🧪 Biomarcadores")
        col_b1, col_b2 = st.columns(2)
        with col_b1:
            nt_probnp_val = caso.get('nt_probnp', 0)
            st.metric("NT-proBNP (pg/ml)", f"{nt_probnp_val:.0f}" if nt_probnp_val else "—")
        with col_b2:
            troponina_val = "✓ Elevada" if caso.get('troponina', 0) else "Normal"
            st.metric("Troponina", troponina_val)
    
        # Resonancia Magnética
        st.markdown("#### 🎯 Resonancia Magnética Cardíaca")
        col_rm1, col_rm2, col_rm3 = st.columns(3)
        with col_rm1:
            lge_val = caso.get('lge_patron', '—')
            st.metric("Patrón LGE", str(lge_val).upper() if lge_val else "—")
        with col_rm2:
            ecv_val = caso.get('ecv', 0)
            st.metric("ECV (%)", f"{ecv_val:.1f}" if ecv_val else "—")
        with col_rm3:
            t1_val = "✓ Elevado" if caso.get('t1_mapping', 0) else "Normal"
            st.metric("T1 Mapping", t1_val)
    
        # Red Flags
        st.markdown("#### 🚩 Hallazgos Clínicos Detectados (Red Flags)")
    
        hallazgos_found = []
        red_flag_features = [
            'stc', 'biceps', 'lumbar', 'hombro', 'dupuytren', 'artralgias', 'fractura_vert', 'tendinitis_calcifica',
            'macro', 'purpura', 'mgus', 'nefro', 'neuro_p', 'disauto', 'hepato', 'fatiga', 'piel_lesiones',
            'apical_sparing', 'biatrial', 'bav_mp', 'pseudo_q', 'bajo_voltaje',
            'mutacion_ttr',
            'confusor_hta', 'confusor_ao', 'confusor_irc', 'derrame_pericardico'
        ]
    
        hallazgo_nombres = {
            'stc': '🔴 STC Bilateral',
            'biceps': '🔴 Rotura Bíceps',
            'lumbar': '🔴 Estenosis Lumbar',
            'hombro': 'Tendinitis Hombro',
            'dupuytren': 'Enfermedad Dupuytren',
            'artralgias': 'Artralgias',
            'fractura_vert': 'Fractura Vertebral',
            'tendinitis_calcifica': 'Tendinitis Cálcica',
            'macro': 'Macroglosia',
            'purpura': 'Púrpura Periorbital',
            'mgus': 'MGUS/Paraproteína',
            'nefro': 'Síndrome Nefrótico',
            'neuro_p': 'Polineuropatía',
            'disauto': 'Disautonomía',
            'hepato': 'Hepatomegalia',
            'fatiga': 'Fatiga Severa',
            'piel_lesiones': 'Lesiones Cutáneas',
            'apical_sparing': 'Apical Sparing',
            'biatrial': 'Dilatación Biauricular',
            'bav_mp': 'BAV/Marcapasos',
            'pseudo_q': 'Pseudoinfarto',
            'bajo_voltaje': 'Bajo Voltaje',
            'mutacion_ttr': 'Mutación TTR',
            'confusor_hta': 'HTA Severa',
            'confusor_ao': 'Estenosis Aórtica',
            'confusor_irc': 'Insuficiencia Renal',
            'derrame_pericardico': 'Derrame Pericárdico'
        }
    
        for feature in red_flag_features:
            if caso.get(feature, 0) in [1, True]:
                hallazgos_found.append(hallazgo_nombres.get(feature, feature))
    
        if hallazgos_found:
            cols_h = st.columns(2)
            for idx, hallazgo in enumerate(hallazgos_found):
                with cols_h[idx % 2]:
                    st.write(f"✅ {hallazgo}")
        else:
            st.info("ℹ️ Sin hallazgos clínicos detectados")
    
        st.divider()
    
        # Botón de descarga
        csv_bytes = df_full.to_csv(index=False).encode('utf-8')
    
        col_btn1, col_btn2 = st.columns(2)
        with col_btn1:
            st.download_button(
                label=f"📥 Descargar Caso #{caso_seleccionado}",
                data=df_full[df_full['id'] == caso_seleccionado].to_csv(index=False).encode('utf-8'),
                file_name=f"caso_{caso_seleccionado}.csv",
                mime="text/csv",
                key=f"download_caso_{caso_seleccionado}"
            )
    
        with col_btn2:
            st.download_button(
                label="📥 Descargar Base de Datos Completa",
                data=csv_bytes,
                file_name=f"amylo_export_{datetime.datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv",
                key="download_db_complete_tab5"
            )
    
        # Gráficos de resumen
        st.divider()
        col_g1, col_g2 = st.columns(2)
    
        with col_g1:
            st.subheader("📈 Diagnóstico Real")
            st.bar_chart(df_full['diagnostico'].value_counts())
        
        with col_g2:
            st.subheader("🤖 Diagnóstico Algoritmo")
            if 'Diagnóstico Algoritmo' in df_full.columns:
                st.bar_chart(df_full['Diagnóstico Algoritmo'].value_counts())

        # Botón de limpieza
        st.divider()
        with st.expander("⚠️ Zona de Peligro: Limpiar Base de Datos"):
            st.warning("Esta acción eliminará TODOS los casos guardados.")
            if st.button("🗑️ BORRAR TODA LA BASE DE DATOS", type="secondary"):
                ruta_abs = os.path.join(BASE_DIR, DB_FILE)
                if os.path.isfile(ruta_abs):
                    os.remove(ruta_abs)
                    st.success("✅ Base de datos eliminada.")
                    st.rerun()
    else:
        st.info("📭 No hay casos guardados aún.")
