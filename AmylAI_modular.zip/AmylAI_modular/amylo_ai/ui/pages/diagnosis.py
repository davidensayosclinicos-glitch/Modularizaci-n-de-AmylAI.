import os
import re
import io
import csv
import json
import base64
import datetime
import time
import html
import zipfile
import tempfile
import hashlib
import hmac
import shutil
import glob
import webbrowser
from urllib.parse import quote_plus

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pdfplumber
from PIL import Image
from scipy import stats
from scipy.stats import norm
from sklearn.metrics import (
    confusion_matrix, roc_curve, auc, matthews_corrcoef, cohen_kappa_score,
    accuracy_score, balanced_accuracy_score, f1_score, fbeta_score,
    brier_score_loss, average_precision_score, precision_recall_curve,
    classification_report
)
import streamlit as st

from amylo_ai.config import BASE_DIR, DB_FILE, DEFAULT_DATA
from amylo_ai.ml.model import calcular_ensamble_experto_ml_llm

def render():
    st.header("🤖 Diagnóstico del Algoritmo")
    st.markdown("Aplica el algoritmo de amiloidosis a toda la tabla y visualiza los resultados")

    ruta_abs = os.path.join(BASE_DIR, DB_FILE)

    if not os.path.isfile(ruta_abs):
        st.error(f"❌ No se encuentra {DB_FILE} en la carpeta")
        st.stop()

    # Cargar datos
    with st.spinner("Cargando tabla de amiloidosis..."):
        df_algoritmo = pd.read_csv(ruta_abs)

    st.success(f"✅ Tabla cargada: {len(df_algoritmo)} casos")

    # Crear columnas de resultado si no existen
    if 'Diagnóstico Algoritmo' not in df_algoritmo.columns:
        df_algoritmo['Diagnóstico Algoritmo'] = ''
    if 'Hallazgos Detectados' not in df_algoritmo.columns:
        df_algoritmo['Hallazgos Detectados'] = ''
    if 'Score' not in df_algoritmo.columns:
        df_algoritmo['Score'] = 0
    if 'Confianza (%)' not in df_algoritmo.columns:
        df_algoritmo['Confianza (%)'] = 0.0

    # Opciones de procesamiento
    col_opts1, col_opts2 = st.columns(2)

    with col_opts1:
        procesar_todos = st.checkbox("🔄 Procesar TODOS los casos", value=False)

    with col_opts2:
        procesar_vacios = st.checkbox("⚙️ Solo procesar resultados vacíos", value=True)

    # Botón de procesamiento
    if st.button("▶️ EJECUTAR ALGORITMO", type="primary"):
        with st.spinner("Procesando casos..."):
            total_procesados = 0
        
            # Mapeo de nombres de columnas CSV a nombres esperados por el algoritmo
            mapeo_columnas = {
                'IVS (mm)': 'ivs',
                'Voltaje (mV)': 'volt',
                'GLS (%)': 'gls',
                'NT-proBNP (pg/ml)': 'nt_probnp',
                'Troponina elevada': 'troponina',
                'Troponina elevada crónica baja (ATTR)': 'troponina_cronica',
                'Patrón LGE': 'lge_patron',
                'ECV (%)': 'ecv',
                'T1 Mapping': 't1_mapping',
                'Hiperrealce subepicárdico (ATTR-v)': 'hiperrealce_subepicardico',
                'Edad': 'edad',
                'Sexo': 'sexo',
                'Derrame pericárdico': 'derrame_pericardico',
                'Pared posterior (mm)': 'septum_posterior',
                'Distribución concéntrica (ATTR)': 'distribucion_concentrica',
                'RV engrosado (ATTR)': 'rv_engrosado',
                'Aorta pequeña/normal relativa (ATTR)': 'aorta_pequena',
                'Ausencia de FA (ATTR vs HTA)': 'ausencia_fa',
                'STC bilateral': 'stc',
                'Rotura bíceps': 'biceps',
                'Estenosis lumbar': 'lumbar',
                'Tendinitis hombro': 'hombro',
                'Dupuytren': 'dupuytren',
                'Artralgias': 'artralgias',
                'Fractura vertebral': 'fractura_vert',
                'Tendinitis cálcica': 'tendinitis_calcifica',
                'Macroglosia': 'macro',
                'Púrpura periorbital': 'purpura',
                'MGUS/Paraproteína': 'mgus',
                'Síndrome nefrótico': 'nefro',
                'Polineuropatía': 'neuro_p',
                'Disautonomía': 'disauto',
                'Hepatomegalia': 'hepato',
                'Fatiga severa': 'fatiga',
                'Lesiones cutáneas': 'piel_lesiones',
                'Apical sparing': 'apical_sparing',
                'Dilatación biauricular': 'biatrial',
                'BAV/Marcapasos': 'bav_mp',
                'Pseudoinfarto': 'pseudo_q',
                'Bajo voltaje paradójico': 'bajo_voltaje',
                'Mutación TTR': 'mutacion_ttr',
                'Confusor HTA': 'confusor_hta',
                'Confusor EAo': 'confusor_ao',
                'Confusor IRC': 'confusor_irc'
            }
        
            for idx, row in df_algoritmo.iterrows():
                # Verificar si ya tiene resultado
                tiene_resultado = pd.notna(df_algoritmo.loc[idx, 'Diagnóstico Algoritmo']) and \
                                  str(df_algoritmo.loc[idx, 'Diagnóstico Algoritmo']).strip() != ''
            
                if procesar_vacios and tiene_resultado and not procesar_todos:
                    continue
            
                # Preparar datos para el algoritmo
                d = DEFAULT_DATA.copy()
                row_dict = row.to_dict()
            
                # Aplicar mapeo de columnas
                for nombre_csv, nombre_algoritmo in mapeo_columnas.items():
                    if nombre_csv in row_dict:
                        valor = row_dict[nombre_csv]
                        if nombre_algoritmo in DEFAULT_DATA:
                            if isinstance(DEFAULT_DATA[nombre_algoritmo], bool):
                                if isinstance(valor, bool):
                                    d[nombre_algoritmo] = valor
                                elif isinstance(valor, str):
                                    d[nombre_algoritmo] = valor.lower() in ['true', '1', 'sí', 's', 'yes', 'v']
                                elif isinstance(valor, (int, float)):
                                    d[nombre_algoritmo] = bool(valor)
                                else:
                                    d[nombre_algoritmo] = False
                            elif isinstance(DEFAULT_DATA[nombre_algoritmo], (int, float)):
                                try:
                                    if pd.isna(valor) or valor == '' or valor is None:
                                        d[nombre_algoritmo] = DEFAULT_DATA[nombre_algoritmo]
                                    else:
                                        d[nombre_algoritmo] = float(valor)
                                except (ValueError, TypeError):
                                    d[nombre_algoritmo] = DEFAULT_DATA[nombre_algoritmo]
                            else:
                                d[nombre_algoritmo] = valor if pd.notna(valor) and valor != '' else DEFAULT_DATA[nombre_algoritmo]
            
                # Asegurar valores numéricos válidos
                for key in ['ivs', 'volt', 'gls', 'nt_probnp', 'ecv', 'septum_posterior', 'edad']:
                    if key in d and (pd.isna(d[key]) or d[key] is None):
                        d[key] = 0.0 if isinstance(d[key], float) else 0
            
                try:
                    # Ejecutar algoritmo
                    res = calcular_ensamble_experto_ml_llm(d, usar_llm=False)
                
                    # Guardar resultados
                    df_algoritmo.loc[idx, 'Diagnóstico Algoritmo'] = res.get('nivel', '')
                    df_algoritmo.loc[idx, 'Hallazgos Detectados'] = ", ".join(res.get('hallazgos', []))
                    df_algoritmo.loc[idx, 'Score'] = res.get('score', 0)
                    df_algoritmo.loc[idx, 'Confianza (%)'] = res.get('confianza_porcentaje', 0.0)
                
                    total_procesados += 1
                
                except Exception as e:
                    df_algoritmo.loc[idx, 'Diagnóstico Algoritmo'] = f"ERROR: {str(e)[:50]}"
        
            # Guardar en CSV
            df_algoritmo.to_csv(ruta_abs, index=False)
        
        st.success(f"✅ Procesamiento completado: {total_procesados} casos calculados")
        st.rerun()

    # Filtros
    st.divider()
    st.subheader("🔍 Filtros de Visualización")

    col_filter1, col_filter2, col_filter3 = st.columns(3)

    with col_filter1:
        diagnosticos_unicos = ['Todos'] + sorted(df_algoritmo['Diagnóstico Algoritmo'].dropna().unique().tolist())
        diag_filtro = st.selectbox("Diagnóstico Algoritmo:", diagnosticos_unicos)

    with col_filter2:
        score_min = st.number_input("Score mínimo:", min_value=0, max_value=50, value=0)

    with col_filter3:
        mostrar_filas = st.number_input("Filas a mostrar:", min_value=5, max_value=len(df_algoritmo)+1, value=20)

    # Aplicar filtros
    df_filtrado = df_algoritmo.copy()

    if diag_filtro != 'Todos':
        df_filtrado = df_filtrado[df_filtrado['Diagnóstico Algoritmo'] == diag_filtro]

    df_filtrado = df_filtrado[df_filtrado['Score'] >= score_min]

    # Columnas a mostrar
    columnas_mostrar = ['id', 'Diagnóstico Algoritmo', 'Score', 'Confianza (%)', 'Hallazgos Detectados']
    columnas_disponibles = [col for col in columnas_mostrar if col in df_filtrado.columns]

    st.subheader(f"📋 Resultados ({len(df_filtrado)} casos)")
    df_filtrado_tabla = df_filtrado[columnas_disponibles].head(int(mostrar_filas)).copy()
    df_filtrado_tabla = df_filtrado_tabla.rename(columns={
        'Diagnóstico Algoritmo': 'Sospecha Algoritmo'
    })
    st.dataframe(
        df_filtrado_tabla,
        use_container_width=True,
        height=400
    )

    # Estadísticas
    st.divider()
    st.subheader("📊 Estadísticas Generales")

    col_stat1, col_stat2, col_stat3, col_stat4 = st.columns(4)

    # Contar diagnósticos
    diag_str = df_algoritmo['Diagnóstico Algoritmo'].astype(str)
    diag_counts = diag_str.value_counts()

    with col_stat1:
        alta_sospecha = len(df_algoritmo[diag_str.str.contains('ALTA', case=False, na=False)])
        st.metric("Alta Sospecha", alta_sospecha)

    with col_stat2:
        intermedia = len(df_algoritmo[diag_str.str.contains('INTERMEDIA', case=False, na=False)])
        st.metric("Intermedia", intermedia)

    with col_stat3:
        sano = len(df_algoritmo[diag_str.str.contains('BAJA|Sano', case=False, na=False)])
        st.metric("Bajo Riesgo/Sano", sano)

    with col_stat4:
        sin_calcular = len(df_algoritmo[df_algoritmo['Diagnóstico Algoritmo'].isna() | (df_algoritmo['Diagnóstico Algoritmo'] == '')])
        st.metric("Sin Calcular", sin_calcular)

    # Gráficos
    st.divider()

    col_graf1, col_graf2 = st.columns(2)

    with col_graf1:
        st.subheader("Distribución de Diagnósticos")
        if len(diag_counts) > 0:
            st.bar_chart(diag_counts)
        else:
            st.info("Sin datos para mostrar")

    with col_graf2:
        st.subheader("Distribución de Scores")
        scores = df_algoritmo['Score'].dropna()
        if len(scores) > 0:
            fig, ax = plt.subplots()
            ax.hist(scores, bins=20)
            ax.set_xlabel("Score")
            ax.set_ylabel("Frecuencia")
            st.pyplot(fig)
        else:
            st.info("Sin datos para mostrar")

    # Exportar resultados
    st.divider()
    st.subheader("💾 Exportar Resultados")

    col_exp1, col_exp2 = st.columns(2)

    with col_exp1:
        csv_export = df_algoritmo.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="📥 Descargar Resultados (CSV)",
            data=csv_export,
            file_name=f"diagnostico_algoritmo_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )

    with col_exp2:
        # Crear Excel con filtrados
        df_excel = df_filtrado[columnas_disponibles].copy()
        excel_buffer = pd.DataFrame.to_excel.__defaults__[0] if hasattr(pd.DataFrame.to_excel, '__defaults__') else None
        try:
            from io import BytesIO
            excel_bytes = BytesIO()
            with pd.ExcelWriter(excel_bytes, engine='openpyxl') as writer:
                df_excel.to_excel(writer, sheet_name='Diagnóstico', index=False)
            st.download_button(
                label="📊 Descargar como Excel",
                data=excel_bytes.getvalue(),
                file_name=f"diagnostico_algoritmo_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        except Exception as e:
            st.warning(f"⚠️ No se puede exportar a Excel: {e}")
