import os
import re
import io
import csv
import json
import base64
import datetime
import time
import html
import zipfile
import tempfile
import hashlib
import hmac
import shutil
import glob
import webbrowser
from urllib.parse import quote_plus

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pdfplumber
from PIL import Image
from scipy import stats
from scipy.stats import norm
from sklearn.metrics import (
    confusion_matrix, roc_curve, auc, matthews_corrcoef, cohen_kappa_score,
    accuracy_score, balanced_accuracy_score, f1_score, fbeta_score,
    brier_score_loss, average_precision_score, precision_recall_curve,
    classification_report
)
import streamlit as st

# Esta página no necesita cargar el motor clínico.

def render():
    st.header("🔬 Test de Estrés del Algoritmo")
    st.markdown("Resumen de validación del algoritmo de amiloidosis cardíaca")

    st.divider()

    # Resumen General
    st.subheader("📊 Resumen General")
    st.metric("Precisión Global (Accuracy)", "83.8%", help="Acierto total del algoritmo")

    st.info("""
    El algoritmo es **excelente detectando Amiloidosis AL y ATTR**, pero sufre un poco más 
    diferenciando entre casos Intermedios, Sanos y HVI (Hipertrofia Ventricular Izquierda 
    por HTA o problemas Aórticos).
    """)

    st.divider()

    # Rendimiento por Categoría
    st.subheader("🔍 Rendimiento por Categoría")

    # Amiloidosis AL
    st.markdown("### Amiloidosis AL (Alta Sospecha) 🟢 Excelente")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Precisión", "100%", help="No hay falsos positivos: cuando dice AL, es seguro que es AL")
    with col2:
        st.metric("Sensibilidad", "95.0%", help="Encuentra el 95% de los casos reales")

    st.divider()

    # Amiloidosis ATTR
    st.markdown("### Amiloidosis ATTR (Alta Probabilidad) 🟢 Muy bueno")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Precisión", "93.1%")
    with col2:
        st.metric("Sensibilidad", "94.5%")

    st.divider()

    # Baja / Sano
    st.markdown("### Baja / Sano 🟡 Bueno, pero con falsos positivos")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Precisión", "73.8%", help='A veces dice que es "Baja/Sano" cuando en realidad pertenece a otra categoría')
    with col2:
        st.metric("Sensibilidad", "97.0%", help="Casi nunca se le escapa un paciente realmente sano")

    st.divider()

    # HVI No Amiloide
    st.markdown("### HVI No Amiloide 🟠 Moderado")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Precisión", "84.2%")
    with col2:
        st.metric("Sensibilidad", "69.5%", help="Pierde a varios pacientes con HVI que clasifica como Intermedios o Sanos")

    st.divider()

    # Intermedia (Screening)
    st.markdown("### Intermedia (Screening) 🔴 El punto más débil")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Precisión", "70.4%")
    with col2:
        st.metric("Sensibilidad", "63.0%", help="Le cuesta identificar los casos intermedios, confundiéndolos con Sanos o HVI No Amiloide")

    st.divider()

    # Tabla resumen
    st.subheader("📋 Tabla Resumen de Métricas")

    df_resumen = pd.DataFrame({
        'Categoría': [
            'Amiloidosis AL (Alta Sospecha)',
            'Amiloidosis ATTR (Alta Probabilidad)',
            'Baja / Sano',
            'HVI No Amiloide',
            'Intermedia (Screening)'
        ],
        'Precisión': ['100%', '93.1%', '73.8%', '84.2%', '70.4%'],
        'Sensibilidad': ['95.0%', '94.5%', '97.0%', '69.5%', '63.0%'],
        'Evaluación': ['🟢 Excelente', '🟢 Muy bueno', '🟡 Bueno', '🟠 Moderado', '🔴 Punto débil']
    })

    st.dataframe(df_resumen, use_container_width=True, hide_index=True)

    st.divider()

    # Conclusiones
    st.subheader("💡 Conclusiones")
    st.success("""
    **Fortalezas:**
    - Excelente detección de AL (100% precisión, 95% sensibilidad)
    - Muy buena detección de ATTR (93.1% precisión, 94.5% sensibilidad)
    - Alta sensibilidad para identificar pacientes sanos (97%)

    **Áreas de mejora:**
    - Diferenciación entre casos Intermedios, Sanos y HVI
    - Sensibilidad de HVI (69.5%) y casos Intermedios (63.0%)
    - Reducir falsos positivos en categoría Baja/Sano
    """)
