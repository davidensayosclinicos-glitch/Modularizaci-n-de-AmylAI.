import os
import re
import io
import csv
import json
import base64
import datetime
import time
import html
import zipfile
import tempfile
import hashlib
import hmac
import shutil
import glob
import webbrowser
from urllib.parse import quote_plus

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pdfplumber
from PIL import Image
from scipy import stats
from scipy.stats import norm
from sklearn.metrics import (
    confusion_matrix, roc_curve, auc, matthews_corrcoef, cohen_kappa_score,
    accuracy_score, balanced_accuracy_score, f1_score, fbeta_score,
    brier_score_loss, average_precision_score, precision_recall_curve,
    classification_report
)
import streamlit as st

from amylo_ai.clinical.narrative import generar_explicacion_narrativa
from amylo_ai.ml.model import calcular_ensamble_experto_ml_llm
from amylo_ai.services.llm import fusionar_extracciones, motor_nlp_contextual
from amylo_ai.services.ocr import procesar_pdf_paralelo

def render():
    st.markdown("### 📄 Procesamiento de Lote (PDFs Masivo)")
    st.markdown("Sube múltiples informes médicos para análisis automático")
    st.divider()

    col_upload, col_info = st.columns([2, 1])

    with col_upload:
        st.markdown("#### 📤 Selecciona tus documentos")
        uploaded_files = st.file_uploader(
            "Arrastra aquí tus informes (PDF):",
            type=["pdf"],
            accept_multiple_files=True,
            help="Máximo 10 archivos por sesión"
        )

    with col_info:
        st.markdown("#### ℹ️ Información")
        st.markdown("""
        ✅ Análisis automático  
        ✅ Extracción NLP  
        ✅ Diagnóstico por caso  
        ✅ Exportación de resultados  
        """)

    if uploaded_files and st.button("🚀 Procesar Lote", type="primary", use_container_width=True):
        num_docs = len(uploaded_files)
        extracciones = []

        st.divider()
        st.markdown("### ⏳ Progreso de Procesamiento")
    
        container_progress = st.container(border=True)
        with container_progress:
            progress_global = st.progress(0)
            text_global = st.empty()
        
            progress_local = st.progress(0)
            text_local = st.empty()

        for i, uploaded_file in enumerate(uploaded_files):
            doc_name = uploaded_file.name
            texto_completo_doc = ""

            text_global.markdown(f"**📍 Archivo {i+1}/{num_docs}:** {doc_name}")
            progress_global.progress((i) / num_docs)

            try:
                with pdfplumber.open(uploaded_file) as pdf:
                    total_paginas = len(pdf.pages)
                    text_local.markdown(f"🚀 Procesando {total_paginas} páginas en paralelo...")
                    progress_local.progress(0.2)
                
                    # Procesamiento paralelo optimizado
                    inicio_ocr = time.time()
                    texto_completo_doc, tiempos_ocr = procesar_pdf_paralelo(pdf, max_workers=4)
                    tiempo_total_ocr = time.time() - inicio_ocr
                
                    # Mostrar estadísticas de velocidad
                    if tiempos_ocr:
                        tiempo_promedio = sum(tiempos_ocr.values()) / len(tiempos_ocr)
                        text_local.markdown(f"✅ OCR completado en {tiempo_total_ocr:.1f}s (promedio {tiempo_promedio:.2f}s/página)")
                    else:
                        text_local.markdown(f"✅ PDF procesado en {tiempo_total_ocr:.1f}s")
                
                    progress_local.progress(0.8)

            except Exception as e:
                st.error(f"❌ Error leyendo {doc_name}: {e}")
                continue

            text_local.markdown(f"🧠 Analizando {doc_name}...")
            if len(texto_completo_doc) > 10:
                datos_doc = motor_nlp_contextual(texto_completo_doc)
                extracciones.append({"documento": doc_name, "datos": datos_doc})
            else:
                st.warning(f"⚠️ {doc_name}: Parece estar vacío o escaneado sin OCR")

        progress_global.progress(1.0)
        text_global.markdown("**✅ Procesamiento completado**")
        text_local.empty()
        progress_local.empty()
    
        time.sleep(0.5)
        container_progress.empty()

        st.session_state.consolidado_batch = fusionar_extracciones(extracciones)
    
        # Generar tabla de resultados
        res_indiv = []
        for item in extracciones:
            riesgo = calcular_ensamble_experto_ml_llm(item['datos'], usar_llm=True)
            res_indiv.append({
                "📄 Documento": item['documento'],
                "🎯 Diagnóstico": riesgo['nivel'],
                "📊 Score": riesgo['score'],
                "🤝 Consenso": f"{riesgo.get('fuerza_consenso', 0.0):.1f}%",
                "📝 Hallazgos": ", ".join(riesgo['hallazgos'][:2]) + ("..." if len(riesgo['hallazgos']) > 2 else "")
            })
    
        st.session_state.resultados_individuales = pd.DataFrame(res_indiv)
        st.rerun()

    # Mostrar resultados si existen
    if st.session_state.get('consolidado_batch'):
        st.divider()
        st.markdown("### 📋 Resultados del Análisis")
    
        if st.session_state.resultados_individuales is not None:
            st.markdown("#### Diagnósticos por Documento")
            st.dataframe(
                st.session_state.resultados_individuales,
                use_container_width=True,
                height=300,
                hide_index=True
            )
    
        col_data, col_diag = st.columns([1, 1], gap="large")
    
        with col_data:
            st.markdown("#### 📊 Datos Consolidados")
            df_res = pd.DataFrame([st.session_state.consolidado_batch]).T
            df_res.columns = ["Valor"]
            st.dataframe(df_res, use_container_width=True, height=400)
    
        with col_diag:
            st.markdown("#### 🤖 Diagnóstico Fusionado")
            res_batch = calcular_ensamble_experto_ml_llm(st.session_state.consolidado_batch, usar_llm=True)
        
            st.markdown(f"""
            <div style="
                background: linear-gradient(135deg, {res_batch['color']}33 0%, {res_batch['color']}11 100%);
                border-left: 5px solid {res_batch['color']};
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 20px;
            ">
                <h3 style="color: {res_batch['color']}; margin: 0 0 10px 0;">
                    {res_batch['nivel']}
                </h3>
                <p style="color: #333; margin: 0;">
                    <strong>{res_batch['msg']}</strong>
                </p>
            </div>
            """, unsafe_allow_html=True)

            componentes_b = res_batch.get('componentes_ensamble', {})
            votos_b = res_batch.get('votos_ensamble', {})
            if componentes_b:
                st.markdown("##### 🧠 Desglose Ensamble")
                filas_comp_b = []
                for nombre in ['experto', 'ml', 'llm']:
                    comp = componentes_b.get(nombre, {})
                    filas_comp_b.append({
                        'Componente': nombre.upper(),
                        'Peso': round(float(comp.get('peso', 0.0)), 2),
                        'Categoría': comp.get('categoria') or 'N/D'
                    })
                st.dataframe(pd.DataFrame(filas_comp_b), use_container_width=True, hide_index=True)

            if votos_b:
                filas_votos_b = [
                    {'Categoría': cat, 'Voto Normalizado': round(float(valor) * 100.0, 1)}
                    for cat, valor in sorted(votos_b.items(), key=lambda x: x[1], reverse=True)
                ]
                st.dataframe(pd.DataFrame(filas_votos_b), use_container_width=True, hide_index=True)
                st.caption(
                    f"Consenso final: {res_batch.get('categoria_ensamble', res_batch.get('nivel', 'N/D'))} "
                    f"({res_batch.get('fuerza_consenso', 0.0)}%)"
                )
        
            st.markdown("#### 🧠 Análisis del Asistente")
            explicacion = generar_explicacion_narrativa(st.session_state.consolidado_batch, res_batch)
            st.info(explicacion)
        
            if "_origen" in st.session_state.consolidado_batch:
                with st.expander("🔍 Auditoría (Origen de datos)"):
                    st.json(st.session_state.consolidado_batch["_origen"])
    
        st.divider()
        col_exp1, col_exp2 = st.columns(2)
        with col_exp1:
            if st.button("📥 Descargar Resultados", use_container_width=True):
                csv = st.session_state.resultados_individuales.to_csv(index=False)
                st.download_button(
                    label="📥 Resultados.csv",
                    data=csv,
                    file_name=f"amylai_results_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    key="download_batch_results"
                )
    
        with col_exp2:
            if st.button("🗑️ Limpiar Resultados", use_container_width=True):
                st.session_state.consolidado_batch = None
                st.session_state.resultados_individuales = None
                st.rerun()

    # -----------------------------------------------------------------------------
    # TAB 2: CASO INDIVIDUAL - INTERFAZ MEJORADA
    # -------------------------------------------------------------------------------------
