import os
import streamlit as st
from amylo_ai.config import BASE_DIR
from amylo_ai.utils.files import read_file_base64

def apply_global_styles():
    if (
        'fondo_base64' not in st.session_state or not st.session_state.get('fondo_base64')
        or 'icono_base64' not in st.session_state or not st.session_state.get('icono_base64')
    ):
        fondo_data = None
        fondo_candidates = [
            "fondo_rb_optimizado.jpg",
            "fondo_rb.jpg",
            "fondo_lateral.jpg",
        ]
        for fondo_name in fondo_candidates:
            fondo_path = os.path.join(BASE_DIR, fondo_name)
            fondo_data = read_file_base64(fondo_path)
            if fondo_data:
                break
        st.session_state.fondo_base64 = f"data:image/jpeg;base64,{fondo_data}" if fondo_data else None

        icono_path = os.path.join(BASE_DIR, "image_6.png")
        icono_data = read_file_base64(icono_path)
        st.session_state.icono_base64 = f"data:image/png;base64,{icono_data}" if icono_data else None

    # Inyectar CSS con fondo
    fondo_css = ""
    if st.session_state.fondo_base64:
        fondo_css = f"""
        .stApp {{
            background-image: url('{st.session_state.fondo_base64}');
            background-size: cover;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-position: center;
        }}

        [data-testid="stAppViewContainer"] {{
            background-image: url('{st.session_state.fondo_base64}');
            background-size: cover;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-position: center;
            position: relative;
            color: #111111;
        }}
    
        [data-testid="stAppViewContainer"]::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0.75) 100%);
            pointer-events: none;
            z-index: 0;
        }}
    
        [data-testid="stAppViewContainer"] > * {{
            position: relative;
            z-index: 1;
        }}
        """

    st.markdown(f"""
    <style>
    {fondo_css}

    /* Sidebar mejorado con fondo */
    [data-testid="stSidebar"] {{
        background: linear-gradient(180deg, rgba(244,140,140,0.95) 0%, rgba(230,110,110,0.95) 100%);
        box-shadow: 2px 0 8px rgba(0,0,0,0.1);
        backdrop-filter: blur(10px);
        color: #ffffff;
        font-size: 0.9rem;
    }}

    /* Colores principales */
    :root {{
        --color-al: #d32f2f;
        --color-attr: #6a1b9a;
        --color-intermedia: #f57c00;
        --color-baja: #388e3c;
    }}

    /* Tipografía mejorada */
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }}

    /* Dividers mejorados */
    hr {{ border: none; height: 2px; background: linear-gradient(90deg, transparent, #ccc, transparent); margin: 20px 0; }}

    /* Headers */
    h1, h2, h3 {{ font-weight: 700; letter-spacing: -0.5px; }}

    /* Botones más bonitos */
    .stButton > button {{
        border-radius: 8px !important;
        font-weight: 600 !important;
        letter-spacing: 0.5px !important;
        border: none !important;
        transition: all 0.3s ease !important;
    }}

    .stButton > button:hover {{
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
    }}

    /* Expanders con mejor apariencia */
    .streamlit-expanderHeader {{
        font-weight: 600 !important;
        border-radius: 8px !important;
    }}

    /* Checkboxes */
    .stCheckbox {{ margin: 10px 0 !important; }}

    /* Alerts */
    .stAlert {{ border-radius: 10px !important; }}

    /* Tabs styling */
    .stTabs [data-baseweb="tab-list"] [data-qa="stTab"] {{
        padding: 12px 20px !important;
        font-weight: 600 !important;
        border-radius: 8px 8px 0 0 !important;
    }}

    /* Input fields mejorados */
    input {{
        border-radius: 8px !important;
    }}

    textarea {{
        border-radius: 8px !important;
    }}

    /* Select mejora do */
    select {{
        border-radius: 8px !important;
    }}
    </style>
    """, unsafe_allow_html=True)

def apply_page_styles(fondo_lateral_css: str = ""):
    tab_style = """
        <style>
        .stTabs [data-baseweb="tab-list"] [data-qa="stTab"] {
            padding: 12px 20px;
            font-weight: 600;
        }
        </style>
        """

    # Configurar fondo dinámico con imagen si existe
    bg_img_css = "background-image: linear-gradient(180deg, #0e1117, #161b22);"
    if st.session_state.get('fondo_base64'):
        bg_img_css = f"""
            background-image: linear-gradient(180deg, rgba(255,255,255,0.6), rgba(255,255,255,0.75)), url('{st.session_state.fondo_base64}') !important;
            background-size: cover !important;
            background-attachment: fixed !important;
            background-repeat: no-repeat !important;
        """

    page_style = f"""
        <style>
        html, body, [class*="css"] {{
            font-size: 13px !important;
        }}

        /* Intensify main page background */
        .stApp {{
            {bg_img_css}
            background-position: center !important;
        }}

        [data-testid="stAppViewContainer"] {{
            background-color: #f4f6f8 !important;
            {bg_img_css}
            background-position: center !important;
            color: #111111;
        }}

        /* Sidebar */
        section[data-testid="stSidebar"] {{
            overflow: visible !important;
        }}

        section[data-testid="stSidebar"] > div {{
            height: 100vh !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
        }}

        [data-testid="stSidebarContent"] {{
            height: 100% !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            padding-bottom: 0.75rem !important;
        }}

        [data-testid="stSidebar"] > div:first-child {{
            background: linear-gradient(180deg, rgba(20, 24, 28, 0.92), rgba(20, 24, 28, 0.96)) !important;
            {fondo_lateral_css}
            background-size: cover !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            backdrop-filter: blur(12px);
            color: #ffffff !important;
            font-size: 0.95rem;
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, 'Times New Roman', Georgia, serif !important;
            height: 100vh !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            padding-bottom: 0.5rem !important;
        }}

        [data-testid="stSidebar"] .block-container {{
            padding-top: 0.6rem !important;
            padding-bottom: 0.6rem !important;
            padding-left: 0.8rem !important;
            padding-right: 0.8rem !important;
        }}

        [data-testid="stSidebar"] .sidebar-logo-wrap {{
            width: 100% !important;
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
            margin: 0 auto 0.5rem auto !important;
            padding-left: 0 !important;
            padding-right: 0 !important;
            text-align: center !important;
        }}

        [data-testid="stSidebar"] .sidebar-logo-wrap img {{
            width: 120px;
            max-width: 100%;
            height: auto;
            display: block;
            margin: 0 auto;
        }}

        [data-testid="stSidebar"] [data-testid="stImage"] {{
            width: 100% !important;
            display: flex !important;
            justify-content: center !important;
            margin: 0 auto 0.5rem auto !important;
        }}

        [data-testid="stSidebar"] [data-testid="stImage"] img {{
            display: block !important;
            margin-left: auto !important;
            margin-right: auto !important;
        }}

        @media (max-width: 768px) {{
            [data-testid="stSidebar"] .block-container {{
                padding-left: 0.55rem !important;
                padding-right: 0.55rem !important;
            }}

            [data-testid="stSidebar"] .sidebar-logo-wrap {{
                margin-bottom: 0.4rem !important;
            }}

            [data-testid="stSidebar"] .sidebar-logo-wrap img {{
                width: 110px;
            }}
        }}

        /* Sidebar radio buttons styling */
        [data-testid="stSidebar"] [role="radiogroup"] {{
            background: rgba(255, 255, 255, 0.05) !important;
            padding: 10px !important;
            border-radius: 8px !important;
            border: 1px solid rgba(255, 255, 255, 0.15) !important;
        }}

        [data-testid="stSidebar"] [role="radio"] {{
            color: #ffffff !important;
            font-size: 0.95rem !important;
            font-weight: 600 !important;
            padding: 7px 6px !important;
            line-height: 1.25 !important;
        }}

        [data-testid="stSidebar"] [role="radio"]:hover {{
            background-color: rgba(77, 166, 255, 0.15) !important;
        }}

        /* Sidebar text and widgets contrast */
        [data-testid="stSidebar"] .css-1v0mbdj, [data-testid="stSidebar"] .stButton>button,
        [data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3,
        [data-testid="stSidebar"] h4, [data-testid="stSidebar"] p, [data-testid="stSidebar"] label, [data-testid="stSidebar"] span {{
            color: #ffffff !important;
            font-size: 0.9rem !important;
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, 'Times New Roman', Georgia, serif !important;
            letter-spacing: 0.2px;
        }}

        /* Divider styling */
        [data-testid="stSidebar"] hr {{
            border: none;
            height: 1px;
            background: linear-gradient(to right, rgba(255,255,255,0), rgba(255,255,255,0.3), rgba(255,255,255,0)) !important;
            margin: 18px 0 !important;
        }}

        /* Hide minimize button and keyboard shortcut completely */
        [data-testid="stSidebar"] [aria-label*="keyboard"],
        [data-testid="stSidebar"] [title*="keyboard"],
        [data-testid="stSidebar"] button:has-text("keyboard"),
        button[aria-label*="keyboard"],
        button[title*="keyboard"],
        [data-testid="stSidebar"] button[kind="secondary"] {{
            display: none !important;
            visibility: hidden !important;
        }}
    
        /* Alternative: hide any button in header that might show keyboard */
        [data-testid="stSidebar"] > div:first-child > div:first-child button {{
            display: none !important;
        }}
    
        /* Fix input text color in sidebar */
        [data-testid="stSidebar"] input {{
            color: #ffffff !important;
            font-size: 0.9rem !important;
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, 'Times New Roman', Georgia, serif !important;
            background-color: rgba(255, 255, 255, 0.08) !important;
            border: 1px solid rgba(255, 255, 255, 0.2) !important;
        }}

        [data-testid="stSidebar"] input::placeholder {{
            color: rgba(255, 255, 255, 0.6) !important;
        }}

        [data-testid="stSidebar"] input:focus {{
            border-color: #4da6ff !important;
            box-shadow: 0 0 0 2px rgba(77, 166, 255, 0.2) !important;
        }}

        /* Keep tab style overrides */
        .stTabs [data-baseweb="tab-list"] [data-qa="stTab"] {{
            padding: 12px 20px;
            font-weight: 600;
            color: #ffffff !important;
        }}
        </style>
        """

    st.markdown(page_style, unsafe_allow_html=True)
