import re
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import pytesseract
from PIL import Image, ImageEnhance, ImageFilter

_ocr_cache = {}
_ocr_lock = threading.Lock()

def optimizar_imagen_ocr(pil_img: Image.Image) -> Image.Image:
    """
    Preprocesa imagen para OCR más rápido y preciso.
    - Convierte a escala de grises
    - Mejora contraste
    - Aplica filtro de nitidez
    """
    # Convertir a escala de grises
    img_gray = pil_img.convert('L')

    # Mejorar contraste
    enhancer = ImageEnhance.Contrast(img_gray)
    img_enhanced = enhancer.enhance(1.8)

    # Reducir ruido + nitidez
    img_denoised = img_enhanced.filter(ImageFilter.MedianFilter(size=3))
    img_sharp = img_denoised.filter(ImageFilter.SHARPEN)

    return img_sharp

def limpiar_texto_extraido(texto: str) -> str:
    """Limpia artefactos frecuentes de extracción OCR/PDF sin alterar contenido clínico."""
    if not texto:
        return ""

    t = texto.replace("\r", "\n")
    t = re.sub(r"(\w)-\n(\w)", r"\1\2", t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()

def extraer_texto_nativo_pagina(page) -> str:
    """Intenta extraer texto con pdfplumber priorizando fidelidad antes de OCR."""
    try:
        texto = page.extract_text(layout=True, x_tolerance=2, y_tolerance=2)
        if texto and len(texto.strip()) > 5:
            return limpiar_texto_extraido(texto)
    except Exception:
        pass

    try:
        texto = page.extract_text()
        if texto and len(texto.strip()) > 5:
            return limpiar_texto_extraido(texto)
    except Exception:
        pass

    try:
        words = page.extract_words(use_text_flow=True, keep_blank_chars=False)
        if words:
            texto = " ".join(w.get("text", "") for w in words if w.get("text"))
            if texto and len(texto.strip()) > 5:
                return limpiar_texto_extraido(texto)
    except Exception:
        pass

    return ""

def ocr_rapido_pagina(page_num: int, page, timeout_ocr: float = 15.0) -> tuple:
    """
    OCR optimizado para una página específica.
    Retorna (page_num, texto_ocr, tiempo_procesamiento)
    """
    start = time.time()
    
    try:
        # Intentar extracción nativa primero (más fiel cuando hay capa de texto)
        raw_text = extraer_texto_nativo_pagina(page)
        if raw_text and len(raw_text.strip()) > 5:
            return (page_num, raw_text, time.time() - start)

        # Si no hay texto, OCR multi-estrategia para mejorar calidad
        best_text = ""
        best_score = 0

        for resolution in (200, 300):
            page_image = page.to_image(resolution=resolution)
            pil_img = page_image.original
            pil_img_opt = optimizar_imagen_ocr(pil_img)

            for psm in (6, 4, 11):
                try:
                    ocr_text = pytesseract.image_to_string(
                        pil_img_opt,
                        lang='spa+eng',
                        config=f'--oem 1 --psm {psm}',
                        timeout=timeout_ocr
                    )
                except Exception:
                    continue

                ocr_text = limpiar_texto_extraido(ocr_text)
                if not ocr_text:
                    continue

                score = len(re.findall(r"[A-Za-zÁÉÍÓÚáéíóúÑñ0-9]", ocr_text))
                if score > best_score:
                    best_score = score
                    best_text = ocr_text

        return (page_num, best_text, time.time() - start)
            
    except Exception as e:
        return (page_num, f"[ERROR OCR: {str(e)[:50]}]", time.time() - start)

def procesar_pdf_paralelo(pdf, max_workers: int = 4) -> tuple:
    """
    Procesa múltiples páginas de PDF en paralelo para máxima velocidad.
    Retorna (texto_completo, tiempos_por_pagina)
    """
    texto_completo = ""
    tiempos = {}
    textos_por_pagina = {}
    total_paginas = len(pdf.pages)

    if total_paginas == 0:
        return "", {}

    workers = max(1, min(max_workers, total_paginas))
    
    with ThreadPoolExecutor(max_workers=workers) as executor:
        # Enviar todas las páginas a procesar en paralelo
        futures = {executor.submit(ocr_rapido_pagina, i, page): i 
                   for i, page in enumerate(pdf.pages)}
        
        # Recolectar resultados en orden
        for future in as_completed(futures):
            try:
                page_num, ocr_texto, tiempo_proc = future.result()
                if ocr_texto and not ocr_texto.startswith("[ERROR"):
                    textos_por_pagina[page_num] = ocr_texto
                tiempos[page_num] = tiempo_proc
            except Exception as e:
                print(f"Error procesando página en paralelo: {e}")

    # Reconstruir texto en el orden correcto del documento
    for page_num in sorted(textos_por_pagina.keys()):
        texto_completo += textos_por_pagina[page_num] + "\n"
    
    return texto_completo, tiempos

# Configuración opcional de Tesseract
import os
tess_cmd_env = os.environ.get('TESSERACT_CMD') or os.environ.get('TESSERACT_PATH')
if not tess_cmd_env:
    tess_cmd_env = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
if tess_cmd_env and os.path.exists(tess_cmd_env):
    pytesseract.pytesseract.tesseract_cmd = tess_cmd_env
