import os
import re
import json
from typing import Dict, Any, List, Optional
try:
    import streamlit as st
except Exception:
    st = None

from amylo_ai.config import DEFAULT_DATA, TERMINOLOGIA_MEDICA
from amylo_ai.utils.parsing import (
    safe_float, _normalizar_palabra_numero_es, normalizar_numeros_texto_clinico,
    parsear_json_llm
)
from amylo_ai.clinical.heuristic import diagnostico_ia

client = None
backend_activo = None
llm_model = "llama3.2"
llm_endpoint_activo = ""
llm_provider_activo = ""

def _get_secret_or_env(key: str, default: Optional[str] = None) -> Optional[str]:
    try:
        if st is not None and key in st.secrets:
            value = st.secrets.get(key)
            if value is not None and str(value).strip() != "":
                return str(value)
    except Exception:
        pass
    value_env = os.getenv(key)
    if value_env is not None and str(value_env).strip() != "":
        return str(value_env)
    return default

def _inicializar_llm_local(OpenAI):
    global client, backend_activo, llm_endpoint_activo, llm_provider_activo
    try:
        client = OpenAI(
            base_url="http://localhost:8000/v1",
            api_key="vllm"
        )
        client.models.list()
        backend_activo = "🚀 vLLM (Alto Rendimiento)"
        llm_endpoint_activo = "http://localhost:8000/v1"
        llm_provider_activo = "vLLM local"
        return
    except Exception:
        pass

    try:
        client = OpenAI(
            base_url="http://localhost:11434/v1",
            api_key="ollama"
        )
        client.models.list()
        backend_activo = "🤖 Ollama (Local)"
        llm_endpoint_activo = "http://localhost:11434/v1"
        llm_provider_activo = "Ollama local"
        return
    except Exception:
        client = None
        backend_activo = "🛡️ Regex (Sin LLM disponible)"
        llm_endpoint_activo = ""
        llm_provider_activo = "Regex/Fallback"

try:
    from openai import OpenAI
    llm_model = _get_secret_or_env("LLM_MODEL", "llama3.2")

    remote_base_url = _get_secret_or_env("LLM_BASE_URL") or _get_secret_or_env("OPENAI_BASE_URL")
    remote_api_key = _get_secret_or_env("LLM_API_KEY") or _get_secret_or_env("OPENAI_API_KEY")

    # Si hay API key pero no base URL, usar OpenAI por defecto (OpenAI-compatible)
    if remote_api_key and not remote_base_url:
        remote_base_url = "https://api.openai.com/v1"

    if remote_base_url and remote_api_key:
        try:
            remote_base_url = str(remote_base_url).rstrip("/")
            if not remote_base_url.endswith("/v1"):
                remote_base_url = f"{remote_base_url}/v1"

            client = OpenAI(
                base_url=remote_base_url,
                api_key=str(remote_api_key)
            )
            client.models.list()
            if "api.openai.com" in remote_base_url:
                backend_activo = "☁️ OpenAI (st.secrets)"
                llm_provider_activo = "OpenAI"
            else:
                backend_activo = "☁️ Endpoint remoto (st.secrets)"
                llm_provider_activo = "OpenAI-compatible remoto"
            llm_endpoint_activo = remote_base_url
        except Exception:
            _inicializar_llm_local(OpenAI)
    else:
        _inicializar_llm_local(OpenAI)
            
except Exception:
    client = None
    backend_activo = "🛡️ Regex (Sin LLM disponible)"
    llm_endpoint_activo = ""
    llm_provider_activo = "Regex/Fallback"

def generar_instrucciones_contexto():
    """Genera un prompt optimizado usando el tesauro comprimido"""
    texto = "VOCABULARIO MÉDICO A DETECTAR (SINÓNIMOS ACEPTADOS):\n"
    for clave, valor in TERMINOLOGIA_MEDICA.items():
        texto += f"- {clave}: [{valor}]\n"
    return texto

def validar_rangos_clinicos(datos: Dict[str, Any]) -> Dict[str, Any]:
    """Filtra valores fisiológicamente imposibles o errores de OCR"""
    if datos.get('ivs', 0) > 35:
        datos['ivs'] = 0.0

    if datos.get('volt', 0) > 6:
        datos['volt'] = 0.0

    gls = datos.get('gls', 0)
    if gls > 0:
        gls = -gls

    if gls < -40:
        gls = 0.0

    datos['gls'] = gls
    return datos

def correccion_determinista(texto: str, datos: Dict[str, Any]) -> Dict[str, Any]:
    """Capa de seguridad Regex + Censor Universal V3 (Fix Microvoltajes, BAV, Biomarcadores, RM)"""
    texto_norm = normalizar_numeros_texto_clinico(texto)
    t = texto_norm.lower()
    t_ascii = _normalizar_palabra_numero_es(t)

    # --- A. RESCATE DE POSITIVOS (Keywords que la IA ignora) ---
    
    # FIX VOLTAJE: Añadimos "microvoltaje" como disparador directo
    if not datos.get('volt'):
        if (
            "bajo voltaje" in t
            or "microvoltaje" in t
            or "voltajes eléctricos anormalmente bajos" in t
            or "voltajes anormalmente bajos" in t
            or "voltajes bajos" in t
        ):
            datos['volt'] = 0.4
            datos['bajo_voltaje'] = True
        else:
            # Busca "QRS de X mm" o "Voltaje de X mV"
            match = re.search(r"(voltaje|qrs).{0,15}?(\d+[,.]?\d*)", t)
            if match:
                val = float(match.group(2).replace(',', '.'))
                # Si el valor es > 5, probablemente sean mm (Sokolow), no mV. 
                # Convertimos mm a mV dividiendo por 10 si es necesario, o lo ignoramos si es ambiguo.
                if 0 < val < 5: 
                    datos['volt'] = val

    # Si el texto afirma voltaje conservado/normal, anula bajo voltaje
    if re.search(r"(voltajes?\s+(conservados?|normales?)|sin\s+bajo\s+voltaje|no\s+bajo\s+voltaje)", t) or re.search(r"(voltajes?\s+(conservados?|normales?)|sin\s+bajo\s+voltaje|no\s+bajo\s+voltaje)", t_ascii):
        datos['bajo_voltaje'] = False
        if safe_float(datos.get('volt', 0)) == 0:
            datos['volt'] = 1.1

    # RESCATE BIOMARCADORES NUMÉRICOS
    # NT-proBNP
    if not datos.get('nt_probnp'):
        match = re.search(r"(nt-?probnp|bnp).{0,15}?(\d+(\.\d+)?|,\d+)", t)
        if match:
            val = float(match.group(2).replace(',', '.'))
            if val > 0:
                datos['nt_probnp'] = val
        elif (
            "nt-probnp" in t or "nt probnp" in t or "bnp" in t
        ) and (
            "marcadamente elevado" in t
            or "muy elevado" in t
            or "elevado" in t
            or "elevación marcada" in t
        ):
            # Rescate cualitativo cuando no hay cifra explícita
            datos['nt_probnp'] = 3500.0
    
    # ECV (Volumen Extracelular)
    if not datos.get('ecv'):
        match = re.search(r"(ecv|volumen extracelular).{0,15}?(\d+)%?", t)
        if match:
            val = float(match.group(2))
            if 0 < val <= 100:
                datos['ecv'] = val
    
    # Septum/Pared Posterior
    if not datos.get('septum_posterior'):
        match = re.search(r"(tabique|pared posterior|septum).{0,20}?(\d+[,.]?\d*)", t)
        if match:
            val = float(match.group(2).replace(',', '.'))
            if 5 < val < 30:  # Rango fisiológico (mm)
                datos['septum_posterior'] = val
    
    # Edad
    if not datos.get('edad'):
        match = re.search(r"(\d{1,3})\s*(?:años|a[ña]o|yrs)", t)
        if match:
            edad = int(match.group(1))
            if 0 < edad < 150:
                datos['edad'] = edad
    
    # LGE Patrón (Resonancia) - negación dominante aunque venga marcado por LLM
    if re.search(r"(sin|niega|no|ausencia de).{0,120}(subendocardic|transmural|difuso|parcheado|realce tard[ií]o)", t) or re.search(r"(sin|niega|no|ausencia de).{0,120}(subendocardic|transmural|difuso|parcheado|realce tardio)", t_ascii):
        datos['lge_patron'] = ""
    elif not datos.get('lge_patron') or datos.get('lge_patron') == '':
        if "subendocárdico" in t or "subendocardico" in t:
            datos['lge_patron'] = "subendocardico"
        elif "transmural" in t:
            datos['lge_patron'] = "transmural"
        elif "difuso" in t:
            datos['lge_patron'] = "difuso"
        elif "parcheado" in t or "parcheado" in t:
            datos['lge_patron'] = "parcheado"

    # FIX AMILOIDOSIS AL: Rescate de palabras clave
    triggers_mgus = ["monoclonal", "inmunofijación positiva", "banda m ", "pico m ", "cadenas ligeras"]
    if any(x in t for x in triggers_mgus):
        # Solo marca True si NO hay una negación cerca
        if not re.search(r"(no |ausencia|negativ).{0,30}(monoclonal|inmunofijación|banda|pico)", t):
            datos['mgus'] = True

    if re.search(r"\bmacroglosia\b|\bimprontas\b", t) or re.search(r"\bmacroglosia\b|\bimprontas\b", t_ascii):
        if not (re.search(r"(niega|sin|no|ausencia de).{0,80}(macroglosia|improntas)", t) or re.search(r"(niega|sin|no|ausencia de).{0,80}(macroglosia|improntas)", t_ascii)):
            datos['macro'] = True

    if re.search(r"\bpurpura\b|\bpúrpura\b|periorbital", t) or re.search(r"\bpurpura\b|periorbital", t_ascii):
        if not (re.search(r"(niega|sin|no|ausencia de).{0,80}(purpura|púrpura|periorbital)", t) or re.search(r"(niega|sin|no|ausencia de).{0,80}(purpura|periorbital)", t_ascii)):
            datos['purpura'] = True

    # Biauricular: no inferir por aurícula izquierda aislada
    if (re.search(r"aur[ií]cula\s+izquierda", t) or re.search(r"auricula\s+izquierda", t_ascii)) and not (re.search(r"biatrial|biauricular|ambas\s+aur[ií]culas", t) or re.search(r"biatrial|biauricular|ambas\s+auriculas", t_ascii)):
        datos['biatrial'] = False

    # --- B. CENSOR DE ALUCINACIONES (Correcciones lógicas) ---
    
    # FIX BAV: Si dice "Ritmo Sinusal" y NO menciona bloqueo/marcapasos, fuerza False
    if "ritmo sinusal" in t or "rs a " in t:
        if not any(x in t for x in ["bloqueo", "bav", "marcapasos", "mp "]):
            datos['bav_mp'] = False

    # FIX SIV: Rescate numérico si la IA falló la conversión cm -> mm
    if not datos.get('ivs'):
        # Busca patrones como "SIV 1.6 cm" o "Septum 16 mm"
        match = re.search(r"(siv|septo|tabique|septum).{0,20}?(\d+[,.]?\d*)", t)
        if match:
            valor = float(match.group(2).replace(',', '.'))
            # Si el valor es pequeño (ej: 1.6), asume cm y multiplica por 10
            if 0.6 <= valor <= 3.0: 
                datos['ivs'] = valor * 10.0
            # Si es normal (ej: 16), lo deja tal cual
            elif 6 < valor < 30: 
                datos['ivs'] = valor

    # Rescate de engrosamiento/hipertrofia VI con texto narrativo
    if not datos.get('ivs'):
        match = re.search(
            r"(engrosamiento|hipertrofia).{0,45}?(ventr[íi]culo\s*izquierdo|\bvi\b).{0,20}?(\d+[,.]?\d*)\s*mm",
            t
        )
        if match:
            valor = float(match.group(3).replace(',', '.'))
            if 6 < valor < 30:
                datos['ivs'] = valor

    if not datos.get('ivs'):
        if ("engrosamiento severo" in t or "hipertrofia severa" in t) and ("ventrículo izquierdo" in t or "ventriculo izquierdo" in t or " vi " in f" {t} "):
            datos['ivs'] = 16.0
        elif ("engrosamiento moderado" in t or "hipertrofia moderada" in t) and ("ventrículo izquierdo" in t or "ventriculo izquierdo" in t or " vi " in f" {t} "):
            datos['ivs'] = 13.0

    # Rescate de síndrome nefrótico/proteinuria severa en texto libre
    if not datos.get('nefro'):
        if (
            "síndrome nefrótico" in t
            or "sindrome nefrotico" in t
            or "proteinuria severa" in t
            or "proteinuria en rango nefrótico" in t
            or "proteinuria en rango nefrotico" in t
            or "orina muy espumosa" in t
            or "orina espumosa" in t
        ):
            datos['nefro'] = True

    # Rescate de fatiga severa cualitativa
    if not datos.get('fatiga'):
        if "fatiga extrema" in t or "fatiga severa" in t or "agotamiento extremo" in t:
            datos['fatiga'] = True

    # --- C. CENSOR UNIVERSAL (Negaciones estándar) ---
    patron_base = r"(niega|no |sin |ausencia|descarta|normal|negativo).{0,120}?"

    for k, v_str in TERMINOLOGIA_MEDICA.items():
        # Si el dato está marcado como True, verificamos que no sea un falso positivo por negación
        if datos.get(k) is True:
            regex_keywords = f"({v_str})"
            if re.search(patron_base + regex_keywords, t, re.IGNORECASE):
                datos[k] = False

    return validar_rangos_clinicos(datos)

def fusionar_extracciones(extracciones: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Combina datos con Lógica GLS corregida"""
    final = DEFAULT_DATA.copy()
    origen = {}

    for item in extracciones:
        doc_name = item["documento"]
        datos_limpios = {k: v for k, v in item["datos"].items() if k in DEFAULT_DATA}

        for k, v in datos_limpios.items():
            current_val = final.get(k)

            # Booleanos (OR)
            if isinstance(v, bool):
                if v is True:
                    final[k] = True
                    origen[k] = doc_name

            # Numéricos
            elif isinstance(v, (int, float)):
                v_float = safe_float(v)
                curr_float = safe_float(current_val)

                # GLS: Queremos el MENOS negativo (más cercano a 0 = peor función)
                if k == "gls":
                    if v_float != 0:
                        if curr_float == 0:
                            final[k] = v_float
                            origen[k] = doc_name
                        elif abs(v_float) < abs(curr_float):
                            final[k] = v_float
                            origen[k] = doc_name

                # Resto (IVS, Volt): Nos quedamos con el mayor
                else:
                    if abs(v_float) > abs(curr_float):
                        final[k] = v_float
                        origen[k] = doc_name

    final["_origen"] = origen
    return final

def motor_nlp_hibrido(texto: str, use_llm: bool = True) -> Dict[str, Any]:
    """
    Motor HÍBRIDO: Regex (rápido) + LLM (preciso) donde falta.
    Tiempo: 2-5s (mucho mejor que 10-30s del LLM puro).
    Precisión: 95%+ (datos complejos con LLM de respaldo).
    """
    datos = DEFAULT_DATA.copy()
    
    if not texto.strip():
        return datos
    
    texto_normalizado = normalizar_numeros_texto_clinico(texto)
    texto_lower = texto_normalizado.lower()
    
    # ===== PASO 1: REGEX PARA DATOS NUMÉRICOS CLAROS (Muy rápido) =====
    
    # IVS / Septum - patrones mejorados
    ivs_patterns = [
        r'ivs\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # IVS: 15
        r'septo\s*[:=]\s*(\d+(?:[.,]\d+)?)\s*mm',  # Septo: 15mm
        r'septum\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # Septum: 15
        r'grosor.*septo\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # Grosor septo: 15
        r'septo.*(\d+(?:[.,]\d+)?)\s*(?:mm)',  # Septo 15mm
        r'espesor.*septo\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # Espesor septo: 15
    ]
    for pattern in ivs_patterns:
        match = re.search(pattern, texto_lower)
        if match:
            val = match.group(1).replace(',', '.')
            try:
                datos['ivs'] = float(val)
                break
            except:
                pass
    
    # GLS / Strain - patrones mejorados
    gls_patterns = [
        r'gls\s*[:=]\s*(-?\d+(?:[.,]\d+)?)',  # GLS: -15
        r'strain\s*(?:global)?\s*[:=]\s*(-?\d+(?:[.,]\d+)?)',  # Strain: -15
        r'strain.*(?:longitudinal|global)\s*[:=]?\s*(-?\d+(?:[.,]\d+)?)',  # Strain longitudinal: -15
        r'longitudinal.*strain\s*[:=]\s*(-?\d+(?:[.,]\d+)?)',  # Longitudinal strain: -15
    ]
    for pattern in gls_patterns:
        match = re.search(pattern, texto_lower)
        if match:
            val = match.group(1).replace(',', '.')
            try:
                datos['gls'] = -abs(float(val))
                break
            except:
                pass
    
    # NT-proBNP - patrones mejorados
    bnp_patterns = [
        r'nt-?pro?bnp\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # NT-proBNP: 4200
        r'bnp\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # BNP: 4200
        r'n-?terminal\s*pro\s*bnp\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # N-terminal pro BNP: 4200
    ]
    for pattern in bnp_patterns:
        match = re.search(pattern, texto_lower)
        if match:
            val = match.group(1).replace(',', '.')
            try:
                datos['nt_probnp'] = float(val)
                break
            except:
                pass
    
    # ECV (Extracellular Volume)
    ecv_patterns = [
        r'ecv\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # ECV: 45
        r'volumen.*extracelular\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # Volumen extracelular: 45
        r'extracellular.*volume\s*[:=]\s*(\d+(?:[.,]\d+)?)',  # Extracellular volume: 45
    ]
    for pattern in ecv_patterns:
        match = re.search(pattern, texto_lower)
        if match:
            val = match.group(1).replace(',', '.')
            try:
                datos['ecv'] = float(val)
                break
            except:
                pass
    
    # Edad - mejorada
    edad_patterns = [
        r'edad\s*[:=]\s*(\d{1,3})',  # Edad: 72
        r'(?:paciente|pt)\s*(?:de\s*)?(?:sexo\s*)?(?:masculino|femenino|varón|mujer)?\s*(?:de\s*)?(\d{1,3})\s*(?:años|year|yo|años)',  # Paciente de 72 años
        r'(\d{1,3})\s*(?:años|year|yo)',  # 72 años
    ]
    for pattern in edad_patterns:
        match = re.search(pattern, texto_lower)
        if match:
            try:
                datos['edad'] = int(match.group(1))
                break
            except:
                pass
    
    # Sexo
    if re.search(r'varón|hombre|male|masculine', texto_lower):
        datos['sexo'] = 'M'
    elif re.search(r'mujer|femenino|female|feminine', texto_lower):
        datos['sexo'] = 'F'
    
    # ===== PASO 2: PATRONES BOOLEANOS SIMPLES (Regex completo) =====
    # Hallazgos que regex puede detectar bien
    
    boolean_patterns = {
        'apical_sparing': (r'apical\s*sparing|preservación.*apical|sparing.*apical|preserved.*apex', r'sin.*apical|no.*apical'),
        'bajo_voltaje': (r'bajo\s*voltaje|low\s*voltage|microlvoltaje|qrs.*bajo|voltaje.*bajo', r'sin.*voltaje|voltaje.*normal'),
        'bav_mp': (r'bloqueo\s*av|bloqueo\s*atrioventricular|marcapasos|pacemaker|bav\s*(?:completo|alto)', r'sin.*bav|bav.*no'),
        'biatrial': (
            r'biatrial|biauricular|dilataci[oó]n\s+de\s+ambas\s+aur[ií]culas|ambas\s+aur[ií]culas\s+dilatadas',
            r'sin.*biauricular|sin.*biatrial|aur[ií]cula\s+izquierda\s+(?:discretamente\s+)?dilatada'
        ),
        'derrame_pericardico': (r'derrame(?:\s*pericárd)?|pericardial\s*effusion|efusión(?:\s*pericárdica)?', r'sin.*derrame|sin.*efusión|derrame.*no'),
        'troponina': (r'troponina\s*(?:elevada|alta|positive|high|positiva|\+)', r'troponina\s*(?:normal|baja|negativa|-)'),
        'macro': (r'macroglosia|agrandada.*lengua|lengua.*agrandada|enlarged.*tongue', r'sin.*macroglosia|lengua.*normal'),
        'purpura': (r'púrpura|purpura|periorbital|ojos\s*mapache', r'sin.*púrpura|púrpura.*no'),
        'stc': (r'túnel.*carp|carpal\s*tunnel|s\.?t\.?c\.?|atrapamiento.*mediano', r'niega.*stc|sin.*stc|stc.*no|bilateral.*niega'),
        'biceps': (r'rotura.*bíceps|bíceps.*rotura|popeye|rupture.*biceps', r'sin.*bíceps|bíceps.*no|bíceps.*intacto'),
        'lumbar': (r'estenosis.*lumbar|stenosis.*lumbar|claudicación.*neuro|compresión.*lumbar', r'sin.*lumbar|lumbar.*normal|estenosis.*no'),
        'nefro': (r'síndrome.*nefrótico|nephrotic.*syndrome|proteinuria|glomerulon', r'sin.*nefrótico|nefrótico.*no|síndrome.*no'),
        'neuro_p': (r'polineuropatía|polyneuropathy|neuropatía|parestesia|neuropatía.*periférica', r'sin.*neuropatía|neuropatía.*no|periférica.*no'),
        'disauto': (r'disautonomía|autonomic|hipotensión.*orto|diarrea|hipohidrosis', r'sin.*disautonomía|disautonomía.*no'),
        'hepato': (r'hepatomegalia|agrandado.*hígado|hígado.*agrandado|enlarged.*liver', r'sin.*hepato|hígado.*normal|hepato.*no'),
        'fatiga': (r'fatiga\s*(?:severa|extrema|intensa)|extreme\s*fatigue|agotamiento', r'sin.*fatiga|fatiga.*no'),
        'mutacion_ttr': (r'mutación.*ttr|ttr.*mutado|attr.*hereditara|hereditary.*ttr', r'ttr.*no|sin.*mutación|mutación.*no'),
    }
    
    for key, (positive_pattern, negative_pattern) in boolean_patterns.items():
        if re.search(positive_pattern, texto_lower):
            # Verificar si está negado
            if not re.search(negative_pattern, texto_lower):
                datos[key] = True
    
    # ===== PASO 3: CAMPOS COMPLEJOS - USAR LLM SOLO SI REGEX FALLA =====
    # Si falta información crítica, usar LLM smart para extraer lo faltante
    
    campos_criticos = ['ivs', 'edad', 'gls', 'nt_probnp', 'lge_patron']
    campos_faltantes = [k for k in campos_criticos if (datos[k] == 0 and k != 'lge_patron') or (k == 'lge_patron' and datos[k] == '')]
    
    if campos_faltantes and client and use_llm:
        # Solo usar LLM para campos que regex NO pudo extraer
        prompt_mini = f"""Extrae SOLO estos campos del texto en JSON válido:
{json.dumps({k: datos[k] for k in campos_faltantes})}

Texto: \"\"\"{texto}\"\"\"
Texto normalizado: \"\"\"{texto_normalizado}\"\"\"

Responde solo con JSON válido, reemplazando valores NULL por los encontrados.
No agregues campos adicionales."""
        
        try:
            data_ia = solicitar_json_llm(prompt_mini, model=llm_model)
            data_ia = normalizar_extraccion_llm(
                data_ia,
                only_keys=campos_faltantes,
                base_data={k: datos.get(k, DEFAULT_DATA.get(k)) for k in campos_faltantes}
            )
            # Mezclar: regex tiene prioridad, LLM solo rellena vacíos
            for k in campos_faltantes:
                if k in data_ia and data_ia[k] is not None:
                    datos[k] = data_ia[k]
        except:
            pass  # Mantener los valores de regex
    
    # ===== PATRÓN LGE (CATEGORÍA) - Detectar automáticamente =====
    if re.search(r'subendocardio|subendocárdic', texto_lower):
        datos['lge_patron'] = 'subendocardico'
    elif re.search(r'transmural|transmurale', texto_lower):
        datos['lge_patron'] = 'transmural'
    elif re.search(r'parche|patchy', texto_lower):
        datos['lge_patron'] = 'parcheado'
    elif re.search(r'difuso', texto_lower):
        datos['lge_patron'] = 'difuso'

    if client and use_llm:
        datos['_modelo'] = f"🧠 Híbrido ({backend_activo or 'LLM'})"
    else:
        datos['_modelo'] = "🛡️ Regex (LLM no disponible)"
    
    return datos

def motor_nlp_contextual(texto: str) -> Dict[str, Any]:
    """Motor NLP V4: Máxima precisión - LLM con instrucciones mejoradas"""
    if not texto.strip(): 
        return DEFAULT_DATA.copy()
    texto_normalizado = normalizar_numeros_texto_clinico(texto)
    
    modelo_usado = f"🤖 {llm_model} + Regex ({backend_activo or 'LLM'})"

    if not client:
        datos = correccion_determinista(texto, {})
        datos['_modelo'] = "🛡️ Regex (LLM no disponible)"
        return datos

    try:
        instrucciones = generar_instrucciones_contexto()
        
        # PROMPT V4: MEJORADO PARA MÁXIMA PRECISIÓN Y FLEXIBILIDAD
        prompt = f"""ERES UN CARDIÓLOGO EXPERTO EN AMILOIDOSIS.

Tu tarea: Extraer datos COMPLETOS de la nota clínica, sin importar cómo esté redactada.

### INSTRUCCIONES CRÍTICAS:
1. Lee TODO el texto cuidadosamente, párrafo por párrafo
2. Busca CUALQUIER mención de los datos solicitados
3. Si dice "Edad 72 años", "72 años", "setenta y dos", "72", extrae 72
4. Si dice "septo 1.8cm", "septum 18mm", "IVS 1.8", extrae como número (1.8 o 18)
5. Si dice "niega", "sin", "normal", "ausente" → false
6. Si menciona síntoma/hallazgo sin negación → true
7. Para textos ambiguos: interpreta como médico (contexto clínico)
8. NO inventes ni infieras datos ausentes; usa SOLO evidencia textual explícita.
9. Si un hallazgo aparece como "descartar", "duda", "probable" o antecedente familiar, NO marcar como presente.

### CAMPOS NUMÉRICOS (convertir TODO a número):
- ivs: Grosor septum/septo (en mm, si está en cm multiplicar x10)
- volt: Voltaje ECG (0.4=bajo, 1.0+ normal). Si dice "bajo voltaje" → 0.4
- gls: Global Longitudinal Strain (número negativo). Si dice "strain -10%" → -10
- edad: Años del paciente (número entero)
- nt_probnp: BNP (número bruto, ej: 4200)
- ecv: Volumen extracelular (0-100)
- septum_posterior: Grosor pared posterior (mm), también llamado "PP", "espesor pared posterior"
- t1_mapping: Valor T1 nativo (ms). Si dice "T1 prolongado" → booleano true, sino 0


### CAMPOS BOOLEANOS (true SOLO si está CLARAMENTE mencionado):
Busca estas palabras EXACTAS o sus sinónimos:
- apical_sparing: "apical sparing", "preservación apical", "sparing"
- bajo_voltaje: "bajo voltaje", "microvoltaje", "reduced voltage"
- bav_mp: "bloqueo AV", "BAV", "marcapasos", "pacemaker"
- biatrial: "dilatación auricular", "biatrial", "aurícula"
- derrame_pericardico: "derrame", "efusión pericárdica"
- troponina: "troponina elevada", "troponina alta", "troponina positiva"
- macro: "macroglosia", "lengua agrandada"
- purpura: "púrpura", "periorbital", "ojos mapache"
- mgus: "MGUS", "componente monoclonal", "cadena ligera"
- stc: "túnel carpiano", "STC", "carpal tunnel" (BILATERAL en ATTR)
- biceps: "rotura bíceps", "popeye", "biceps rupture"
- lumbar: "estenosis lumbar", "claudicación", "lumbar stenosis"
- nefro: "síndrome nefrótico", "proteinuria", "nephrotic"
- neuro_p: "polineuropatía", "neuropatía periférica", "polyneuropathy"
- disauto: "disautonomía", "hipotensión ortostática", "autonomic"
- hepato: "hepatomegalia", "hígado agrandado"
- fatiga: "fatiga severa", "agotamiento extremo"
- mutacion_ttr: "mutación TTR", "hereditary ATTR", "ATTR mutado"

### CAMPO CATEGORÍA (ELEGIR UNO):
lge_patron: 
  - "subendocardico" si dice "subendocárdico", "subendocardial"
  - "transmural" si dice "transmural", "circunferencial"
  - "parcheado" si dice "parcheado", "patchy"
  - "difuso" si dice "difuso", "diffuse"
  - "" si no menciona

### SEXO:
- "M" si dice varón/hombre/male/masculino
- "F" si dice mujer/femenino/female/femenina
- "" si no especifica

### DATOS INCOMPLETOS:
Si una dato NO está en el texto:
- Números → 0 (para ivs, edad, voltaje, etc.)
- Booleanos → false
- Texto → cadena vacía ""

### EJEMPLO PRÁCTICO:
Entrada: "Mujer 68 años. Ecocardiograma con septo 16, strain -8. RM con LGE subendocárdico. ECV 42%. Sin antecedentes de STC."

Salida:
{{
  "ivs": 16.0,
  "volt": 1.0,
  "gls": -8.0,
  "edad": 68,
  "sexo": "F",
  "nt_probnp": 0.0,
  "troponina": false,
  "lge_patron": "subendocardico",
  "ecv": 42.0,
  "derrame_pericardico": false,
  "stc": false,
  ...todos los demás: false
}}

### AHORA ANALIZA ESTE TEXTO:
\"\"\"{texto}\"\"\"

### TEXTO NORMALIZADO (apoyo para números en palabras):
\"\"\"{texto_normalizado}\"\"\"

RESPONDE SOLO CON JSON VÁLIDO. Rellena TODOS los campos."""

        data_ia = solicitar_json_llm(prompt, model=llm_model)
        datos_filtrados = normalizar_extraccion_llm(data_ia)

        # Fusión conservadora: LLM primero, regex solo rescata señales confiables
        base_regex = motor_nlp_hibrido(texto, use_llm=False)
        datos_filtrados = fusionar_llm_regex_conservador(datos_filtrados, base_regex)

        # Segunda pasada focalizada para campos críticos aún vacíos
        campos_criticos = ['ivs', 'edad', 'gls', 'nt_probnp', 'lge_patron', 'volt']
        campos_faltantes = [
            k for k in campos_criticos
            if (k != 'lge_patron' and safe_float(datos_filtrados.get(k, 0)) == 0)
            or (k == 'lge_patron' and str(datos_filtrados.get(k, '')).strip() == '')
        ]
        if campos_faltantes:
            prompt_rescate = f"""Extrae SOLO estos campos faltantes en JSON válido:
{json.dumps({k: datos_filtrados.get(k, DEFAULT_DATA.get(k)) for k in campos_faltantes})}

Texto clínico original: \"\"\"{texto}\"\"\"
Texto clínico normalizado: \"\"\"{texto_normalizado}\"\"\"

Reglas:
- No inventar datos.
- Si no hay evidencia explícita, dejar valor por defecto.
- Responder SOLO JSON.
"""
            data_rescate = solicitar_json_llm(prompt_rescate, model=llm_model)
            data_rescate = normalizar_extraccion_llm(
                data_rescate,
                only_keys=campos_faltantes,
                base_data={k: datos_filtrados.get(k, DEFAULT_DATA.get(k)) for k in campos_faltantes}
            )
            for k in campos_faltantes:
                v = data_rescate.get(k, DEFAULT_DATA.get(k))
                if k == 'lge_patron':
                    if str(v).strip() != '':
                        datos_filtrados[k] = v
                elif safe_float(v) != safe_float(DEFAULT_DATA.get(k, 0)):
                    datos_filtrados[k] = v

        # Validación final determinista (respaldo adicional)
        resultado_final = correccion_determinista(texto, datos_filtrados)
        resultado_final['_modelo'] = modelo_usado
        return resultado_final

    except Exception as e:
        print(f"⚠️ Error IA: {e}")
        datos = correccion_determinista(texto, {})
        datos['_modelo'] = "🛡️ Regex (Respaldo por Error)"
        return datos

def generar_diagnostico_por_llm(datos: Dict[str, Any]) -> Dict[str, Any]:
    """Solicita al LLM un diagnóstico clínico breve basado en los hallazgos.
    Retorna dict {'diagnostico_llm': str, 'confianza_llm': float}
    Si no hay cliente LLM disponible, hace fallback a `diagnostico_ia`.
    """
    def normalizar_diagnostico_llm(texto: str) -> str:
        """Normaliza el texto del LLM a la nomenclatura del algoritmo."""
        if not texto:
            return "BAJA / SANO"

        t = str(texto).upper()

        if "AL" in t and ("ALTA" in t or "SOSPECHA" in t):
            return "ALTA SOSPECHA (AL)"
        if "ATTR" in t:
            return "ALTA PROBABILIDAD (ATTR)"
        if "INTERMEDIA" in t:
            return "INTERMEDIA (Screening)"
        if "HVI" in t or "HIPERTROFIA" in t:
            return "HVI No Amiloide"
        if "BAJA" in t or "SANO" in t or "CONTROL" in t:
            return "BAJA / SANO"

        return "BAJA / SANO"
    # Construir resumen compacto
    resumen_items = []
    resumen_items.append(f"Edad: {datos.get('edad', 'N/A')}")
    resumen_items.append(f"Sexo: {datos.get('sexo', 'N/A')}")
    ivs_prompt = safe_float(datos.get('ivs', 0))
    gls_prompt = safe_float(datos.get('gls', 0))
    volt_prompt = safe_float(datos.get('volt', 0))
    ntprobnp_prompt = safe_float(datos.get('nt_probnp', 0))
    ecv_prompt = safe_float(datos.get('ecv', 0))
    resumen_items.append(f"IVS: {ivs_prompt if ivs_prompt > 0 else 'No reportado'}")
    resumen_items.append(f"GLS: {gls_prompt if gls_prompt != 0 else 'No reportado'}")
    resumen_items.append(f"Volt: {volt_prompt if volt_prompt > 0 else 'No reportado'}")
    resumen_items.append(f"NT-proBNP: {ntprobnp_prompt if ntprobnp_prompt > 0 else 'No reportado'}")
    resumen_items.append(f"ECV: {ecv_prompt if ecv_prompt > 0 else 'No reportado'}")

    # Añadir red flags positivos (lista de claves con valor verdadero/1)
    rf_keys = [k for k in datos.keys() if k in DEFAULT_DATA and k not in ['edad','sexo','ivs','gls','volt','nt_probnp','ecv','confianza_ia','modelo_usado']]
    rf_pos = [k for k in rf_keys if str(datos.get(k, '')).lower() not in ['', '0', '0.0', 'false', 'none']]
    if rf_pos:
        resumen_items.append('RedFlags: ' + ','.join(rf_pos[:10]))

    prompt = (
        "Actúa como cardiólogo experto y selecciona SOLO una de estas etiquetas exactas: "
        "'ALTA SOSPECHA (AL)', 'ALTA PROBABILIDAD (ATTR)', 'INTERMEDIA (Screening)', "
        "'HVI No Amiloide', 'BAJA / SANO'.\n\n" +
        "\n".join(resumen_items) + "\n\nResponde SOLO con la etiqueta exacta."
    )

    # Si no hay cliente LLM, fallback a heurística local
    if not client:
        diag = diagnostico_ia(datos)
        return {'diagnostico_llm': normalizar_diagnostico_llm(diag), 'confianza_llm': 0.0}

    try:
        resp = client.chat.completions.create(
            model=llm_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            top_p=1,
        )
        text = ''
        try:
            text = resp.choices[0].message.content.strip()
        except Exception:
            text = str(resp)
        diag_line = text.splitlines()[0] if text else diagnostico_ia(datos)
        # No extraemos confianza numérica del LLM por ahora
        return {'diagnostico_llm': normalizar_diagnostico_llm(diag_line), 'confianza_llm': 0.0}
    except Exception:
        diag = diagnostico_ia(datos)
        return {'diagnostico_llm': normalizar_diagnostico_llm(diag), 'confianza_llm': 0.0}

def normalizar_extraccion_llm(
    data_ia: Dict[str, Any],
    only_keys: Optional[List[str]] = None,
    base_data: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Normaliza tipos y rangos de la extracción de IA con DEFAULT_DATA como contrato."""
    keys = list(only_keys) if only_keys else list(DEFAULT_DATA.keys())
    base = (base_data or DEFAULT_DATA).copy()
    salida: Dict[str, Any] = {}
    truthy = {"1", "true", "yes", "si", "sí", "positivo", "presente"}

    for key in keys:
        default_val = DEFAULT_DATA.get(key, base.get(key, ""))
        raw_val = data_ia.get(key, base.get(key, default_val))

        if isinstance(default_val, bool):
            if isinstance(raw_val, bool):
                salida[key] = raw_val
            elif isinstance(raw_val, (int, float)):
                salida[key] = bool(raw_val)
            else:
                salida[key] = str(raw_val).strip().lower() in truthy
        elif isinstance(default_val, int) and not isinstance(default_val, bool):
            salida[key] = int(round(safe_float(raw_val)))
        elif isinstance(default_val, float):
            salida[key] = float(safe_float(raw_val))
        else:
            salida[key] = str(raw_val).strip() if raw_val is not None else ""

    if 'gls' in salida:
        gls_val = safe_float(salida.get('gls'))
        salida['gls'] = -abs(gls_val) if gls_val != 0 else 0.0

    if 'sexo' in salida:
        sx = str(salida.get('sexo', '')).upper().strip()
        salida['sexo'] = sx[:1] if sx[:1] in ('M', 'F') else ''

    if 'lge_patron' in salida:
        lge = str(salida.get('lge_patron', '')).lower().strip()
        mapa_lge = {
            'subendocárdico': 'subendocardico',
            'subendocardial': 'subendocardico',
            'transmurale': 'transmural',
            'diffuse': 'difuso',
            'patchy': 'parcheado',
        }
        salida['lge_patron'] = mapa_lge.get(lge, lge)

    if 'edad' in salida:
        salida['edad'] = max(0, min(120, int(safe_float(salida.get('edad', 0)))))

    salida = validar_rangos_clinicos(salida)
    return salida

def solicitar_json_llm(prompt: str, model: Optional[str] = None) -> Dict[str, Any]:
    """Solicita extracción JSON al LLM con parámetros deterministas y fallback seguro."""
    if not client:
        return {}

    model_name = model or llm_model
    payload = {
        "model": model_name,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "top_p": 1,
    }

    try:
        r = client.chat.completions.create(
            **payload,
            response_format={"type": "json_object"},
            stream=False,
        )
        raw_content = r.choices[0].message.content if r and r.choices else ""
        return parsear_json_llm(raw_content)
    except Exception:
        try:
            r = client.chat.completions.create(**payload, stream=False)
            raw_content = r.choices[0].message.content if r and r.choices else ""
            return parsear_json_llm(raw_content)
        except Exception:
            return {}

def fusionar_llm_regex_conservador(datos_llm: Dict[str, Any], datos_regex: Dict[str, Any]) -> Dict[str, Any]:
    """Fusiona extracción LLM + regex sin degradar la salida del LLM.
    - LLM es la fuente principal.
    - Regex rescata valores numéricos/categóricos cuando LLM devuelve valor por defecto.
    - Para booleanos, solo rescata hallazgos de alta especificidad.
    """
    out = DEFAULT_DATA.copy()
    out.update(datos_llm or {})

    numeric_keys = {
        'ivs', 'volt', 'gls', 'nt_probnp', 'ecv', 'septum_posterior', 'edad'
    }
    high_specific_bool_keys = {
        'stc', 'biceps', 'lumbar', 'macro', 'purpura', 'mgus',
        'mutacion_ttr', 'apical_sparing', 'bajo_voltaje',
        'bav_mp', 'derrame_pericardico', 'biatrial'
    }

    for key, default_val in DEFAULT_DATA.items():
        regex_val = datos_regex.get(key, default_val)
        llm_val = out.get(key, default_val)

        # Numéricos: regex solo rescata cuando LLM viene en default
        if key in numeric_keys:
            if safe_float(llm_val) == safe_float(default_val) and safe_float(regex_val) != safe_float(default_val):
                out[key] = regex_val
            continue

        # Categórico LGE: regex rescata cuando LLM no detecta patrón
        if key == 'lge_patron':
            if str(llm_val).strip() == '' and str(regex_val).strip() != '':
                out[key] = regex_val
            continue

        # Sexo: rescate solo si LLM no lo detecta
        if key == 'sexo':
            if str(llm_val).strip() == '' and str(regex_val).strip() in {'M', 'F'}:
                out[key] = regex_val
            continue

        # Booleanos: no sobreescribir todo con regex para evitar falsos positivos
        if isinstance(default_val, bool):
            if key in high_specific_bool_keys and (not bool(llm_val)) and bool(regex_val):
                out[key] = True

    return out
