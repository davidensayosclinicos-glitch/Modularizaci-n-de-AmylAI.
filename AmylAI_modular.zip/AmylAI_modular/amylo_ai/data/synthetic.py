import os
import datetime
from typing import Any, Dict
import numpy as np
import pandas as pd
try:
    import streamlit as st
except Exception:
    st = None

from amylo_ai.config import BASE_DIR, DB_FILE, DEFAULT_DATA, FEATURES
from amylo_ai.utils.parsing import safe_float
from amylo_ai.clinical.redflags import extraer_redflags_detectados
from amylo_ai.clinical.heuristic import diagnostico_ia
from amylo_ai.clinical.algorithm import calcular_riesgo_experto
from amylo_ai.services.llm import generar_diagnostico_por_llm

def generar_caso_sintetico(rng: np.random.RandomState = None) -> Dict[str, Any]:
    """Genera un caso clínico sintético realista"""
    if rng is None:
        rng = np.random.RandomState(42)
    
    caso = DEFAULT_DATA.copy()
    
    # DEMOGRAFÍA
    caso['edad'] = rng.randint(45, 85)
    caso['sexo'] = rng.choice(['M', 'F'])
    
    # Tipo de caso: 30% AL, 35% ATTR-v, 15% ATTR-h, 10% HVI puro, 10% Control
    tipo_caso = rng.choice(['AL', 'ATTR_V', 'ATTR_H', 'HVI', 'CONTROL'], p=[0.30, 0.35, 0.15, 0.10, 0.10])
    
    # PARÁMETROS CARDIACOS COMUNES
    caso['ivs'] = float(rng.normal(13, 3)) if tipo_caso in ['AL', 'ATTR_V', 'ATTR_H'] else float(rng.normal(10, 2))
    caso['ivs'] = max(9, min(25, caso['ivs']))  # Limitar rango
    
    caso['gls'] = float(rng.normal(-10, 4)) if tipo_caso in ['AL', 'ATTR_V'] else float(rng.normal(-18, 5))
    caso['gls'] = max(-25, min(-5, caso['gls']))
    
    caso['volt'] = float(rng.normal(0.6, 0.3)) if tipo_caso in ['AL', 'ATTR_V'] else float(rng.normal(1.2, 0.4))
    caso['volt'] = max(0.3, min(2.5, caso['volt']))
    
    caso['septum_posterior'] = float(rng.normal(11, 2)) if tipo_caso in ['AL', 'ATTR_V', 'ATTR_H'] else float(rng.normal(9, 1.5))
    caso['septum_posterior'] = max(7, min(18, caso['septum_posterior']))
    
    # AL DIRECTO
    if tipo_caso == 'AL':
        caso['mgus'] = rng.choice([True, False], p=[0.6, 0.4])
        caso['macro'] = rng.choice([True, False], p=[0.5, 0.5])
        caso['purpura'] = rng.choice([True, False], p=[0.4, 0.6])
        caso['nt_probnp'] = float(rng.normal(3500, 1500))
        caso['troponina'] = rng.choice([True, False], p=[0.7, 0.3])
        caso['nefro'] = rng.choice([True, False], p=[0.5, 0.5])
        caso['neuro_p'] = rng.choice([True, False], p=[0.4, 0.6])
        caso['ecv'] = float(rng.normal(45, 5))
        caso['lge_patron'] = rng.choice(['TRANSMURAL', 'SUBENDOCARDICO', 'DIFUSO'])
    
    # ATTR CLÁSICO (Musculoesquelético)
    if tipo_caso == 'ATTR_V':
        caso['stc'] = rng.choice([True, False], p=[0.8, 0.2])
        caso['lumbar'] = rng.choice([True, False], p=[0.7, 0.3])
        caso['biceps'] = rng.choice([True, False], p=[0.6, 0.4])
        caso['nt_probnp'] = float(rng.normal(2000, 800))
        caso['troponina'] = rng.choice([True, False], p=[0.5, 0.5])
        caso['ecv'] = float(rng.normal(38, 4))
        caso['lge_patron'] = rng.choice(['SUBENDOCARDICO', '', ''])
        caso['apical_sparing'] = rng.choice([True, False], p=[0.7, 0.3])
        if rng.random() < 0.3:
            caso['dupuytren'] = True
        if rng.random() < 0.3:
            caso['artralgias'] = True
    
    # ATTR HEREDITARIA
    if tipo_caso == 'ATTR_H':
        caso['stc'] = rng.choice([True, False], p=[0.6, 0.4])
        caso['mutacion_ttr'] = True
        caso['nt_probnp'] = float(rng.normal(1800, 700))
        caso['ecv'] = float(rng.normal(36, 3))
        caso['edad'] = rng.randint(35, 70)  # ATTR-h presenta antes
    
    # HVI PURO (factores confusores)
    if tipo_caso == 'HVI':
        caso['confusor_hta'] = rng.choice([True, False], p=[0.8, 0.2])
        caso['ivs'] = float(rng.normal(12, 2))
        caso['nt_probnp'] = float(rng.normal(800, 300))
        caso['troponina'] = False
        caso['ecv'] = float(rng.normal(25, 3))
    
    # CONTROL (sin hallazgos)
    if tipo_caso == 'CONTROL':
        caso['ivs'] = float(rng.normal(9, 1))
        caso['gls'] = float(rng.normal(-20, 3))
        caso['volt'] = float(rng.normal(1.3, 0.3))
        caso['nt_probnp'] = float(rng.normal(100, 50))
        caso['edad'] = rng.randint(50, 80)
    
    caso['edad'] = int(caso['edad'])
    caso['nt_probnp'] = max(0, float(caso['nt_probnp']))
    
    return caso

def generar_base_datos_sintetica(n: int = 1000) -> pd.DataFrame:
    """Genera n casos sintéticos con diagnósticos IA, guarda una BD completa
    y devuelve un DataFrame con TODAS las variables (todas las columnas).
    """
    rng = np.random.RandomState(42)

    headless = os.environ.get('AMYLO_HEADLESS', '0') == '1'
    if not headless and st is not None:
        st.info(f"🔄 Generando {n} casos sintéticos (todas las variables)...")
        progress_bar = st.progress(0)
    else:
        progress_bar = None

    # Columnas completas: id, fecha, diagnostico, resultado_algoritmo, diagnostico_ia, confianza_ia, modelo_usado + FEATURES
    columnas_esperadas = ['id', 'fecha', 'diagnostico', 'resultado_algoritmo', 'diagnostico_ia', 'confianza_ia', 'modelo_usado'] + FEATURES
    filas = []

    # El modo headless ya se resolvió antes de crear widgets de Streamlit.

    for i in range(n):
        caso = generar_caso_sintetico(rng)
        # Usar el diagnóstico del algoritmo experto cuando esté disponible
        try:
            res_algo = calcular_riesgo_experto(caso)
            diag_algo = res_algo.get('nivel', '')
            confianza_algo = res_algo.get('confianza_porcentaje', 0.0)
        except Exception:
            # Fallback a la heurística IA previa
            diag_algo = diagnostico_ia(caso)
            confianza_algo = 0.0

        try:
            diag_llm = generar_diagnostico_por_llm(caso)
            diag_ia = diag_llm.get('diagnostico_llm', '')
        except Exception:
            diag_ia = ''

        fila = {col: DEFAULT_DATA.get(col, '') for col in columnas_esperadas}
        fila['id'] = i + 1
        fila['fecha'] = datetime.datetime.now().isoformat()
        fila['diagnostico'] = diag_ia
        fila['resultado_algoritmo'] = diag_algo
        fila['diagnostico_ia'] = diag_ia
        fila['confianza_ia'] = round(confianza_algo if confianza_algo else 85.0, 2)
        fila['modelo_usado'] = 'Sintético-IA'

        # Añadir todas las FEATURES explícitamente
        for f in FEATURES:
            valor = caso.get(f, DEFAULT_DATA.get(f, 0))
            # Normalizar tipos: booleanos a int si vienen así
            if isinstance(valor, bool):
                fila[f] = int(valor)
            else:
                fila[f] = valor

        filas.append(fila)

        # Actualizar barra (0-100)
        if headless:
            if (i + 1) % max(1, n // 10) == 0:
                print(f"Generados {i+1}/{n} casos...")
        else:
            try:
                if progress_bar is not None:
                    progress_bar.progress(int((i + 1) / n * 100))
            except Exception:
                if progress_bar is not None:
                    progress_bar.progress((i + 1) / n)

    if progress_bar is not None:
        progress_bar.empty()

    # Construir DataFrame con columnas en orden
    df_all = pd.DataFrame(filas)
    for col in columnas_esperadas:
        if col not in df_all.columns:
            df_all[col] = DEFAULT_DATA.get(col, '')
    df_all = df_all[columnas_esperadas]

    # Guardar BD completa
    ruta_bd = os.path.join(BASE_DIR, DB_FILE)
    df_all.to_csv(ruta_bd, index=False)

    if not headless and st is not None:
        st.success(f"✅ {len(df_all)} casos sintéticos generados y guardados en {DB_FILE}")
    return df_all

def generar_resumen_guardado(id_caso: str, datos: Dict[str, Any], diagnostico: str) -> str:
    """Genera un resumen formateado de lo que se acaba de guardar"""
    ivs_guardado = safe_float(datos.get('ivs', 0))
    gls_guardado = safe_float(datos.get('gls', 0))
    volt_guardado = safe_float(datos.get('volt', 0))
    ntprobnp_guardado = safe_float(datos.get('nt_probnp', 0))
    ecv_guardado = safe_float(datos.get('ecv', 0))

    resumen = f"""
    ### ✅ RESUMEN DE GUARDADO DEL CASO
    
    **ID del Caso:** #{id_caso}  
    **Diagnóstico Final:** {diagnostico}  
    **Fecha/Hora:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
    
    #### Datos Guardados:
    - **Edad:** {datos.get('edad', '—')} años
    - **Sexo:** {'Masculino' if datos.get('sexo') == 'M' else 'Femenino' if datos.get('sexo') == 'F' else '—'}
    
    #### Parámetros Cardiacos:
    - **IVS/Septo:** {f"{ivs_guardado} mm" if ivs_guardado > 0 else 'No reportado'}
    - **GLS/Strain:** {f"{gls_guardado} %" if gls_guardado != 0 else 'No reportado'}
    - **Voltaje ECG:** {f"{volt_guardado} mV" if volt_guardado > 0 else 'No reportado'}
    - **Pared Posterior:** {datos.get('septum_posterior', 0)} mm
    
    #### Biomarcadores:
    - **NT-proBNP:** {f"{ntprobnp_guardado} pg/ml" if ntprobnp_guardado > 0 else 'No reportado'}
    - **Troponina Elevada:** {'✓ Sí' if datos.get('troponina') else 'No'}
    
    #### Resonancia Cardíaca:
    - **Patrón LGE:** {datos.get('lge_patron', '—').upper()}
    - **ECV:** {f"{ecv_guardado} %" if ecv_guardado > 0 else 'No reportado'}
    - **T1 Mapping Elevado:** {'✓ Sí' if datos.get('t1_mapping') else 'No'}
    
    #### Red Flags Detectados:
    """
    
    # Contar red flags
    red_flag_count = 0
    for feature in FEATURES:
        if feature not in ['id', 'fecha', 'diagnostico', 'confianza_ia', 'modelo_usado', 
                          'edad', 'sexo', 'ivs', 'volt', 'gls', 'nt_probnp', 'ecv', 'septum_posterior', 
                          'lge_patron', 'troponina', 't1_mapping', 'derrame_pericardico']:
            if datos.get(feature, False):
                red_flag_count += 1
    
    resumen += f"**Total Red Flags:** {red_flag_count}\n\n"
    resumen += "✅ **All data successfully saved to database**\n"
    
    return resumen
