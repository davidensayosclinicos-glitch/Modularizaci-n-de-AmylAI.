import os
import shutil
import datetime
import traceback
from typing import Any, Dict
import pandas as pd
try:
    import streamlit as st
except Exception:
    class _NoCache:
        @staticmethod
        def cache_data(*args, **kwargs):
            def deco(fn): return fn
            return deco
    st = _NoCache()

from amylo_ai.config import BASE_DIR, DB_FILE, DEFAULT_DATA, FEATURES
from amylo_ai.clinical.algorithm import calcular_riesgo_experto
from amylo_ai.services.llm import generar_diagnostico_por_llm

def migrar_base_datos_v4_3():
    """
    Migra automáticamente desde versiones anteriores a v4.3.0
    Agrega nuevas columnas: confianza_ia, modelo_usado
    """
    import shutil
    
    bd_antigua = "amylo_data_final_v1.csv"
    bd_nueva = DB_FILE
    
    ruta_antigua = os.path.join(BASE_DIR, bd_antigua)
    ruta_nueva = os.path.join(BASE_DIR, bd_nueva)
    
    # Si existe BD antigua y no existe la nueva, migrar
    if os.path.isfile(ruta_antigua) and not os.path.isfile(ruta_nueva):
        try:
            print(f"🔄 Migrando base de datos desde {bd_antigua} a {bd_nueva}...")
            
            # Cargar BD antigua
            df = pd.read_csv(ruta_antigua)
            
            # Remover NHC si existe (no deseado)
            if 'nhc' in df.columns:
                df = df.drop('nhc', axis=1)
            
            # Agregar nuevas columnas si no existen
            if 'confianza_ia' not in df.columns:
                df['confianza_ia'] = 0.0  # Casos antiguos sin confianza
            if 'modelo_usado' not in df.columns:
                df['modelo_usado'] = 'Importado v4.2.0'  # Marcar como importado de versión anterior
            if 'resultado_algoritmo' not in df.columns:
                df['resultado_algoritmo'] = ''
            if 'diagnostico_ia' not in df.columns:
                df['diagnostico_ia'] = ''
            
            # Guardar en nueva estructura
            df.to_csv(ruta_nueva, index=False)
            
            # Respaldar archivo antiguo
            fecha_backup = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            archivo_backup = ruta_antigua.replace('.csv', f'_migrado_{fecha_backup}.csv')
            shutil.copy(ruta_antigua, archivo_backup)
            
            print(f"✅ Migración completada: {len(df)} casos transferidos")
        except Exception as e:
            print(f"❌ Error en migración: {e}")
    
    # Si existe BD nueva pero le faltan columnas, actualizar estructura
    if os.path.isfile(ruta_nueva):
        try:
            df = pd.read_csv(ruta_nueva)
            columnas_requeridas = ['nhc', 'confianza_ia', 'modelo_usado', 'resultado_algoritmo', 'diagnostico_ia']
            necesita_actualizar = False
            
            for col in columnas_requeridas:
                if col not in df.columns:
                    if col == 'nhc':
                        df[col] = ''
                    elif col == 'confianza_ia':
                        df[col] = 0.0
                    elif col in ['resultado_algoritmo', 'diagnostico_ia']:
                        df[col] = ''
                    else:
                        df[col] = 'Actualizado a v4.3.0'
                    necesita_actualizar = True
            
            if necesita_actualizar:
                print("🔧 Actualizando estructura de BD a v4.3.0...")
                
                # Respaldar
                fecha_backup = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                archivo_backup = ruta_nueva.replace('.csv', f'_backup_{fecha_backup}.csv')
                shutil.copy(ruta_nueva, archivo_backup)
                
                # Guardar actualizado
                df.to_csv(ruta_nueva, index=False)
                print(f"✅ Estructura actualizada: {len(df)} casos")
        except Exception as e:
            print(f"❌ Error actualizando estructura: {e}")

def save_case_training(datos: Dict[str, Any], diagnostico: str, confianza_ia: float = 0.0, modelo_usado: str = "") -> str:
    """
    Guarda un caso en la base de datos CSV para entrenamiento futuro.
    Incluye TODOS los red flags (hallazgos clínicos) como columnas independientes.
    NUEVO v4.3.0: Guarda también confianza IA y modelo usado
    Retorna el ID del caso o "ERROR" si falla.
    """
    try:
        ruta_abs = os.path.join(BASE_DIR, DB_FILE)
        
        # Columns esperadas: id, fecha, diagnostico, resultado_algoritmo, diagnostico_ia, confianza_ia, modelo_usado + FEATURES
        columnas_esperadas = ['id', 'fecha', 'diagnostico', 'resultado_algoritmo', 'diagnostico_ia', 'confianza_ia', 'modelo_usado'] + FEATURES
        
        # Cargar BD existente o crear nueva
        if os.path.isfile(ruta_abs):
            df = pd.read_csv(ruta_abs)
            nuevo_id = int(df['id'].max()) + 1 if 'id' in df.columns else 1
            
            # Verificar si la estructura es correcta
            columnas_faltantes = set(columnas_esperadas) - set(df.columns)
            
            if columnas_faltantes:
                # Si faltan columnas, necesitamos actualizar la estructura
                # Respaldar el archivo antiguo
                import shutil
                fecha_backup = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                archivo_backup = ruta_abs.replace('.csv', f'_backup_{fecha_backup}.csv')
                shutil.copy(ruta_abs, archivo_backup)
                
                # Agregar columnas faltantes al DataFrame con valores por defecto apropiados
                for col in columnas_faltantes:
                    # Usar el valor por defecto de DEFAULT_DATA si existe
                    if col in ['resultado_algoritmo', 'diagnostico_ia']:
                        default_val = ''
                    else:
                        default_val = DEFAULT_DATA.get(col, 0)
                    df[col] = default_val
                
                # Reordenar columnas a la estructura correcta
                df = df[columnas_esperadas]
                df.to_csv(ruta_abs, index=False)
        else:
            # Crear tabla nueva con TODAS las columnas
            df = pd.DataFrame(columns=columnas_esperadas)
            nuevo_id = 1
        
        # Preparar fila nueva: cada red flag es una columna
        try:
            res_algo = calcular_riesgo_experto(datos)
            resultado_algoritmo = res_algo.get('nivel', '')
        except Exception:
            resultado_algoritmo = ''

        try:
            diag_llm = generar_diagnostico_por_llm(datos)
            diag_ia = diag_llm.get('diagnostico_llm', '')
        except Exception:
            diag_ia = ''

        nueva_fila = {
            'id': nuevo_id, 
            'fecha': datetime.datetime.now().isoformat(),
            'diagnostico': diagnostico,
            'resultado_algoritmo': resultado_algoritmo,
            'diagnostico_ia': diag_ia,
            'confianza_ia': round(confianza_ia, 2),  # Precision a 2 decimales
            'modelo_usado': modelo_usado
        }
        
        # Guardar TODOS los red flags (features) como columnas
        for feature in FEATURES:
            valor = datos.get(feature, DEFAULT_DATA.get(feature, 0))
            # Convertir booleanos a 0/1 para CSV y mantener números
            if isinstance(valor, bool):
                nueva_fila[feature] = int(valor)
            else:
                nueva_fila[feature] = valor
        
        # Añadir fila al DataFrame
        df = pd.concat([df, pd.DataFrame([nueva_fila])], ignore_index=True)
        
        # Asegurar tipos de datos correctos: mixto según feature
        df['id'] = df['id'].astype(int)
        df['diagnostico'] = df['diagnostico'].astype(str)
        for feature in FEATURES:
            if feature in ['ivs', 'volt', 'gls', 'nt_probnp', 'septum_posterior', 'ecv', 'edad']:
                # Numéricos
                df[feature] = pd.to_numeric(df[feature], errors='coerce').fillna(0)
                if feature in ['edad']:
                    df[feature] = df[feature].astype(int)
            elif feature in ['lge_patron', 'sexo']:
                # Strings/categóricos
                df[feature] = df[feature].astype(str)
            else:
                # Booleanos (0/1)
                df[feature] = pd.to_numeric(df[feature], errors='coerce').fillna(0).astype(int)
        
        # Guardar con columnas en el orden correcto
        df = df[columnas_esperadas]
        df.to_csv(ruta_abs, index=False)
        
        return str(nuevo_id)
    except Exception as e:
        print(f"Error guardando caso: {e}")
        import traceback
        traceback.print_exc()
        return "ERROR"

def load_training_database(completar_ia: bool = False) -> pd.DataFrame:
    """Carga la base de datos de casos guardados (ruta consistente con BASE_DIR)."""
    ruta_abs = os.path.join(BASE_DIR, DB_FILE)
    if os.path.isfile(ruta_abs):
        df = pd.read_csv(ruta_abs)
        necesita_guardar = False

        # Asegurar columnas minimas
        columnas_minimas = ['id', 'fecha', 'diagnostico']
        for col in columnas_minimas:
            if col not in df.columns:
                df[col] = '' if col != 'id' else 0
                necesita_guardar = True

        if 'resultado_algoritmo' not in df.columns:
            df['resultado_algoritmo'] = ''
            necesita_guardar = True
        if 'diagnostico_ia' not in df.columns:
            df['diagnostico_ia'] = ''
            necesita_guardar = True

        # Asegurar que existan todas las FEATURES
        for feature in FEATURES:
            if feature not in df.columns:
                df[feature] = DEFAULT_DATA.get(feature, 0)
                necesita_guardar = True

        # Completar resultado_algoritmo si esta vacio
        try:
            serie_resultado = df['resultado_algoritmo']
            mask_vacio = serie_resultado.isna() | (serie_resultado.astype(str).str.strip() == '')
            if mask_vacio.any():
                def _calc_resultado(row: pd.Series) -> str:
                    datos = {f: row.get(f, DEFAULT_DATA.get(f, 0)) for f in FEATURES}
                    try:
                        res_algo = calcular_riesgo_experto(datos)
                        return res_algo.get('nivel', '')
                    except Exception:
                        return ''

                df.loc[mask_vacio, 'resultado_algoritmo'] = df.loc[mask_vacio].apply(_calc_resultado, axis=1)
                necesita_guardar = True
        except Exception:
            pass

        # Completar diagnostico_ia si esta vacio (opcional, puede ser lento)
        if completar_ia:
            try:
                serie_ia = df['diagnostico_ia']
                mask_vacio = serie_ia.isna() | (serie_ia.astype(str).str.strip() == '')
                if mask_vacio.any():
                    def _calc_diag_ia(row: pd.Series) -> str:
                        datos = {f: row.get(f, DEFAULT_DATA.get(f, 0)) for f in FEATURES}
                        try:
                            diag_llm = generar_diagnostico_por_llm(datos)
                            return diag_llm.get('diagnostico_llm', '')
                        except Exception:
                            return ''

                    df.loc[mask_vacio, 'diagnostico_ia'] = df.loc[mask_vacio].apply(_calc_diag_ia, axis=1)
                    necesita_guardar = True
            except Exception:
                pass

        if necesita_guardar:
            df.to_csv(ruta_abs, index=False)

        return df
    else:
        return pd.DataFrame(columns=['id', 'fecha', 'diagnostico', 'resultado_algoritmo', 'diagnostico_ia'] + FEATURES)

def get_db_mtime() -> float:
    ruta_abs = os.path.join(BASE_DIR, DB_FILE)
    try:
        return os.path.getmtime(ruta_abs)
    except Exception:
        return 0.0

@st.cache_data(show_spinner=False)
def get_database_stats(db_mtime: float) -> Dict[str, Any]:
    """Obtiene estadísticas de la base de datos"""
    _ = db_mtime
    df = load_training_database()

    if df.empty:
        return {
            'total_casos': 0,
            'por_diagnostico': {},
            'ultima_actualizacion': 'N/A'
        }

    stats = {
        'total_casos': len(df),
        'por_diagnostico': df['diagnostico'].value_counts().to_dict(),
        'ultima_actualizacion': df['fecha'].max() if 'fecha' in df.columns else 'N/A'
    }

    return stats
