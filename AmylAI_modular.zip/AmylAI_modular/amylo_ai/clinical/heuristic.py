from typing import Any, Dict
from amylo_ai.clinical.redflags import extraer_redflags_detectados

def diagnostico_ia(datos: Dict[str, Any]) -> str:
    """
    Asigna un diagnóstico basado en los hallazgos clínicos (lógica médica)
    Retorna el diagnóstico más probable
    """
    redflags = extraer_redflags_detectados(datos)
    
    # Contar hallazgos por categoría
    al_directo = len(redflags.get('AL_DIRECTO', []))
    al_sistemico = len(redflags.get('AL_SISTEMICO', []))
    attr_clasico = len(redflags.get('ATTR_CLASICO', []))
    attr_heredit = len(redflags.get('ATTR_HEREDITARIO', []))
    cardiacos = len(redflags.get('HALLAZGOS_CARDIACOS', []))
    confusores = len(redflags.get('FACTORES_CONFUSORES', []))
    
    # Biomarkers
    nt_probnp = datos.get('nt_probnp', 0)
    troponina = datos.get('troponina', False)
    ecv = datos.get('ecv', 0)
    lge = datos.get('lge_patron', '')
    ivs = datos.get('ivs', 0)
    
    # Lógica diagnóstica
    
    # AL DIAGNOSIS
    if al_directo >= 2 or (al_directo >= 1 and al_sistemico >= 2):
        if nt_probnp > 2500 and troponina:
            return "AL - Amiloidosis AL Probable (ALTA SOSPECHA)"
        elif nt_probnp > 1000:
            return "AL - Amiloidosis AL Probable"
        else:
            return "AL - Amiloidosis AL Posible"
    
    # ATTR CLÁSICO (Musculoesquelético)
    if attr_clasico >= 3:  # Tríada: STC + Lumbar + Bíceps
        if ivs > 13 and ecv > 35:
            return "ATTR-v - Amiloidosis ATTR Salvaje (ALTA SOSPECHA)"
        else:
            return "ATTR-v - Amiloidosis ATTR Salvaje"
    elif attr_clasico >= 2 and ivs > 12:
        return "ATTR-v - Amiloidosis ATTR Salvaje Probable"
    elif attr_clasico >= 1 and ivs > 13 and ('SUBENDOCARDICO' in lge.upper() or ecv > 35):
        return "ATTR-v - Amiloidosis ATTR Probable"
    
    # ATTR HEREDITARIA
    if attr_heredit >= 1:
        return "ATTR-v Hereditaria - Mutación TTR Confirmada (REQUIERE CRIBADO FAMILIAR)"
    
    # DIFERENCIAL HVI
    if confusores >= 1 and ivs > 11 and al_directo == 0 and attr_clasico <= 1:
        return "HVI - Hipertrofia por HTA/Válvula (Sin Amiloidosis)"
    
    # BAJA PROBABILIDAD
    if redflags['TOTAL_REDFLAGS'] == 0 or ivs < 10:
        return "CONTROL - Sin hallazgos de amiloidosis"
    
    # ZONA GRIS
    if ivs > 12 and nt_probnp > 400:
        return "INTERMEDIA - Requiere investigación adicional"
    
    return "CONTROL - Baja probabilidad de amiloidosis"
