from typing import Any, Dict
from amylo_ai.config import PESOS, UMBRAL_CONFIRMACION, UMBRAL_SCREENING
from amylo_ai.utils.parsing import safe_bool, safe_float

def exportar_a_fhir(datos, resultado):
    """Genera un recurso FHIR R4 Observation simplificado"""
    return {
        "resourceType": "Observation",
        "status": "final",
        "code": {
            "coding": [{
                "system": "http://loinc.org",
                "code": "89253-9",
                "display": "Cardiac amyloidosis assessment"
            }]
        },
        "valueInteger": resultado['score'],
        "interpretation": [{
            "coding": [{
                "code": resultado['nivel'],
                "display": resultado['msg']
            }]
        }],
        "component": [
            {"code": {"text": "IVS"}, "valueQuantity": {"value": datos['ivs'], "unit": "mm"}},
            {"code": {"text": "GLS"}, "valueQuantity": {"value": datos['gls'], "unit": "%"}}
        ]
    }

def calcular_confianza_porcentaje(score: int, max_score: int = 45) -> float:
    """
    Calcula el porcentaje de confianza basado en el score.
    Escala normalizada de 0-100%.
    """
    # Normalizar tipos inesperados
    try:
        if isinstance(score, complex):
            score = score.real
        score = float(score)
    except Exception:
        score = 0.0

    # Normalizar score a rango 0-1 usando sigmoid suave
    normalized = min(max(score / max_score, 0.0), 1.0)
    # Aplicar escala perceptual (más sensible a cambios bajos)
    confianza = (normalized ** 0.7) * 100

    try:
        if isinstance(confianza, complex):
            confianza = confianza.real
        confianza = float(confianza)
    except Exception:
        confianza = 0.0

    return min(confianza, 98.0)  # Máximo 98% para humildad estadística

def calcular_riesgo_experto(d: Dict[str, Any], umbral_screening: float = None, umbral_confirmacion: float = None) -> Dict[str, Any]:
    """
    Motor de inferencia clínica para sospecha de amiloidosis cardíaca.
    Ajustado a stress test bioestadístico (ROC / Youden / McNemar).
    
    Parámetros:
    - d: Diccionario con datos del paciente
    - umbral_screening: Score mínimo para INTERMEDIA (por defecto UMBRAL_SCREENING)
    - umbral_confirmacion: Score mínimo para ALTA PROBABILIDAD (por defecto UMBRAL_CONFIRMACION)
    """
    
    # Usar umbrales globales si no se especifican
    if umbral_screening is None:
        umbral_screening = UMBRAL_SCREENING
    if umbral_confirmacion is None:
        umbral_confirmacion = UMBRAL_CONFIRMACION

    score = 0
    score_cardiaco = 0
    hallazgos = []

    # ------------------------------------------------------------------
    # 1. Extracción de variables
    # ------------------------------------------------------------------
    ivs = safe_float(d.get("ivs"))
    volt = safe_float(d.get("volt"))
    gls = safe_float(d.get("gls"))
    nt_probnp = safe_float(d.get("nt_probnp"))
    ecv = safe_float(d.get("ecv"))
    septum_post = safe_float(d.get("septum_posterior"))
    lge_patron = str(d.get("lge_patron", ""))
    troponina = safe_bool(d, "troponina")

    tiene_confusor = any(
        safe_bool(d, k) for k in ["confusor_hta", "confusor_ao", "confusor_irc"]
    )

    # ------------------------------------------------------------------
    # 2. Fenotipo cardíaco
    # ------------------------------------------------------------------
    umbral_ivs = 14 if tiene_confusor else 12
    puntos_hvi = PESOS["hvi_confusor"] if tiene_confusor else PESOS["hvi_base"]

    if ivs >= umbral_ivs:
        score += puntos_hvi
        score_cardiaco += puntos_hvi
        hallazgos.append(f"HVI ≥{umbral_ivs} mm (+{puntos_hvi})")

    ratio_vm = volt / ivs if ivs > 0 else 100.0
    discordancia = ivs >= 12 and volt > 0 and ratio_vm < 0.05
    if discordancia:
        score += PESOS["discordancia"]
        score_cardiaco += PESOS["discordancia"]
        hallazgos.append("Discordancia Voltaje/Masa (+3)")

    if safe_bool(d, "apical_sparing"):
        score += PESOS["apical_sparing"]
        score_cardiaco += PESOS["apical_sparing"]
        hallazgos.append("Patrón Apical Sparing (+4)")
    elif -15 < gls < 0:
        score += PESOS["strain_reducido"]
        score_cardiaco += PESOS["strain_reducido"]
        hallazgos.append(f"Strain longitudinal reducido ({gls}%) (+2)")

    if safe_bool(d, "bav_mp") and ivs >= 12:
        score += PESOS["bav_mp"]
        score_cardiaco += PESOS["bav_mp"]
        hallazgos.append("Trastorno de conducción / MP (+2)")

    # Red flags cardiacos adicionales
    if safe_bool(d, "biatrial"):
        score += 1
        score_cardiaco += 1
        hallazgos.append("Dilatación biauricular (+1)")
    if safe_bool(d, "pseudo_q"):
        score += 1
        score_cardiaco += 1
        hallazgos.append("Pseudoinfarto (+1)")
    if safe_bool(d, "bajo_voltaje"):
        score += 1
        score_cardiaco += 1
        hallazgos.append("Bajo voltaje (+1)")
    if safe_bool(d, "derrame_pericardico"):
        score += 1
        score_cardiaco += 1
        hallazgos.append("Derrame pericárdico (+1)")
    if septum_post >= 12:
        score += 1
        score_cardiaco += 1
        hallazgos.append("Pared posterior aumentada (+1)")

    # Biomarcadores y RM
    if nt_probnp >= 2000:
        score += 2
        hallazgos.append("NT-proBNP muy elevado (+2)")
    elif nt_probnp >= 1000:
        score += 1
        hallazgos.append("NT-proBNP elevado (+1)")
    if troponina:
        score += 1
        hallazgos.append("Troponina elevada (+1)")
    if ecv >= 35:
        score += 2
        hallazgos.append("ECV muy elevado (+2)")
    elif ecv >= 30:
        score += 1
        hallazgos.append("ECV elevado (+1)")
    if any(k in lge_patron.upper() for k in ["SUBENDOCARD", "DIFUSO", "TRANSMURAL"]):
        score += 2
        hallazgos.append("Patrón LGE sugerente (+2)")

    # ------------------------------------------------------------------
    # 3. Fenotipo extracardíaco ATTR (Musculoesquelético)
    # ------------------------------------------------------------------
    # Red flags ATTR principales
    n_attr = sum(
        safe_bool(d, k) for k in ["stc", "biceps", "lumbar", "hombro"]
    )
    
    # Red flags ATTR adicionales
    n_attr_adicionales = sum(
        safe_bool(d, k) for k in ["dupuytren", "artralgias", "fractura_vert", "tendinitis_calcifica"]
    )
    
    # Scoring ATTR musculoesquelético
    if n_attr >= 2:
        score += PESOS["attr_extra_alto"]
        hallazgos.append(f"Fenotipo ATTR clásico ({n_attr} signos) (+3)")
    elif n_attr == 1:
        score += PESOS["attr_extra_bajo"]
        hallazgos.append("Fenotipo ATTR (1 signo clásico) (+1)")
    
    # Red flags ATTR adicionales
    if n_attr_adicionales >= 2:
        score += 2
        hallazgos.append(f"Red flags ATTR adicionales ({n_attr_adicionales}) (+2)")
    elif n_attr_adicionales == 1:
        score += 1
        hallazgos.append("Red flag ATTR complementario (+1)")

    # ------------------------------------------------------------------
    # 4. Fenotipo AL sistémico (Red flags específicos)
    # ------------------------------------------------------------------
    # Diagnóstico directo AL
    n_al_directo = sum(
        safe_bool(d, k) for k in ["mgus", "macro", "purpura"]
    )
    
    # Otros hallazgos AL
    n_al_secundario = sum(
        safe_bool(d, k) for k in ["nefro", "neuro_p", "disauto", "hepato", "fatiga", "piel_lesiones"]
    )

    if n_al_directo >= 1:
        score += 3 * n_al_directo
        hallazgos.append(f"Red flags AL directos ({n_al_directo}) (+{3 * n_al_directo})")
    if n_al_secundario >= 1:
        score += n_al_secundario
        hallazgos.append(f"Red flags AL sistémicos ({n_al_secundario}) (+{n_al_secundario})")
    
    # ------------------------------------------------------------------
    # 5. ATTR hereditaria (Mutación TTR)
    # ------------------------------------------------------------------
    if safe_bool(d, "mutacion_ttr"):
        score += 4
        hallazgos.append("Mutación TTR confirmada (⚠️ ATTR hereditaria) (+4)")

    # Penalización por confusores
    confusores = sum(safe_bool(d, k) for k in ["confusor_hta", "confusor_ao", "confusor_irc"])
    if confusores:
        score -= confusores
        hallazgos.append(f"Confusores presentes ({confusores}) (-{confusores})")

    res = {
        "score": score,
        "hallazgos": hallazgos,
        "puntos": score
    }

    # ===================================================================
    # BLOQUEO ABSOLUTO #1: AMILOIDOSIS AL (DIRECTO)
    # ===================================================================
    if n_al_directo >= 1:
        res.update({
            "nivel": "ALTA SOSPECHA (AL)",
            "color": "#d32f2f",
            "msg": "🚨 Signos específicos de amiloidosis AL detectados.",
            "accion": "Derivación URGENTE a Hematología (FLC séricos, biopsia).",
            "evidencia": f"Criterio clínico directo ({n_al_directo} hallazgo/s AL)",
            "confianza_porcentaje": 95.0  # AL directo es muy específico
        })
        return res
    
    # ===================================================================
    # BLOQUEO ABSOLUTO #2: PERFIL AL (MÚLTIPLES HALLAZGOS SECUNDARIOS)
    # ===================================================================
    if n_al_secundario >= 3:
        res.update({
            "nivel": "ALTA SOSPECHA (AL)",
            "color": "#d32f2f",
            "msg": "🚨 Múltiples criterios sugestivos de AL (síndrome nefrótico, neuropatía, disautonomía).",
            "accion": "Derivación urgente a Hematología + Nefrología.",
            "evidencia": f"Poliafectación sistémica AL ({n_al_secundario} hallazgos)",
            "confianza_porcentaje": 90.0  # AL sistémico alto
        })
        return res

    # -------- GATE CARDÍACO FUERTE PARA ATTR --------
    fenotipo_cardiaco_fuerte = (
        safe_bool(d, "apical_sparing") or
        (ivs >= 12 and volt > 0 and (volt / ivs) < 0.05) or
        (ivs >= 14 and not tiene_confusor) or
        (safe_bool(d, "bajo_voltaje") and safe_bool(d, "bav_mp"))  # Bajo voltaje + BAV
    )
    
    # Contador de fenotipo ATTR completo
    n_attr_total = n_attr + n_attr_adicionales

    # Calcular confianza/probabilidad
    confianza = calcular_confianza_porcentaje(score, max_score=45)

    # ===================================================================
    # ATTR PROBABLE (FENOTIPO COMPLETO + CARDIO FUERTE)
    # ===================================================================
    if (
        score >= umbral_confirmacion and
        fenotipo_cardiaco_fuerte and
        n_attr_total >= 1
    ):
        res.update({
            "nivel": "ALTA PROBABILIDAD (ATTR)",
            "color": "#c62828",
            "msg": f"✅ Fenotipo ATTR consistente (Score {score}). Cardiopatía + manifestaciones sistémicas.",
            "accion": "Confirmar con gammagrafía ósea (Tc-99m DPD/PyP) ± biopsia.",
            "evidencia": "Gate cardíaco + sistemico (alta especificidad)",
            "confianza_porcentaje": confianza
        })
        return res
    # ===================================================================
    # FILTRO TEMPRANO: SANO / BAJO RIESGO (SIN hallazgos significativos)
    # ===================================================================
    # Estrategia: excluir casos claramente inocentes ANTES de chequear INTERMEDIA
    score_sin_confusores = score - confusores if confusores > 0 else score
    
    # Si score es muy bajo y sin hallazgos sistémicos → probablemente SANO
    if score_sin_confusores <= 1 and n_al_directo == 0 and n_al_secundario == 0:
        # Extra check: si IVS < 12, casi seguro es sano
        if ivs < 12:
            res.update({
                "nivel": "BAJA / SANO",
                "color": "#388e3c",
                "msg": "✅ Sin criterios clínicos de cardiopatía infiltrativa. Fenotipo normal.",
                "accion": "Seguimiento habitual. Tranquilizar al paciente.",
                "evidencia": "Score bajo, sin hallazgos sistémicos, IVS normal",
                "confianza_porcentaje": 85.0
            })
            return res

    # ===================================================================
    # FILTRO TEMPRANO: HVI NO AMILOIDE (HTA/Válvula puro)
    # ===================================================================
    # Si tiene HVI + confusores + SIN hallazgos sistémicos de amiloidosis
    # → Es probablemente HVI puro (hipertensión/válvula), no amiloidosis
    if ivs >= 12 and confusores >= 1:
        # Contar hallazgos sistémicos de amiloidosis
        hallazgos_sistemicos = n_al_directo + n_al_secundario
        hallazgos_attr_clasico = sum(
            safe_bool(d, k) for k in ["stc", "biceps", "lumbar", "dupuytren", "artralgias"]
        )
        
        # Si no hay hallazgos sistémicos significativos de amiloidosis
        # y el score (sin confusores) es bajo → claramente HVI puro
        if hallazgos_sistemicos == 0 and hallazgos_attr_clasico <= 1 and score_sin_confusores < 4:
            res.update({
                "nivel": "HVI No Amiloide",
                "color": "#1976d2",
                "msg": "💙 Hipertrofia con fenotipo HTA/valvular. Confusor presente (HTA/válvula). Sin criterios infiltración.",
                "accion": "Control de PA y factores de riesgo. Cardio-RM sólo si hallazgos imagen sospechosos.",
                "evidencia": "HVI + confusor evidente + ausencia de signos sistémicos amiloide",
                "confianza_porcentaje": 80.0
            })
            return res

    # ===================================================================
    # INTERMEDIA REAL (CARDÍACA SIN CONFIRMACIÓN - UMBRAL ELEVADO)
    # ===================================================================
    # Nota: UMBRAL_SCREENING ahora es 4 (antes 1) para mejorar especificidad
    # Requiere múltiples hallazgos, no solo uno
    if score >= umbral_screening:
        res.update({
            "nivel": "INTERMEDIA (Screening)",
            "color": "#f57c00",
            "msg": f"⚠️ Sospecha moderada de amiloidosis (Score {score}). Requiere investigación.",
            "accion": "Cardio-RM + biomarcadores / Considerar pruebas sistémicas (ADN, biopsia si sospecha).",
            "evidencia": "Múltiples hallazgos sugestivos sin gate completo ATTR",
            "confianza_porcentaje": confianza
        })
        return res

    # ===================================================================
    # HVI NO AMILOIDE (Fallback - para casos sin confusores claros)
    # ===================================================================
    if ivs >= 12:
        res.update({
            "nivel": "HVI No Amiloide",
            "color": "#1976d2",
            "msg": "💙 Hipertrofia sin criterios claros de infiltración amiloide. Probable HTA/valvulopatía.",
            "accion": "Cardio-RM para descartar infiltración. Control de PA.",
            "evidencia": "Fenotipo hipertrófico aislado",
            "confianza_porcentaje": 65.0
        })
        return res

    # ===================================================================
    # SANO / BAJO RIESGO (Default cuando nada más aplica)
    # ===================================================================
    res.update({
        "nivel": "BAJA / SANO",
        "color": "#388e3c",
        "msg": "✅ Sin hallazgos significativos de cardiopatía infiltrativa.",
        "accion": "Seguimiento habitual.",
        "evidencia": "Score bajo, sin red flags sistémicos",
        "confianza_porcentaje": confianza
    })

    return res
