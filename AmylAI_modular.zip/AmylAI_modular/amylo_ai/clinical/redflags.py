from typing import Any, Dict
from amylo_ai.utils.parsing import safe_float

def extraer_redflags_detectados(datos: Dict[str, Any]) -> Dict[str, list]:
    """
    Extrae todos los red flags (hallazgos clínicos) detectados en los datos.
    Retorna un diccionario con categorías de red flags.
    """
    redflags = {
        "AL_DIRECTO": [],
        "AL_SISTEMICO": [],
        "ATTR_CLASICO": [],
        "ATTR_HEREDITARIO": [],
        "HALLAZGOS_CARDIACOS": [],
        "PARAMETROS_CARDIACOS": [],
        "FACTORES_CONFUSORES": [],
        "TOTAL_REDFLAGS": 0
    }
    
    # AL DIRECTO - Hallazgos patognomónicos
    if datos.get('mgus'): redflags["AL_DIRECTO"].append("MGUS/Paraproteína")
    if datos.get('macro'): redflags["AL_DIRECTO"].append("Macroglosia")
    if datos.get('purpura'): redflags["AL_DIRECTO"].append("Púrpura periorbital")
    
    # AL SISTÉMICO
    if datos.get('nefro'): redflags["AL_SISTEMICO"].append("Síndrome nefrótico")
    if datos.get('hepato'): redflags["AL_SISTEMICO"].append("Hepatomegalia")
    if datos.get('neuro_p'): redflags["AL_SISTEMICO"].append("Polineuropatía")
    if datos.get('fatiga'): redflags["AL_SISTEMICO"].append("Fatiga severa")
    if datos.get('disauto'): redflags["AL_SISTEMICO"].append("Disautonomía")
    if datos.get('piel_lesiones'): redflags["AL_SISTEMICO"].append("Lesiones cutáneas")
    
    # ATTR CLÁSICO - Tríada musculoesquelética
    if datos.get('stc'): redflags["ATTR_CLASICO"].append("STC bilateral")
    if datos.get('lumbar'): redflags["ATTR_CLASICO"].append("Estenosis lumbar")
    if datos.get('biceps'): redflags["ATTR_CLASICO"].append("Rotura bíceps")
    if datos.get('hombro'): redflags["ATTR_CLASICO"].append("Tendinitis hombro")
    if datos.get('dupuytren'): redflags["ATTR_CLASICO"].append("Dupuytren")
    if datos.get('artralgias'): redflags["ATTR_CLASICO"].append("Artralgias")
    if datos.get('fractura_vert'): redflags["ATTR_CLASICO"].append("Fractura vertebral")
    if datos.get('tendinitis_calcifica'): redflags["ATTR_CLASICO"].append("Tendinitis cálcica")
    
    # ATTR HEREDITARIA
    if datos.get('mutacion_ttr'): redflags["ATTR_HEREDITARIO"].append("Mutación TTR")
    
    # HALLAZGOS CARDIACOS ESPECÍFICOS
    if datos.get('apical_sparing'): redflags["HALLAZGOS_CARDIACOS"].append("Apical sparing")
    if datos.get('bajo_voltaje'): redflags["HALLAZGOS_CARDIACOS"].append("Bajo voltaje paradójico")
    if datos.get('bav_mp'): redflags["HALLAZGOS_CARDIACOS"].append("BAV/Marcapasos")
    if datos.get('pseudo_q'): redflags["HALLAZGOS_CARDIACOS"].append("Pseudoinfarto")
    if datos.get('biatrial'): redflags["HALLAZGOS_CARDIACOS"].append("Dilatación biauricular")
    
    # HALLAZGOS ECOCARDIOGRÁFICOS ESPECÍFICOS ATTR (NUEVOS)
    if datos.get('distribucion_concentrica'): redflags["HALLAZGOS_CARDIACOS"].append("Distribución concéntrica (característica ATTR)")
    if datos.get('rv_engrosado'): redflags["HALLAZGOS_CARDIACOS"].append("RV engrosado (signo ominoso ATTR)")
    if datos.get('aorta_pequena'): redflags["HALLAZGOS_CARDIACOS"].append("Aorta pequeña/normal relativa (paradoja ATTR)")
    if datos.get('ausencia_fa'): redflags["HALLAZGOS_CARDIACOS"].append("Ausencia de FA a pesar de ICC severa (ATTR vs HTA)")
    
    # BIOMARCADORES NUEVOS
    if datos.get('hiperrealce_subepicardico'): redflags["HALLAZGOS_CARDIACOS"].append("Hiperrealce subepicárdico (típico ATTR-v)")
    if datos.get('troponina_cronica'): redflags["HALLAZGOS_CARDIACOS"].append("Troponina elevada crónica baja (ATTR)")
    
    # PARÁMETROS CARDIACOS NUMÉRICOS
    ivs = safe_float(datos.get('ivs', 0))
    gls = safe_float(datos.get('gls', 0))
    volt_raw = datos.get('volt', 0)
    volt = safe_float(volt_raw)
    volt_informado = str(volt_raw).strip().lower() not in ('', '0', '0.0', 'none', 'nan') and volt > 0
    ecv = safe_float(datos.get('ecv', 0))
    
    if ivs > 15:
        redflags["PARAMETROS_CARDIACOS"].append(f"IVS muy aumentado: {ivs} mm (muy específico ATTR)")
    elif ivs > 12:
        redflags["PARAMETROS_CARDIACOS"].append(f"IVS aumentado: {ivs} mm")
    
    if gls < -9:
        redflags["PARAMETROS_CARDIACOS"].append(f"GLS anormal: {gls}%")
    
    if volt_informado and volt < 0.5:
        redflags["PARAMETROS_CARDIACOS"].append(f"Voltaje muy bajo: {volt} mV (CRÍTICO: amiloidosis)")
    elif volt_informado and volt < 1.0:
        redflags["PARAMETROS_CARDIACOS"].append(f"Voltaje bajo: {volt} mV")
    
    if ecv > 40:
        redflags["PARAMETROS_CARDIACOS"].append(f"ECV > 40% ({ecv}%) - CASI PATOGNOMÓNICO de amiloidosis")
    elif ecv > 35:
        redflags["PARAMETROS_CARDIACOS"].append(f"ECV elevado ({ecv}%) - muy sugestivo de amiloidosis")
    
    # FACTORES CONFUSORES
    if datos.get('confusor_hta'): redflags["FACTORES_CONFUSORES"].append("HTA severa")
    if datos.get('confusor_ao'): redflags["FACTORES_CONFUSORES"].append("Estenosis aórtica")
    if datos.get('confusor_irc'): redflags["FACTORES_CONFUSORES"].append("Insuficiencia renal")
    
    # Contar total de red flags
    redflags["TOTAL_REDFLAGS"] = sum(len(v) for k, v in redflags.items() if k != "TOTAL_REDFLAGS")
    
    return redflags
