from typing import Any, Dict
from amylo_ai.utils.parsing import safe_float

def generar_explicacion_narrativa(datos: Dict[str, Any], resultado: Dict[str, Any]) -> str:
    nivel = resultado.get('nivel', '')
    hallazgos = resultado.get('hallazgos', [])
    texto = f"Resultado del análisis: **{nivel}**.\n"
    if "ALTA" in nivel:
        texto += "Existe una alta probabilidad clínica de amiloidosis. "
    elif "INTERMEDIA" in nivel:
        texto += "El paciente se encuentra en una **zona gris**. Se requiere imagen avanzada. "
    elif "HVI" in nivel:
        texto += "Los hallazgos sugieren hipertrofia por sobrecarga (HTA/Válvula) y no infiltrativa. "
    else:
        texto += "Baja probabilidad de enfermedad infiltrativa. "
    
    if hallazgos:
        clean_hallazgos = [h.split('(+')[0].strip() for h in hallazgos]
        texto += "\n\nFactores clave detectados: " + ", ".join(clean_hallazgos).lower() + "."
    return texto

def generar_resumen_hallazgos(datos: Dict[str, Any], resultado: Dict[str, Any]) -> str:
    """
    Genera un resumen clínico detallado y profesional de los hallazgos.
    Incluye diagnóstico diferencial, parámetros cardiacos e interpretación clínica.
    """
    
    # SECCIONES ORGANIZADAS POR CATEGORÍA
    hallazgos_al_directo = []
    hallazgos_al_sistemico = []
    hallazgos_attr_clasico = []
    hallazgos_attr_hereditario = []
    hallazgos_cardiacos = []
    hallazgos_confusores = []
    
    # AL DIRECTO
    if datos.get('mgus'): hallazgos_al_directo.append("Paraproteína/MGUS detectada")
    if datos.get('macro'): hallazgos_al_directo.append("Macroglosia")
    if datos.get('purpura'): hallazgos_al_directo.append("Púrpura periorbital")
    
    # AL SISTÉMICO
    if datos.get('nefro'): hallazgos_al_sistemico.append("Síndrome nefrótico")
    if datos.get('hepato'): hallazgos_al_sistemico.append("Hepatomegalia")
    if datos.get('neuro_p'): hallazgos_al_sistemico.append("Polineuropatía periférica")
    if datos.get('fatiga'): hallazgos_al_sistemico.append("Fatiga severa")
    if datos.get('disauto'): hallazgos_al_sistemico.append("Disautonomía (hipotensión ortostática)")
    if datos.get('piel_lesiones'): hallazgos_al_sistemico.append("Lesiones cutáneas")
    
    # ATTR CLÁSICO
    if datos.get('stc'): hallazgos_attr_clasico.append("Síndrome del túnel carpiano bilateral")
    if datos.get('lumbar'): hallazgos_attr_clasico.append("Estenosis lumbar claudicante")
    if datos.get('biceps'): hallazgos_attr_clasico.append("Rotura bilateral de bíceps")
    if datos.get('hombro'): hallazgos_attr_clasico.append("Tendinitis del manguito rotador")
    if datos.get('dupuytren'): hallazgos_attr_clasico.append("Contractura de Dupuytren")
    if datos.get('artralgias'): hallazgos_attr_clasico.append("Artralgias crónicas")
    if datos.get('fractura_vert'): hallazgos_attr_clasico.append("Fracturas vertebrales")
    if datos.get('tendinitis_calcifica'): hallazgos_attr_clasico.append("Tendinitis calcificante")
    
    # ATTR HEREDITARIO
    if datos.get('mutacion_ttr'): hallazgos_attr_hereditario.append("Mutación TTR confirmada genéticamente")
    
    # HALLAZGOS CARDIACOS
    if datos.get('ivs'): hallazgos_cardiacos.append(f"Grosor de pared VI: {datos['ivs']} mm")
    if datos.get('gls'): hallazgos_cardiacos.append(f"GLS (strain global): {datos['gls']}%")
    volt_guardado = safe_float(datos.get('volt', 0))
    hallazgos_cardiacos.append(f"Voltaje en ECG: {volt_guardado} mV" if volt_guardado > 0 else "Voltaje en ECG: No reportado")
    if datos.get('apical_sparing'): hallazgos_cardiacos.append("Apical sparing (muy sugestivo de ATTR)")
    if datos.get('bajo_voltaje'): hallazgos_cardiacos.append("Bajo voltaje paradójico")
    if datos.get('bav_mp'): hallazgos_cardiacos.append("Bloqueo AV completo / Marcapasos")
    if datos.get('pseudo_q'): hallazgos_cardiacos.append("Pseudoinfarto (ondas Q patológicas)")
    if datos.get('biatrial'): hallazgos_cardiacos.append("Dilatación biauricular")
    if datos.get('derrame_pericardico'): hallazgos_cardiacos.append("Derrame pericárdico")
    
    # BIOMARCADORES
    hallazgos_biomarcadores = []
    nt_probnp = safe_float(datos.get('nt_probnp', 0))
    if nt_probnp > 0:
        hallazgos_biomarcadores.append(f"NT-proBNP: {nt_probnp} pg/ml")
        if nt_probnp > 3000:
            hallazgos_biomarcadores.append("  → Elevado CRÍTICO (muy sugestivo de amiloidosis)")
        elif nt_probnp > 1000:
            hallazgos_biomarcadores.append("  → Elevado moderadamente")
        elif nt_probnp <= 400:
            hallazgos_biomarcadores.append("  → Normal → Descarta amiloidosis")
    
    if datos.get('troponina'):
        hallazgos_biomarcadores.append("Troponina elevada crónica (infiltración miocárdica crónica)")
    
    # RESONANCIA MAGNÉTICA CARDÍACA
    hallazgos_rm = []
    lge_patron = str(datos.get('lge_patron', '')).lower().strip()
    if lge_patron and lge_patron != 'null':
        hallazgos_rm.append(f"Realce Tardío (LGE): {lge_patron}")
        if lge_patron in ['subendocardico', 'subendocárdico', 'transmural', 'difuso']:
            hallazgos_rm.append("  → Patrón PATOGNOMÓNICO de amiloidosis")
    
    ecv = safe_float(datos.get('ecv', 0))
    if ecv > 0:
        hallazgos_rm.append(f"Volumen Extracelular (ECV): {ecv}%")
        if ecv > 40:
            hallazgos_rm.append("  → DIAGNÓSTICO de amiloidosis")
        elif ecv > 35:
            hallazgos_rm.append("  → Elevado, muy sugestivo")
        elif ecv > 30:
            hallazgos_rm.append("  → Moderadamente elevado")
    
    if datos.get('t1_mapping'):
        hallazgos_rm.append("T1 Mapping: Elevado (sugiere amiloidosis)")
    
    # FACTORES CONFUSORES
    if datos.get('confusor_hta'): hallazgos_confusores.append("Hipertensión arterial severa")
    if datos.get('confusor_ao'): hallazgos_confusores.append("Estenosis aórtica severa")
    if datos.get('confusor_irc'): hallazgos_confusores.append("Insuficiencia renal crónica")
    
    # CONSTRUIR NARRATIVA CLÍNICA
    resumen = "## RESUMEN CLÍNICO DE HALLAZGOS\n\n"
    
    # Nivel de riesgo y impresión general
    nivel = resultado.get('nivel', 'Desconocido')
    resumen += f"**Nivel de Riesgo:** {nivel}\n\n"
    
    score = resultado.get('score', 0)
    resumen += f"**Puntuación Total:** {score} puntos\n\n"
    
    # Interpretación general
    if "ALTA" in nivel:
        resumen += "### Impresión Clínica\n"
        resumen += "Hallazgos altamente sugestivos de **amiloidosis cardíaca**. Se recomienda confirmación diagnóstica urgente mediante:\n"
        resumen += "- Biopsia endomiocárdica con tinción Congo rojo\n"
        resumen += "- Tipaje de amiloide (AL vs ATTR)\n"
        resumen += "- Consulta con especialista en amiloidosis\n\n"
    elif "INTERMEDIA" in nivel:
        resumen += "### Impresión Clínica\n"
        resumen += "**Zona gris diagnóstica.** Los hallazgos son parcialmente consistentes con amiloidosis pero no patognomónicos. Requiere:\n"
        resumen += "- Resonancia cardíaca con realce tardío (patrón amiloide)\n"
        resumen += "- Gammagrafía ósea con Tc-99m pirofosfato\n"
        resumen += "- Seguimiento ecocardiográfico seriado\n\n"
    elif "HVI" in nivel:
        resumen += "### Impresión Clínica\n"
        resumen += "Los hallazgos sugieren **hipertrofia ventricular izquierda por sobrecarga** (HTA, válvula) sin características infiltrativas claras.\n\n"
    else:
        resumen += "### Impresión Clínica\n"
        resumen += "**Baja probabilidad de amiloidosis cardíaca.** Los hallazgos no son significativos o sugieren otras etiologías.\n\n"
    
    # HALLAZGOS AL DIRECTO
    if hallazgos_al_directo:
        resumen += "### 🚨 Hallazgos Sugestivos de AL (Amiloidosis AL)\n"
        for h in hallazgos_al_directo:
            resumen += f"• {h}\n"
        resumen += "*Estos hallazgos sugieren amiloidosis tipo AL. Requiere evaluación urgente del sistema hematológico.*\n\n"
    
    # HALLAZGOS AL SISTÉMICO
    if hallazgos_al_sistemico:
        resumen += "### 🟠 Hallazgos de Afección Sistémica (AL)\n"
        for h in hallazgos_al_sistemico:
            resumen += f"• {h}\n"
        resumen += "*Manifestaciones sistémicas que elevan la probabilidad de amiloidosis AL.*\n\n"
    
    # HALLAZGOS ATTR CLÁSICO
    if hallazgos_attr_clasico:
        resumen += "### 🟣 Hallazgos Característicos de ATTR (Síndrome Musculoesquelético)\n"
        for h in hallazgos_attr_clasico:
            resumen += f"• {h}\n"
        resumen += "*La tríada deTunel Carpiano + Estenosis Lumbar + Rotura de Bíceps es patognomónica de ATTR-v.*\n\n"
    
    # HALLAZGOS ATTR HEREDITARIO
    if hallazgos_attr_hereditario:
        resumen += "### 🧬 Hallazgos de ATTR Hereditaria\n"
        for h in hallazgos_attr_hereditario:
            resumen += f"• {h}\n"
        resumen += "*ATTR hereditaria requiere cribado familiar urgente. Considerar terapia modificadora de transtiretina (tafamidis).*\n\n"
    
    # PARÁMETROS CARDIACOS
    if hallazgos_cardiacos:
        resumen += "### 💙 Parámetros Cardiacos\n"
        for h in hallazgos_cardiacos:
            resumen += f"• {h}\n"
        
        # INTERPRETACIÓN ESPECÍFICA DE PARÁMETROS
        ivs = safe_float(datos.get('ivs', 0))
        gls = safe_float(datos.get('gls', 0))
        volt = safe_float(datos.get('volt', 0))
        
        resumen += "\n**Interpretación:**\n"
        
        if ivs > 15:
            resumen += f"- Grosor VI ({ivs} mm): MUY aumentado (específico ATTR)\n"
        elif ivs > 12:
            resumen += f"- Grosor VI ({ivs} mm): Engrosamiento moderado\n"
        
        if gls < -15:
            resumen += f"- GLS ({gls}%): Función sistólica conservada\n"
        elif gls < -9:
            resumen += f"- GLS ({gls}%): Disfunción longitudinal incipiente\n"
        else:
            resumen += f"- GLS ({gls}%): Disfunción longitudinal severa\n"
        
        if volt > 0 and volt < 0.5:
            resumen += f"- Voltaje ({volt} mV): Bajo voltaje paradójico (amiloidosis)\n"
        elif volt > 0 and volt < 1.0:
            resumen += f"- Voltaje ({volt} mV): Reducido\n"
        
        resumen += "\n"
    
    # BIOMARCADORES
    if hallazgos_biomarcadores:
        resumen += "### 🔬 Biomarcadores\n"
        for h in hallazgos_biomarcadores:
            resumen += f"• {h}\n"
        resumen += "*Los biomarcadores son críticos para confirmar amiloidosis y su tipo (AL vs ATTR).*\n\n"
    
    # RESONANCIA MAGNÉTICA CARDÍACA
    if hallazgos_rm:
        resumen += "### 🎯 Resonancia Magnética Cardíaca\n"
        for h in hallazgos_rm:
            resumen += f"• {h}\n"
        resumen += "*La RM es la prueba de oro no invasiva cuando el Eco es ambiguo.*\n\n"
    
    # FACTORES CONFUSORES
    if hallazgos_confusores:
        resumen += "### ⚠️ Factores Confusores (Diferencial)\n"
        for h in hallazgos_confusores:
            resumen += f"• {h}\n"
        resumen += "*Estos factores pueden causar HVI pero NO son indicativos de amiloidosis.*\n\n"
    
    # RECOMENDACIONES FINALES
    resumen += "### 📋 Recomendaciones Clínicas\n"
    
    if "ALTA" in nivel:
        resumen += "1. **REFERENCIA URGENTE** a unidad de amiloidosis o cardiología especializada\n"
        resumen += "2. Confirmar diagnóstico mediante biopsia endomiocárdica\n"
        resumen += "3. Tipaje de amiloide (AL vs ATTR)\n"
        if "AL" in nivel or hallazgos_al_directo or hallazgos_al_sistemico:
            resumen += "4. Hemato-oncología: Proteinograma, cadenas ligeras libres\n"
        if "ATTR" in nivel or hallazgos_attr_clasico:
            resumen += "4. Genética: Secuenciación TTR (si hereditaria)\n"
        resumen += "5. Seguimiento multidisciplinario (cardiología, hematología, nefrología si aplica)\n"
    elif "INTERMEDIA" in nivel:
        resumen += "1. Resonancia cardíaca con gadolinio para evaluación de patrón de realce\n"
        resumen += "2. Gammagrafía ósea con Tc-99m pirofosfato\n"
        resumen += "3. Ecocardiografía seriada a 6-12 meses\n"
        resumen += "4. Consulta con especialista en amiloidosis\n"
        resumen += "5. Preparación para biopsia si se confirma sospecha\n"
    else:
        resumen += "1. Manejo de factores de riesgo cardiovascular\n"
        resumen += "2. Seguimiento ecocardiográfico anual\n"
        resumen += "3. ECG periódico\n"
        resumen += "4. Considerar buscar amiloidosis si hay progresión documentada\n"
    
    return resumen
