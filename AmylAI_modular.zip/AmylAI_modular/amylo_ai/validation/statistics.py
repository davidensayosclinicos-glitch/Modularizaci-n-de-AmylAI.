import re
import numpy as np
from scipy.stats import norm

def wilson_ci(x, n, alpha=0.05):
    """Calcula el intervalo de confianza de Wilson."""
    # Importamos AQUÍ para evitar conflictos con tu variable 'stats'
    from scipy.stats import norm 
    
    if n == 0: return (0.0, 0.0)
    p = x / n
    z = norm.ppf(1 - alpha / 2) # Usamos norm directamente
    denominator = 1 + z**2 / n
    centre_adjusted_probability = p + z**2 / (2 * n)
    adjusted_standard_deviation = np.sqrt((p * (1 - p) + z**2 / (4 * n)) / n)
    lower_bound = (centre_adjusted_probability - z * adjusted_standard_deviation) / denominator
    upper_bound = (centre_adjusted_probability + z * adjusted_standard_deviation) / denominator
    return (max(0.0, lower_bound), min(1.0, upper_bound))

def bootstrap_ci(y_true, y_pred, metric_func, n_boot=2000, alpha=0.05):
    """Bootstrap no paramétrico."""
    rng = np.random.RandomState(42)
    indices = np.arange(len(y_true))
    scores = []
    for _ in range(n_boot):
        boot_idx = rng.choice(indices, len(indices), replace=True)
        score = metric_func(y_true[boot_idx], y_pred[boot_idx])
        scores.append(score)
    return np.percentile(scores, [alpha/2 * 100, (1 - alpha/2) * 100])

def delong_roc_variance(ground_truth, predictions):
    """Calcula varianza AUC (DeLong)."""
    order = np.argsort(predictions)
    predictions = predictions[order]
    ground_truth = ground_truth[order]
    pos_examples = predictions[ground_truth == 1]
    neg_examples = predictions[ground_truth == 0]
    if len(pos_examples) == 0 or len(neg_examples) == 0: return 0.0, 0.0, 0.0

    def compute_midrank(x):
        J = np.argsort(x); Z = x[J]; N = len(x); T = np.zeros(N, dtype=np.float64)
        i = 0
        while i < N:
            j = i
            while j < N and Z[j] == Z[i]: j += 1
            T[i:j] = 0.5 * (i + j - 1); i = j
        T2 = np.empty(N, dtype=np.float64); T2[J] = T + 1
        return T2

    tx = compute_midrank(predictions)
    tz = compute_midrank(predictions[ground_truth == 1])
    ty = compute_midrank(predictions[ground_truth == 0])
    m = len(pos_examples); n = len(neg_examples)
    aucs = (np.sum(tx[ground_truth == 1]) - m * (m + 1) / 2) / (m * n)
    v01 = (tx[ground_truth == 1] - tz) / n
    v10 = (tx[ground_truth == 0] - ty) / m
    var_auc = (np.var(v01) / m) + (np.var(v10) / n)
    return aucs, var_auc

def permutation_test_multiclass(y_true, y_pred, metric_func, n_perm=1000):
    """Test de permutación."""
    score_obs = metric_func(y_true, y_pred)
    rng = np.random.RandomState(42)
    scores_perm = []
    y_shuffled = y_true.copy()
    for _ in range(n_perm):
        rng.shuffle(y_shuffled)
        scores_perm.append(metric_func(y_shuffled, y_pred))
    p_value = (np.sum(np.array(scores_perm) >= score_obs) + 1) / (n_perm + 1)
    return p_value

def normalizar_clase_diagnostica(val: str) -> str:
    """Normaliza etiquetas diagnósticas para análisis estadístico estable."""
    v_upper = str(val).upper().strip()

    if not v_upper:
        return "Otros"

    if "INTERMEDIA" in v_upper or "SCREENING" in v_upper:
        return "Intermedia"

    if "ATTR" in v_upper:
        return "ATTR"

    if re.search(r"\bAL\b", v_upper):
        return "AL"

    if "HVI" in v_upper or "HIPERTROF" in v_upper:
        return "HVI"

    if "SANO" in v_upper or "NO AMILOIDOSIS" in v_upper or "BAJA" in v_upper:
        return "Sano"

    return "Otros"
