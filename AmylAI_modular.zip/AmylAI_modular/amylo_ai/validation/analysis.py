from typing import Any, Dict
import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
try:
    import seaborn as sns
except Exception:
    sns = None
from scipy.stats import norm
from sklearn.metrics import (confusion_matrix, roc_curve, auc, classification_report, cohen_kappa_score, accuracy_score)
try:
    import streamlit as st
except Exception:
    st = None

from amylo_ai.config import UMBRAL_CONFIRMACION, UMBRAL_SCREENING
from amylo_ai.clinical.algorithm import calcular_riesgo_experto
from amylo_ai.validation.statistics import wilson_ci, bootstrap_ci, delong_roc_variance, normalizar_clase_diagnostica

def render_tab_validacion():
    """
    Validación estadística clínica simplificada del algoritmo.
    Incluye: ROC/AUC, subgrupos, tabla JACC/EHJ, errores, matriz, FDA/EMA.
    """
    st.header("🧪 Validación Estadística Clínica")
    
    uploaded_file = st.file_uploader("Cargar Cohorte CSV para Validación", type=['csv'])
    simular_hvi = st.checkbox("🧬 Simular HVI (IVS > 14mm)", value=True)

    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)
            
            # ============ PROCESAMIENTO ============
            progress_bar = st.progress(0)
            results = []
            
            for index, row in df.iterrows():
                caso_id = row.get('id', index + 1)
                d_simulado = {
                    'ivs': 15 if simular_hvi and row['grupo_diagnostico'] not in ['No amiloidosis / sano'] else 9, 
                    'volt': 5 if row['ecg_bajo_voltaje'] else 12,
                    'gls': -10 if row['strain_reducido'] else -20,
                    'apical_sparing': row['apical_sparing'],
                    'confusor_hta': row['hta'],
                    'confusor_ao': row['estenosis_aortica'],
                    'stc': row['tunel_carpiano'],
                    'macro': row['macroglosia'],
                    'purpura': row['purpura_periorbitaria'],
                    'mgus': row['monoclonalidad'],
                    'nefro': row['proteinuria'],
                    'neuro_p': row['neuropatia'],
                    'disauto': row['hipotension_ortostatica']
                }
                
                res = calcular_riesgo_experto(d_simulado)
                results.append({
                    'Caso_ID': caso_id,
                    'Diagnóstico Real': row['grupo_diagnostico'],
                    'Diagnóstico del Algoritmo': res['nivel'],
                    'Score': res['score'],
                    'Hallazgos': ", ".join(res['hallazgos'])
                })
                
                if index % max(1, len(df)//10) == 0:
                    progress_bar.progress(min(index / len(df), 1.0))
            
            progress_bar.progress(1.0)
            
            # ============ PREPARACIÓN DE DATOS ============
            df_res = pd.DataFrame(results)
            total_casos = len(df_res)
            df_analisis = df_res[~df_res['Diagnóstico del Algoritmo'].str.contains("INTERMEDIA", case=False, na=False)].copy()
            casos_validos = len(df_analisis)
            casos_excluidos = total_casos - casos_validos
            
            st.success(f"✅ {casos_validos} casos analizados ({casos_excluidos} intermedios excluidos)")
            
            # ============ NORMALIZACIÓN ============
            def normalizar_diagnostico(val):
                clase = normalizar_clase_diagnostica(val)
                if clase == 'Sano':
                    return 'No Amiloidosis'
                return clase
            
            df_analisis['Diag_Real_Norm'] = df_analisis['Diagnóstico Real'].apply(normalizar_diagnostico)
            df_analisis['Diag_Algo_Norm'] = df_analisis['Diagnóstico del Algoritmo'].apply(normalizar_diagnostico)
            df_analisis['Real_Binary'] = df_analisis['Diag_Real_Norm'].isin(['AL', 'ATTR']).astype(int)
            df_analisis['Algo_Binary'] = df_analisis['Diag_Algo_Norm'].isin(['AL', 'ATTR']).astype(int)
            
            # ============ MÉTRICAS ============
            from sklearn.metrics import confusion_matrix, roc_curve, auc
            
            y_true_bin = df_analisis['Real_Binary'].values
            y_pred_bin = df_analisis['Algo_Binary'].values
            y_scores = df_analisis['Score'].values
            
            if len(np.unique(y_true_bin)) >= 2:
                fpr, tpr, _ = roc_curve(y_true_bin, y_scores)
                roc_auc = auc(fpr, tpr)
            else:
                fpr, tpr, roc_auc = np.array([0.0, 1.0]), np.array([0.0, 1.0]), 0.5
            
            kappa = cohen_kappa_score(df_analisis['Diag_Real_Norm'], df_analisis['Diag_Algo_Norm'])
            
            cm = confusion_matrix(y_true_bin, y_pred_bin, labels=[0, 1])
            tn, fp, fn, tp = cm.ravel()
            
            sensibilidad = tp / (tp + fn) if (tp + fn) > 0 else 0
            especificidad = tn / (tn + fp) if (tn + fp) > 0 else 0
            ppv = tp / (tp + fp) if (tp + fp) > 0 else 0
            npv = tn / (tn + fn) if (tn + fn) > 0 else 0
            lr_plus = sensibilidad / (1 - especificidad) if (1 - especificidad) > 0 else float('inf')
            lr_minus = (1 - sensibilidad) / especificidad if especificidad > 0 else float('inf')
            accuracy = (tp + tn) / (tp + tn + fp + fn)

            # ============ IC 95% (Wilson + DeLong/Bootstrap) ============
            sens_ci_low, sens_ci_high = wilson_ci(tp, tp + fn)
            esp_ci_low, esp_ci_high = wilson_ci(tn, tn + fp)

            auc_ci_low, auc_ci_high = roc_auc, roc_auc
            try:
                _, var_auc = delong_roc_variance(y_true_bin.astype(int), y_scores.astype(float))
                if np.isfinite(var_auc) and var_auc > 0:
                    z = norm.ppf(0.975)
                    se_auc = np.sqrt(var_auc)
                    auc_ci_low = max(0.0, roc_auc - z * se_auc)
                    auc_ci_high = min(1.0, roc_auc + z * se_auc)
                else:
                    def _safe_auc(yt, ys):
                        if len(np.unique(yt)) < 2:
                            return 0.5
                        fpr_b, tpr_b, _ = roc_curve(yt, ys)
                        return auc(fpr_b, tpr_b)

                    auc_ci_low, auc_ci_high = bootstrap_ci(
                        y_true_bin.astype(int),
                        y_scores.astype(float),
                        _safe_auc,
                        n_boot=1000,
                        alpha=0.05
                    )
                    auc_ci_low, auc_ci_high = float(max(0.0, auc_ci_low)), float(min(1.0, auc_ci_high))
            except Exception:
                auc_ci_low, auc_ci_high = roc_auc, roc_auc
            
            # ============ 1. MÉTRICAS PRINCIPALES (TARJETAS) ============
            st.subheader("📊 Métricas Principales")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("🎯 AUC-ROC", f"{roc_auc:.3f}", help="Ideal > 0.85")
            with col2:
                st.metric("🔗 Kappa", f"{kappa:.3f}", help="Ideal > 0.80")
            with col3:
                st.metric("🩺 Sensibilidad", f"{sensibilidad:.1%}", help="Detección")
            with col4:
                st.metric("🛡️ Especificidad", f"{especificidad:.1%}", help="Sanos correctos")

            st.markdown("#### 📏 Intervalos de Confianza (IC 95%)")
            ci_table = pd.DataFrame({
                'Métrica': ['Sensibilidad', 'Especificidad', 'AUC-ROC'],
                'Estimación': [f"{sensibilidad:.1%}", f"{especificidad:.1%}", f"{roc_auc:.3f}"],
                'IC 95%': [
                    f"[{sens_ci_low:.1%}, {sens_ci_high:.1%}]",
                    f"[{esp_ci_low:.1%}, {esp_ci_high:.1%}]",
                    f"[{auc_ci_low:.3f}, {auc_ci_high:.3f}]"
                ]
            })
            st.dataframe(ci_table, use_container_width=True)
            
            st.divider()
            
            # ============ 2. CURVA ROC ============
            st.subheader("📈 Curva ROC")
            fig_roc, ax_roc = plt.subplots(figsize=(7, 6))
            ax_roc.plot(fpr, tpr, color='#d62728', lw=2.5, label=f'AUC = {roc_auc:.3f}')
            ax_roc.plot([0, 1], [0, 1], color='gray', lw=1, linestyle='--')
            ax_roc.set_xlabel('1 - Especificidad')
            ax_roc.set_ylabel('Sensibilidad')
            ax_roc.set_title('Curva ROC - Discriminación Diagnóstica')
            ax_roc.legend(loc="lower right")
            ax_roc.grid(True, alpha=0.3)
            st.pyplot(fig_roc)
            
            # ============ 3. ANÁLISIS POR SUBGRUPO (AL vs ATTR) ============
            st.subheader("🧬 Sensibilidad por Subtipo (AL vs ATTR)")
            
            df_al = df_analisis[df_analisis['Diag_Real_Norm'] == 'AL']
            df_attr = df_analisis[df_analisis['Diag_Real_Norm'] == 'ATTR']
            
            al_sens = (df_al['Diag_Algo_Norm'] == 'AL').sum() / len(df_al) if len(df_al) > 0 else 0
            attr_sens = (df_attr['Diag_Algo_Norm'] == 'ATTR').sum() / len(df_attr) if len(df_attr) > 0 else 0
            
            col_sub1, col_sub2 = st.columns(2)
            with col_sub1:
                st.markdown("#### 🔴 Amiloidosis AL")
                st.metric("Sensibilidad AL", f"{al_sens:.1%}", f"{int(df_al['Diag_Algo_Norm'].eq('AL').sum())}/{len(df_al)}")
            with col_sub2:
                st.markdown("#### 🟢 Amiloidosis ATTR")
                st.metric("Sensibilidad ATTR", f"{attr_sens:.1%}", f"{int(df_attr['Diag_Algo_Norm'].eq('ATTR').sum())}/{len(df_attr)}")
            
            # Gráfico comparativo
            fig_sub, ax_sub = plt.subplots(figsize=(7, 4))
            tipos = ['AL', 'ATTR']
            sensibilidades = [al_sens * 100, attr_sens * 100]
            bars = ax_sub.bar(tipos, sensibilidades, color=['#d62728', '#2ca02c'], edgecolor='black', linewidth=1.5)
            ax_sub.set_ylabel('Sensibilidad (%)')
            ax_sub.set_title('Sensibilidad por Subtipo de Amiloidosis')
            ax_sub.set_ylim([0, 105])
            ax_sub.axhline(y=75, color='orange', linestyle='--', alpha=0.7, label='Umbral clínico')
            ax_sub.legend()
            for bar, val in zip(bars, sensibilidades):
                ax_sub.text(bar.get_x() + bar.get_width()/2, val + 2, f'{val:.1f}%', ha='center', fontsize=10)
            st.pyplot(fig_sub)
            
            st.divider()
            
            # ============ 4. TABLA JACC/EHJ ============
            st.subheader("📑 Tabla Estilo JACC/EHJ")
            
            tabla_jacc = pd.DataFrame({
                'Métrica': [
                    'Casos (n)',
                    'Sensibilidad',
                    'Especificidad',
                    'VPP',
                    'VPN',
                    'LR+',
                    'LR−',
                    'Exactitud',
                    'AUC-ROC',
                    'Kappa Cohen',
                    'Sens. AL',
                    'Sens. ATTR'
                ],
                'Valor': [
                    f"{casos_validos}",
                    f"{sensibilidad:.1%}",
                    f"{especificidad:.1%}",
                    f"{ppv:.1%}",
                    f"{npv:.1%}",
                    f"{lr_plus:.2f}" if lr_plus != float('inf') else "∞",
                    f"{lr_minus:.2f}" if lr_minus != float('inf') else "∞",
                    f"{accuracy:.1%}",
                    f"{roc_auc:.3f}",
                    f"[{auc_ci_low:.3f}, {auc_ci_high:.3f}]",
                    f"{kappa:.3f}",
                    f"{al_sens:.1%}",
                    f"{attr_sens:.1%}"
                ]
            })
            
            st.dataframe(tabla_jacc, use_container_width=True)
            
            st.divider()
            
            # ============ 5. ANÁLISIS DE ERRORES CLÍNICOS ============
            st.subheader("⚠️ Análisis de Errores Clínicos")
            
            df_analisis['Tipo_Error'] = df_analisis.apply(
                lambda row: 'VP' if row['Real_Binary']==1 and row['Algo_Binary']==1 
                else 'VN' if row['Real_Binary']==0 and row['Algo_Binary']==0
                else 'FP' if row['Real_Binary']==0 and row['Algo_Binary']==1
                else 'FN', axis=1
            )
            
            error_sum = df_analisis['Tipo_Error'].value_counts()
            
            col_err1, col_err2 = st.columns(2)
            
            with col_err1:
                fig_err, ax_err = plt.subplots(figsize=(7, 5))
                colors_err = {'VP': '#2ca02c', 'VN': '#1f77b4', 'FP': '#ff7f0e', 'FN': '#d62728'}
                vals = [error_sum.get(k, 0) for k in ['VP', 'VN', 'FP', 'FN']]
                labels_err = ['VP', 'VN', 'FP', 'FN']
                cols_err = [colors_err.get(k, '#999') for k in labels_err]
                
                wedges, texts, autotexts = ax_err.pie(vals, labels=labels_err, autopct='%1.1f%%',
                                                       colors=cols_err, startangle=90)
                for autotext in autotexts:
                    autotext.set_color('white')
                    autotext.set_fontweight('bold')
                ax_err.set_title('Matriz de Confusión Binaria')
                st.pyplot(fig_err)
            
            with col_err2:
                st.markdown("#### Resumen de Errores")
                st.markdown(f"""
                **VP:** {error_sum.get('VP', 0)} - Detectados correctamente  
                **VN:** {error_sum.get('VN', 0)} - Sanos identificados  
                **FP:** {error_sum.get('FP', 0)} - Falsa alarma ⚠️  
                **FN:** {error_sum.get('FN', 0)} - No detectados 🚨  
                
                **Tasa FN:** {(error_sum.get('FN', 0)/(tp+fn)*100) if (tp+fn)>0 else 0:.1f}%
                """)
            
            st.divider()
            
            # ============ 6. MATRIZ DE CONFUSIÓN MULTICLASE (HEATMAP) ============
            st.subheader("🔲 Matriz de Confusión Multiclase")
            
            cm_multi = pd.crosstab(df_analisis['Diag_Real_Norm'], df_analisis['Diag_Algo_Norm'])
            
            fig_cm, ax_cm = plt.subplots(figsize=(9, 7))
            import seaborn as sns
            sns.heatmap(cm_multi, annot=True, fmt='d', cmap='Blues', ax=ax_cm, 
                       cbar_kws={'label': 'Casos'}, linewidths=1)
            ax_cm.set_xlabel('Diagnóstico del Algoritmo', fontweight='bold')
            ax_cm.set_ylabel('Diagnóstico Real', fontweight='bold')
            ax_cm.set_title('Matriz de Confusión Multiclase')
            st.pyplot(fig_cm)
            
            st.dataframe(cm_multi, use_container_width=True)

            # ============ 6.1 MÉTRICAS POR CLASE ============
            st.subheader("📌 Métricas por Clase")

            classes_sorted = sorted(set(df_analisis['Diag_Real_Norm']) | set(df_analisis['Diag_Algo_Norm']))
            report = classification_report(
                df_analisis['Diag_Real_Norm'],
                df_analisis['Diag_Algo_Norm'],
                labels=classes_sorted,
                output_dict=True,
                zero_division=0
            )
            df_report = pd.DataFrame(report).T
            df_report = df_report.rename(columns={
                'precision': 'Precisión',
                'recall': 'Sensibilidad',
                'f1-score': 'F1',
                'support': 'Soporte'
            })
            st.dataframe(df_report, use_container_width=True)
            
            st.divider()
            
            # ============ 7. CHECKLIST FDA/EMA CDSS ============
            st.subheader("🏥 Validación FDA/EMA CDSS")
            
            fn_rate = (fn/(tp+fn)*100) if (tp+fn)>0 else 0
            
            fda_checklist = pd.DataFrame({
                'Criterio': [
                    'Sensibilidad ≥ 75%',
                    'Especificidad ≥ 85%',
                    'Kappa ≥ 0.75',
                    'AUC-ROC ≥ 0.80',
                    'Tasa FN ≤ 10%',
                    'Análisis multiclase',
                    'Análisis subgrupo',
                    'Matriz confusión'
                ],
                'Valor': [
                    f"{sensibilidad:.1%}",
                    f"{especificidad:.1%}",
                    f"{kappa:.3f}",
                    f"{roc_auc:.3f}",
                    f"{fn_rate:.1f}%",
                    "✓",
                    "✓",
                    "✓"
                ],
                'Cumple': [
                    '✅' if sensibilidad >= 0.75 else '❌',
                    '✅' if especificidad >= 0.85 else '❌',
                    '✅' if kappa >= 0.75 else '❌',
                    '✅' if roc_auc >= 0.80 else '❌',
                    '✅' if fn_rate <= 10 else '❌',
                    '✅',
                    '✅',
                    '✅'
                ]
            })
            
            st.dataframe(fda_checklist, use_container_width=True)
            
            cumple = (fda_checklist['Cumple'] == '✅').sum()
            total = len(fda_checklist)
            pct = (cumple/total)*100
            
            if pct >= 75:
                st.success(f"🟢 APTO: {cumple}/{total} criterios cumplidos ({pct:.0f}%)")
            elif pct >= 50:
                st.warning(f"🟡 MEJORAS NECESARIAS: {cumple}/{total} criterios ({pct:.0f}%)")
            else:
                st.error(f"🔴 NO APTO: {cumple}/{total} criterios ({pct:.0f}%)")
            
            st.divider()

            # ============ 7.1 RENDIMIENTO BINARIO DETALLADO ============
            st.subheader("🧪 Rendimiento Binario (Sens, Esp, VPP, VPN, LR+, LR−)")
            bin_table = pd.DataFrame({
                'Métrica': ['Sensibilidad', 'Especificidad', 'VPP', 'VPN', 'LR+', 'LR−', 'Exactitud'],
                'Valor': [
                    f"{sensibilidad:.1%}",
                    f"{especificidad:.1%}",
                    f"{ppv:.1%}",
                    f"{npv:.1%}",
                    f"{lr_plus:.2f}" if lr_plus != float('inf') else "∞",
                    f"{lr_minus:.2f}" if lr_minus != float('inf') else "∞",
                    f"{accuracy:.1%}"
                ]
            })
            st.dataframe(bin_table, use_container_width=True)

            st.divider()

            # ============ 7.2 LISTAS COMPLETAS FP/FN ============
            st.subheader("🧾 Listas Completas de Falsos Negativos y Falsos Positivos")
            fn_rows = df_analisis[df_analisis['Tipo_Error'] == 'FN'][
                ['Caso_ID', 'Diagnóstico Real', 'Diagnóstico del Algoritmo', 'Score', 'Hallazgos']
            ]
            fp_rows = df_analisis[df_analisis['Tipo_Error'] == 'FP'][
                ['Caso_ID', 'Diagnóstico Real', 'Diagnóstico del Algoritmo', 'Score', 'Hallazgos']
            ]

            col_fn, col_fp = st.columns(2)
            with col_fn:
                st.markdown("#### 🚨 Falsos Negativos (FN)")
                st.dataframe(fn_rows, use_container_width=True)
            with col_fp:
                st.markdown("#### ⚠️ Falsos Positivos (FP)")
                st.dataframe(fp_rows, use_container_width=True)

            st.divider()

            # ============ 7.3 SUPLEMENTO (TABLAS + FIGURA) ============
            st.subheader("📎 Suplemento (Tablas + Figura)")

            sup_col1, sup_col2 = st.columns(2)
            with sup_col1:
                st.markdown("#### Tabla S1. Rendimiento Binario")
                st.dataframe(bin_table, use_container_width=True)
                st.markdown("#### Tabla S2. Métricas por Clase")
                st.dataframe(df_report, use_container_width=True)
            with sup_col2:
                st.markdown("#### Figura S1. Curva ROC")
                fig_sup, ax_sup = plt.subplots(figsize=(6, 5))
                ax_sup.plot(fpr, tpr, color='#d62728', lw=2.5, label=f'AUC = {roc_auc:.3f}')
                ax_sup.plot([0, 1], [0, 1], color='gray', lw=1, linestyle='--')
                ax_sup.set_xlabel('1 - Especificidad')
                ax_sup.set_ylabel('Sensibilidad')
                ax_sup.set_title('Curva ROC - Discriminación Diagnóstica')
                ax_sup.legend(loc="lower right")
                ax_sup.grid(True, alpha=0.3)
                st.pyplot(fig_sup)
            
            # ============ 8. EXPORTACIÓN ============
            st.subheader("💾 Exportar Resultados")
            
            # CSV
            csv_data = df_analisis.to_csv(index=False).encode()
            st.download_button(
                "⬇️ CSV Completo",
                csv_data,
                f"validacion_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                "text/csv"
            )
            
            # Resumen TXT
            txt_resumen = f"""VALIDACIÓN ESTADÍSTICA CLÍNICA
Algoritmo de Diagnóstico de Amiloidosis Cardíaca

RESUMEN EJECUTIVO
===============================
Fecha: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Casos totales: {total_casos}
Casos analizados: {casos_validos}
Casos excluidos: {casos_excluidos}

MÉTRICAS CLAVE
===============================
Sensibilidad: {sensibilidad:.1%}
Especificidad: {especificidad:.1%}
VPP: {ppv:.1%}
VPN: {npv:.1%}
LR+: {lr_plus:.2f}
LR-: {lr_minus:.2f}
Exactitud: {accuracy:.1%}
AUC-ROC: {roc_auc:.3f}
AUC-ROC IC95%: [{auc_ci_low:.3f}, {auc_ci_high:.3f}]
Kappa: {kappa:.3f}
Sensibilidad IC95%: [{sens_ci_low:.1%}, {sens_ci_high:.1%}]
Especificidad IC95%: [{esp_ci_low:.1%}, {esp_ci_high:.1%}]

ANÁLISIS POR SUBGRUPO
===============================
Sensibilidad AL: {al_sens:.1%}
Sensibilidad ATTR: {attr_sens:.1%}

ERRORES CLÍNICOS
===============================
Verdaderos Positivos: {error_sum.get('VP', 0)}
Verdaderos Negativos: {error_sum.get('VN', 0)}
Falsos Positivos: {error_sum.get('FP', 0)}
Falsos Negativos: {error_sum.get('FN', 0)}
Tasa FN: {fn_rate:.1f}%

CUMPLIMIENTO FDA/EMA
===============================
Criterios cumplidos: {cumple}/{total} ({pct:.0f}%)
Estado: {'APTO' if pct >= 75 else 'REQUIERE MEJORAS' if pct >= 50 else 'NO APTO'}
            """
            
            st.download_button(
                "📄 Resumen Ejecutivo",
                txt_resumen,
                f"resumen_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                "text/plain"
            )

        except Exception as e:
            st.error(f"Error procesando CSV: {e}")

def evaluar_estres_algoritmo(df_full: pd.DataFrame, umbral_screening: float = None, umbral_confirmacion: float = None) -> Dict[str, Any]:
    """Evalúa el desempeño del algoritmo contra diagnósticos reales con umbrales ajustables"""
    
    if umbral_screening is None:
        umbral_screening = UMBRAL_SCREENING
    if umbral_confirmacion is None:
        umbral_confirmacion = UMBRAL_CONFIRMACION
    
    df = df_full.copy()
    df['diagnostico'] = df['diagnostico'].astype(str).str.strip()

    def normalizar_diag_safety(val: str) -> str:
        return normalizar_clase_diagnostica(val)

    df['diagnostico_clean'] = df['diagnostico'].apply(normalizar_diag_safety)

    def get_metrics(row: pd.Series) -> pd.Series:
        res = calcular_riesgo_experto(row.to_dict(), umbral_screening=umbral_screening, umbral_confirmacion=umbral_confirmacion)
        lvl = 2 if "ALTA" in res['nivel'] else (1 if "INTERMEDIA" in res['nivel'] else 0)
        return pd.Series([res['score'], lvl, res['nivel']])

    df[['Score_Num', 'Score_Ord', 'Nivel_Txt']] = df.apply(get_metrics, axis=1)

    y_true_bin = df['diagnostico_clean'].isin(['AL', 'ATTR']).astype(int).values
    y_score_ord = df['Score_Num'].values
    y_pred_bin = (~df['Nivel_Txt'].str.contains("INTERMEDIA", case=False, na=False) &
                  ~df['Nivel_Txt'].str.contains("BAJA|SANO|HVI", case=False, na=False)).astype(int).values

    try:
        fpr, tpr, _ = roc_curve(y_true_bin, y_score_ord)
        roc_auc = auc(fpr, tpr)
    except Exception:
        roc_auc = 0.0

    try:
        cm_bin = confusion_matrix(y_true_bin, y_pred_bin, labels=[0, 1])
        tn, fp, fn, tp = cm_bin.ravel()
    except Exception:
        tn = fp = fn = tp = 0

    sensibilidad = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    especificidad = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    sens_ci_low, sens_ci_high = wilson_ci(tp, tp + fn)
    esp_ci_low, esp_ci_high = wilson_ci(tn, tn + fp)

    auc_ci_low, auc_ci_high = roc_auc, roc_auc
    try:
        _, var_auc = delong_roc_variance(y_true_bin.astype(int), y_score_ord.astype(float))
        if np.isfinite(var_auc) and var_auc > 0:
            z = norm.ppf(0.975)
            se_auc = np.sqrt(var_auc)
            auc_ci_low = max(0.0, roc_auc - z * se_auc)
            auc_ci_high = min(1.0, roc_auc + z * se_auc)
    except Exception:
        auc_ci_low, auc_ci_high = roc_auc, roc_auc

    y_true_m = df['diagnostico_clean']
    y_pred_m = df['Nivel_Txt'].apply(normalizar_clase_diagnostica)

    try:
        kappa = cohen_kappa_score(y_true_m, y_pred_m)
    except Exception:
        kappa = 0.0

    intermedia_rate = float((df['Score_Ord'] == 1).mean()) if len(df) > 0 else 0.0

    return {
        'n': len(df),
        'auc': float(roc_auc),
        'auc_ci_low': float(auc_ci_low),
        'auc_ci_high': float(auc_ci_high),
        'kappa': float(kappa),
        'intermedia_rate': intermedia_rate,
        'sensibilidad': float(sensibilidad),
        'especificidad': float(especificidad),
        'sens_ci_low': float(sens_ci_low),
        'sens_ci_high': float(sens_ci_high),
        'esp_ci_low': float(esp_ci_low),
        'esp_ci_high': float(esp_ci_high)
    }
