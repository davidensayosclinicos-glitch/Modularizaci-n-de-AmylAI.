from typing import Any, Dict
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
try:
    import streamlit as st
except Exception:
    class _NoCache:
        @staticmethod
        def cache_resource(fn=None, **kwargs):
            if fn is not None: return fn
            def deco(f): return f
            return deco
    st = _NoCache()

from amylo_ai.config import DEFAULT_DATA, FEATURES, ENSAMBLE_CATEGORIAS, ENSAMBLE_ESTILOS
from amylo_ai.utils.parsing import safe_float
from amylo_ai.data.repository import load_training_database
from amylo_ai.clinical.algorithm import calcular_riesgo_experto
from amylo_ai.clinical.heuristic import diagnostico_ia
from amylo_ai.services.llm import generar_diagnostico_por_llm

@st.cache_resource
def entrenar_modelo_ia():
    df = load_training_database()
    # Verificación de seguridad
    if df.empty or len(df) < 5: 
        return "ERROR: Pocos datos", None
    
    try:
        # Aseguramos que solo usamos columnas numéricas y quitamos filas con diagnósticos vacíos
        X = df[FEATURES].copy()
        for col in X.columns:
            X[col] = pd.to_numeric(X[col], errors='coerce').fillna(0)
        
        y = df['diagnostico']
        
        # El modelo necesita al menos 2 tipos de diagnóstico diferentes para aprender
        if len(y.unique()) < 2:
            return "ERROR: Solo un tipo de diagnóstico en DB", None

        modelo = RandomForestClassifier(n_estimators=100, random_state=42)
        modelo.fit(X, y)
        return modelo, modelo.classes_
    except Exception as e:
        return f"ERROR: {str(e)}", None

def normalizar_categoria_diagnostico(texto: Any) -> str:
    """Mapea texto libre de diagnóstico a una categoría canónica de ensamble."""
    if not texto:
        return "BAJA / SANO"

    t = str(texto).strip().upper()

    if "ALTA SOSPECHA (AL)" in t:
        return "ALTA SOSPECHA (AL)"
    if "ALTA PROBABILIDAD (ATTR)" in t:
        return "ALTA PROBABILIDAD (ATTR)"
    if "INTERMEDIA" in t:
        return "INTERMEDIA (Screening)"
    if "HVI" in t or "HIPERTROF" in t:
        return "HVI No Amiloide"
    if "BAJA" in t or "SANO" in t or "CONTROL" in t:
        return "BAJA / SANO"

    # Variantes frecuentes
    if "ATTR" in t:
        return "ALTA PROBABILIDAD (ATTR)"
    if " AL " in f" {t} " or ("AL" in t and ("SOSPECHA" in t or "PROB" in t)):
        return "ALTA SOSPECHA (AL)"

    return "BAJA / SANO"



@st.cache_resource
def get_modelo_ml():
    modelo, clases = entrenar_modelo_ia()
    if isinstance(modelo, str):
        return None, None
    return modelo, clases

def obtener_probabilidades_ml_por_categoria(datos: Dict[str, Any]) -> Dict[str, Any]:
    """Calcula probabilidades ML agregadas por categoría canónica de ensamble."""
    modelo_ml, _ = get_modelo_ml()
    if modelo_ml is None:
        return {
            "disponible": False,
            "categoria_top": None,
            "proba_categoria": {},
            "clase_top_original": None,
        }

    try:
        fila = {}
        for feature in FEATURES:
            valor = datos.get(feature, DEFAULT_DATA.get(feature, 0))
            if isinstance(valor, bool):
                fila[feature] = int(valor)
            else:
                fila[feature] = pd.to_numeric(valor, errors='coerce')

        X_pred = pd.DataFrame([fila], columns=FEATURES).fillna(0)

        probas = modelo_ml.predict_proba(X_pred)[0]
        clases = list(modelo_ml.classes_)

        proba_categoria = {c: 0.0 for c in ENSAMBLE_CATEGORIAS}
        for clase, proba in zip(clases, probas):
            cat = normalizar_categoria_diagnostico(clase)
            proba_categoria[cat] = proba_categoria.get(cat, 0.0) + float(proba)

        categoria_top = max(proba_categoria, key=proba_categoria.get) if proba_categoria else None
        idx_top = int(np.argmax(probas)) if len(probas) > 0 else 0
        clase_top_original = str(clases[idx_top]) if clases else ""

        return {
            "disponible": True,
            "categoria_top": categoria_top,
            "proba_categoria": proba_categoria,
            "clase_top_original": clase_top_original,
        }
    except Exception:
        return {
            "disponible": False,
            "categoria_top": None,
            "proba_categoria": {},
            "clase_top_original": None,
        }

def calcular_ensamble_experto_ml_llm(datos: Dict[str, Any], usar_llm: bool = True) -> Dict[str, Any]:
    """Ensamble ponderado real: Experto + ML + LLM (pesos dinámicos por disponibilidad)."""
    res_experto = calcular_riesgo_experto(datos)
    cat_experto = normalizar_categoria_diagnostico(res_experto.get("nivel", ""))

    votos = {c: 0.0 for c in ENSAMBLE_CATEGORIAS}
    componentes = {}

    peso_experto = 0.50
    peso_ml = 0.25
    peso_llm = 0.25
    peso_total = 0.0

    # Experto (siempre)
    votos[cat_experto] += peso_experto
    peso_total += peso_experto
    componentes["experto"] = {
        "peso": peso_experto,
        "categoria": cat_experto,
        "confianza": float(safe_float(res_experto.get("confianza_porcentaje", 50.0))),
    }

    # ML
    ml_info = obtener_probabilidades_ml_por_categoria(datos)
    if ml_info.get("disponible", False):
        proba_cat = ml_info.get("proba_categoria", {})
        for cat, proba in proba_cat.items():
            votos[cat] += peso_ml * float(proba)
        peso_total += peso_ml
        componentes["ml"] = {
            "peso": peso_ml,
            "categoria": ml_info.get("categoria_top"),
            "clase_modelo": ml_info.get("clase_top_original"),
            "probabilidades": proba_cat,
        }
    else:
        componentes["ml"] = {
            "peso": 0.0,
            "categoria": None,
            "clase_modelo": None,
            "probabilidades": {},
        }

    # LLM
    cat_llm = None
    etiqueta_llm = "No usado"
    if usar_llm:
        try:
            llm_out = generar_diagnostico_por_llm(datos)
            etiqueta_llm = llm_out.get("diagnostico_llm", "")
        except Exception:
            etiqueta_llm = diagnostico_ia(datos)

        cat_llm = normalizar_categoria_diagnostico(etiqueta_llm)
        votos[cat_llm] += peso_llm
        peso_total += peso_llm

    componentes["llm"] = {
        "peso": peso_llm if usar_llm else 0.0,
        "categoria": cat_llm,
        "etiqueta": etiqueta_llm,
        "usado": bool(usar_llm),
    }

    if peso_total <= 0:
        peso_total = 1.0

    votos_norm = {cat: (valor / peso_total) for cat, valor in votos.items()}
    categoria_final = max(votos_norm, key=votos_norm.get)
    fuerza_consenso = float(votos_norm.get(categoria_final, 0.0)) * 100.0

    res_final = dict(res_experto)
    estilo = ENSAMBLE_ESTILOS.get(categoria_final, ENSAMBLE_ESTILOS["BAJA / SANO"])

    # Si el consenso difiere del experto, sobreescribir etiqueta/estilo
    if categoria_final != cat_experto:
        res_final["nivel"] = categoria_final
        res_final["color"] = estilo["color"]
        res_final["msg"] = estilo["msg"]
        res_final["accion"] = estilo["accion"]

    # Confianza final combinada: confianza experto + fuerza de consenso del ensamble
    conf_experto = float(safe_float(res_experto.get("confianza_porcentaje", 50.0)))
    confianza_final = max(40.0, min(99.0, (0.6 * conf_experto) + (0.4 * fuerza_consenso)))

    evidencia_base = res_final.get("evidencia", "")
    evidencia_ensamble = (
        f"Ensamble: experto={componentes['experto']['categoria']}"
        f", ml={componentes['ml']['categoria'] or 'N/D'}"
        f", llm={componentes['llm']['categoria'] or 'N/D'}"
    )

    res_final["confianza_porcentaje"] = round(confianza_final, 1)
    res_final["evidencia"] = f"{evidencia_base} | {evidencia_ensamble}".strip(" |")
    res_final["componentes_ensamble"] = componentes
    res_final["votos_ensamble"] = votos_norm
    res_final["categoria_ensamble"] = categoria_final
    res_final["fuerza_consenso"] = round(fuerza_consenso, 1)

    return res_final
