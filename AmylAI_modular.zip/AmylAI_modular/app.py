import os
import importlib
import streamlit as st

from amylo_ai.data.repository import migrar_base_datos_v4_3
from amylo_ai.data.synthetic import generar_base_datos_sintetica
from amylo_ai.config import BASE_DIR, DB_FILE
from amylo_ai.ui.state import init_session_state
from amylo_ai.ui.styles import apply_global_styles, apply_page_styles
from amylo_ai.ui.sidebar import render_sidebar

st.set_page_config(
    page_title="AmylAI 1.0",
    page_icon="image_6.png",
    layout="wide",
    initial_sidebar_state="expanded"
)

if 'migracion_v4_3' not in st.session_state:
    migrar_base_datos_v4_3()
    st.session_state.migracion_v4_3 = True

init_session_state()
apply_global_styles()
selected_tab, fondo_lateral_css = render_sidebar()
apply_page_styles(fondo_lateral_css)

PAGE_MAP = {
    "Lote de PDFs": "amylo_ai.ui.pages.batch",
    "Caso Individual": "amylo_ai.ui.pages.individual",
    "Guia Clinica": "amylo_ai.ui.pages.guide",
    "Base de Datos": "amylo_ai.ui.pages.database",
    "Diagnóstico del Algoritmo": "amylo_ai.ui.pages.diagnosis",
    "Test de Estrés": "amylo_ai.ui.pages.stress",
}

page_module = importlib.import_module(PAGE_MAP[selected_tab])
page_module.render()

if __name__ == '__main__' and os.environ.get('AMYLO_GENERATE_SYNTH', '0') == '1':
    os.environ['AMYLO_HEADLESS'] = '1'
    print("Iniciando generación de base sintética (1000 casos)...")
    try:
        df_gen = generar_base_datos_sintetica(1000)
        print(f"Generación completada. Archivo guardado en: {os.path.join(BASE_DIR, DB_FILE)}")
    except Exception as e:
        print(f"Error generando casos sintéticos: {e}")
