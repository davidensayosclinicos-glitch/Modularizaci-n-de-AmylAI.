# AmylAI modular

Refactor del script monolítico original en módulos funcionales.

## Estructura

- `app.py`: arranque y enrutado de pantallas.
- `amylo_ai/clinical/`: algoritmo experto, red flags, heurística y narrativa.
- `amylo_ai/services/`: OCR y LLM/NLP.
- `amylo_ai/data/`: base CSV, migraciones y datos sintéticos.
- `amylo_ai/ml/`: entrenamiento y ensamble ML.
- `amylo_ai/validation/`: estadística y validación.
- `amylo_ai/ui/`: estilos, sidebar y páginas.
- `amylo_ai/utils/`: parseo y ficheros.

## Uso

1. Copia al directorio raíz los recursos que ya usa tu app (`image_6.png`, fondos y el CSV de datos).
2. Instala dependencias: `pip install -r requirements.txt`.
3. Ejecuta: `streamlit run app.py`.

## Optimización aplicada

La pantalla seleccionada se importa dinámicamente. El modelo RandomForest deja de entrenarse al importar todo el proyecto: se obtiene mediante `get_modelo_ml()` con caché de recurso cuando realmente se necesita.
